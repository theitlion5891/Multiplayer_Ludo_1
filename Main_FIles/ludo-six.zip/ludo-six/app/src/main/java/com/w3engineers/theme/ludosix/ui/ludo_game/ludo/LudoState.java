package com.w3engineers.theme.ludosix.ui.ludo_game.ludo;

import android.util.Log;

import java.util.ArrayList;
import java.util.Random;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.keys.PreferenceKey;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.home.HomeActivity;
import com.w3engineers.theme.ludosix.ui.internet.InternetHomeActivity;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.Game;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.GamePlayer;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.GameState;
import com.w3engineers.theme.util.helper.SharedPref;
import com.w3engineers.theme.util.helper.ToneFactory;
import com.w3engineers.theme.util.lib.internet.ConnectivityInternetProvider;
import com.w3engineers.theme.util.lib.nearby.ConnectivityProvider;
import timber.log.Timber;

/**
 * Ludo State
 * This contains the official state for the Ludo Game.
 * based on GameFramework by Steven R. Vegdahl
 * CounterGame
 * TickTackToe2
 * PigGame - implemented by us in lab
 *
 * @author Raj Nayyar
 * @author Avery Guillermo
 * @author Luke Danowski
 * @author Chris Sebrechts
 */

public class LudoState extends GameState {

    // to satisfy Serializable interface
    private static final long serialVersionUID = 1433248382648392873L;
    //instance variables
    private Random dice;
    private int diceVal;

    private boolean isRollable;
    Token[] pieces;

    private int numPlayers;
    private ArrayList<Player> playerList;

    private int playerID_active;
    private int[] playerScore;

    private boolean stillPlayersTurn;
    private boolean canBringOutOfStart;

    private boolean canMovePiece;
    private boolean killedAPiece;

    private boolean scoredAPoint;
    private boolean shouldSkipActions = false;

    private int index;
    private int lastActivePlayer;
    private ArrayList<Integer> sixRolls;
    private Game game;

    public enum Action {ANIMATE_TOKEN, ANIMATE_TOKEN_CUT, ANIMATE_DICE}

    private int count;
    private Action action;

    /**
     * LudoState
     * Initializing the entire state on its first creation
     */
    public LudoState(ArrayList<Player> playerList) {
        scoredAPoint = false;
        killedAPiece = false;
        canMovePiece = false;

        stillPlayersTurn = false;
        canBringOutOfStart = false;
        numPlayers = playerList.size();

        this.playerList = playerList;

        sixRolls = new ArrayList<>();
        sixRolls.add(0);
        sixRolls.add(0);
        sixRolls.add(0);
        sixRolls.add(0);

        dice = new Random();
        diceVal = 1;
        isRollable = true;

        if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
            if (ConnectivityProvider.getConnectivity().getCurrentRole() == ConnectivityProvider.ConnectionRole.CLIENT && HomeActivity.mHostPlayer != null) {
                playerID_active = getActivePlayerId();

            } else {
                playerID_active = 0;
            }
        }else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
            if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.CLIENT && InternetHomeActivity.mHostPlayer != null) {
                playerID_active = getActivePlayerId();

            } else {
                playerID_active = 0;
            }
        }


        pieces = new Token[]{
                new Token(0, 0.8, 0.8), //red piece1
                new Token(0, 3.8, 0.8), //red piece2
                new Token(0, 3.8, 3.8), //red piece3
                new Token(0, 0.8, 3.8), //red piece4
                new Token(1, 9.8, 0.8), //blue piece1
                new Token(1, 12.8, 0.8), //blue piece2
                new Token(1, 12.8, 3.8), //blue piece3
                new Token(1, 9.8, 3.8), //blue piece4
                new Token(2, 12.8, 9.8), //yellow piece1
                new Token(2, 12.8, 12.8), //yellow piece2
                new Token(2, 9.8, 12.8), //yellow piece3
                new Token(2, 9.8, 9.8), //yellow piece4
                new Token(3, 0.8, 9.8), //green piece1
                new Token(3, 3.8, 9.8), //green piece2
                new Token(3, 3.8, 12.8), //green piece3
                new Token(3, 0.8, 12.8)}; //green piece4

        //scores are 0;
        playerScore = new int[]{0, 0, 0, 0};
    }

    private int getActivePlayerId() {
        for (int i = 0; i < numPlayers; i++) {
            if (playerList.get(i).getPlayerBasePosition() == 0) {
                return playerList.get(i).getPlayerPosition();
            }
        }
        return -1;
    }


    public GamePlayer getGamePlayer() {
        return gamePlayer;
    }

    public void setGamePlayer(GamePlayer gamePlayer) {
        this.gamePlayer = gamePlayer;
    }

    private GamePlayer gamePlayer;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    /**
     * Ludostate
     * copies the entire game state
     * (It is a copy constructor)
     *
     * @param original the object from which the copy should be made
     */
    public LudoState(LudoState original) {
        this.scoredAPoint = original.scoredAPoint;
        this.killedAPiece = original.killedAPiece;
        this.canMovePiece = original.canMovePiece;
        this.numPlayers = original.numPlayers;
        this.playerList = original.playerList;
        this.playerID_active = original.playerID_active;
        this.dice = original.dice;
        this.diceVal = original.diceVal;
        this.isRollable = original.isRollable;
        this.stillPlayersTurn = original.stillPlayersTurn;

        //set the piece array
        this.pieces = new Token[original.pieces.length];
        for (int i = 0; i < original.pieces.length; i++) {
            pieces[i] = new Token(original.pieces[i]);
        }

        //set the scores
        this.playerScore = new int[original.playerScore.length];
        for (int i = 0; i < original.playerScore.length; i++) {
            this.playerScore[i] = original.playerScore[i];
        }

    }

    public void setPlayerList(ArrayList<Player> playerList) {
        this.playerList = playerList;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public Action getAction() {
        return this.action;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getLastActivePlayer() {
        return lastActivePlayer;
    }

    public void setLastActivePlayer(int lastActivePlayer) {
        this.lastActivePlayer = lastActivePlayer;
    }

    /**
     * getWhoseMove
     * Tells whose move it is.
     *
     * @return the index (0 or 1) of the player whose move it is.
     */
    public int getWhoseMove() {
        return playerID_active;
    }


    /**
     * getPlayerScore
     * getter method for score
     *
     * @return score array
     */
    public int getPlayerScore(int index) {
        return playerScore[index];
    }

    /**
     * getNumplayers
     * getter method for numPlayers
     *
     * @return number of active players
     */
    public int getNumPlayers() {
        return numPlayers;
    }

    public ArrayList<Player> getPlayerList() {
        return playerList;
    }

    /**
     * newRoll
     * generates a new random roll if player is allowed to play.
     * considers if it is their turn and if roll a 6, they get to roll again
     * <p>
     * //     * @param playerID who sent action
     *
     * @return is move possible with current roll
     */
    public boolean newRoll() {
        if (isRollable) {

            if (sixRolls.get(playerID_active) == 2) {
                diceVal = dice.nextInt(5) + 1;

            } else {
                diceVal = dice.nextInt(6) + 1;
            }

            //handle the case of re-rolls on a 6 with a switch
            switch (diceVal) {
                case 6:
                    isRollable = false; //so it stays true;
                    sixRolls.set(playerID_active, sixRolls.get(playerID_active) + 1);

                default:
                    isRollable = !isRollable;
            }

            //if no moves exist based on diceVal just go to next player
            updateMovesAvailable();
            return true;
        }
        return false;
    }

    public boolean newCustomRoll(int diceValue) {
        if (isRollable) {
            //handle the case of rerolls on a 6 with a switch
            switch (diceVal = diceValue) {
                case 6:
                    isRollable = false; //so it stays true;
                default:
                    isRollable = !isRollable;
            }
            //if no moves exist based on diceVal just go to next player
            updateMovesAvailable();
            return true;
        }
        return false;
    }


    /**
     * updateMovesAvailable
     * Called after a dice roll. We go through the active player's pieces and checks for pieces
     * which can move by the rules of the game, each piece has a boolean which is changed to
     * reflect the outcome of the check;
     *
     * @return true if valid moves exist
     */
    private boolean updateMovesAvailable() {

        //checks if any moves available;
        boolean oneTrue = false;

        //set movable boolean
        for (int i = (playerID_active * 4); i < (playerID_active * 4 + 4); i++) {
            //first, check the pieces in home base
            if (pieces[i].getIsHome()) {
                if (diceVal == 6) {
                    //is in home base and a 6 has been rolled
                    pieces[i].setIsMovable(true);
                    oneTrue = true;
                } else {
                    pieces[i].setIsMovable(false);
                }
            } else if (pieces[i].getNumSpacesMoved() < 51) {
                //in normal route
                pieces[i].setIsMovable(true);
                oneTrue = true;
            } else if (pieces[i].getNumSpacesMoved() + diceVal < 57) {
                //in home stretch and total will be less than or equal to 56
                pieces[i].setIsMovable(true);
                oneTrue = true;
            } else if (pieces[i].getNumSpacesMoved() + diceVal > 57) {
                pieces[i].setIsMovable(false);

            } else {
                pieces[i].setIsMovable(false);
            }
        }

        return oneTrue;
    }


    /**
     * increments player score
     * increments player score
     */
    public void incPlayerScore(int playerID) {
        playerScore[playerID]++;
    }

    /**
     * getNumMovableTokens
     * <p>
     * returns the number of pieces which are in play
     * //     * @param playerID
     *
     * @return
     */
    public int getNumMovableTokens(int playerID) {
        int count = 0;
        for (int i = (playerID * 4); i < (playerID * 4 + 4); i++) {
            if (!pieces[i].getIsHome() && !pieces[i].getReachedHomeBase() && pieces[i].getIsMovable()) {
                int currentLocation = pieces[i].getNumSpacesMoved();
                int homeBaseLocation = 56;
                if (currentLocation > 50) { //Inside homestretch
                    if (diceVal + currentLocation <= homeBaseLocation) {
                        count++;
                    }
                    // else don't increment because it can't move
                } else {
                    count++;
                }
            }
        }
        return count;
    }

    public void changeMovableTokensHighlightState(int playerID, boolean shouldHighlight) {

        for (int i = (playerID * 4); i < (playerID * 4 + 4); i++) {
            if (!pieces[i].getReachedHomeBase() && pieces[i].getIsMovable()) {
                int currentLocation = pieces[i].getNumSpacesMoved();
                int homeBaseLocation = 56;
                if (currentLocation > 50) { //Inside homestretch
                    if (diceVal + currentLocation <= homeBaseLocation) {
                        pieces[i].setShouldHighlight(shouldHighlight);
                    }
                    // else don't increment because it can't move
                } else {
                    pieces[i].setShouldHighlight(shouldHighlight);
                }
            }
        }
    }

    /**
     * changePlayerTurn
     * <p>
     * this changes the players turn
     */
    public void changePlayerTurn() {
        resetSixRollsArray();

        this.stillPlayersTurn = false;
        this.isRollable = true;

        if (numPlayers == 2) {
            if (playerID_active == 0) {
                playerID_active = 2;

            } else {
                playerID_active = 0;
            }

        } else {
            if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
                if (ConnectivityProvider.getConnectivity().getCurrentRole() == ConnectivityProvider.ConnectionRole.CLIENT && HomeActivity.mHostPlayer != null) {
                    getNextActivePlayerId();

                } else {

//                if (numPlayers == 3 && playerID_active == 1) {
//                    playerID_active = 3;
//
//                } else {

                    if ((++playerID_active) >= numPlayers) {
                        playerID_active = 0;
                    }
//                }
                }
            }else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
                if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.CLIENT && InternetHomeActivity.mHostPlayer != null) {
                    getNextActivePlayerId();

                } else {

//                if (numPlayers == 3 && playerID_active == 1) {
//                    playerID_active = 3;
//
//                } else {

                    if ((++playerID_active) >= numPlayers) {
                        playerID_active = 0;
                    }
//                }
                }
            }


        }
    }

    private void resetSixRollsArray() {
        for (int i = 0; i < sixRolls.size(); i++) {
            sixRolls.set(i, 0);
        }
    }

    private void getNextActivePlayerId() {
        if (playerID_active != -1) {
            int nextPlayerId = (playerID_active == 3) ? 0 : (playerID_active + 1);

            if (isActivePlayerIdValid(nextPlayerId)) {
                playerID_active = nextPlayerId;

            } else {
                playerID_active = nextPlayerId + 1;
            }

            Timber.i("Active player id: %d", playerID_active);

        }
    }

    private boolean isActivePlayerIdValid(int id) {
        for (int i = 0; i < numPlayers; i++) {

            if (playerList.get(i).getPlayerPosition() == id)
                return true;
        }

        return false;
    }

    public void setIsRollable(boolean bol) {
        this.isRollable = bol;
    }


    /**
     * advanceToken
     * This advances the token
     * it handles the killing of opponent pieces
     * it determines if a piece can move while within the homestrech row.
     *
     * @param playerID
     * @param index
     * @return
     */
    public boolean advanceToken(int playerID, int index) {

        if (shouldSkipActions) {
            Token piece = pieces[index];

            //reset all the boolean variables for the next roll
            canBringOutOfStart = false;
            canMovePiece = false; //now that the player moved the token, the player can't use the diceVal to move anymore!
            killedAPiece = false;
            scoredAPoint = false;

            if (action == Action.ANIMATE_TOKEN) {
                piece.incNumSpacesMoved(1);

            } else if (action == Action.ANIMATE_TOKEN_CUT) {
                Log.e("cutanim", "Token current pos: " + piece.getNumSpacesMoved());

                piece.incNumSpacesMoved(-1);

                Log.e("cutanim", "Token new pos: " + piece.getNumSpacesMoved());

                if (piece.getNumSpacesMoved() == 0) {
                    Log.e("cutanim", "Token reached home");

                    piece.setIsHome(true);
                    action = null;

                    //According to Ludo Rules, if the player either rolled a six, killed a piece, or the player scored a point
                    // then grant them another turn!
                    stillPlayersTurn = true;
                    isRollable = true;
                }
            }
            return true;

        } else {
            //only act on movable pieces. Always updated after each dice roll.
            if (pieces[index].getIsMovable()) {

                if (diceVal > 1) {
                    pieces[index].incNumSpacesMoved(-(diceVal - 1));
                }

                int currentLocation = pieces[index].getNumSpacesMoved();
                int homeBaseLocation = 56;
                //Inside homestretch
                if (currentLocation >= 50) {
                    if (diceVal + currentLocation == homeBaseLocation) {
                        pieces[index].incNumSpacesMoved(diceVal);
                        incPlayerScore(playerID);
                        pieces[index].setReachedHomeBase(true);
                        this.scoredAPoint = true;
                        ToneFactory.on().play(R.raw.reach_home);

                        Timber.i("Player: " + playerID + " Scored a Point" + "Score: " + playerScore[playerID]);
                    } else if (diceVal + currentLocation < homeBaseLocation) {
                        pieces[index].incNumSpacesMoved(diceVal);
                    }
                } else {
                    pieces[index].incNumSpacesMoved(diceVal);
                }
                int spacesPieceHasTraveled = pieces[index].getNumSpacesMoved();
                // check for overlap on non-safe tiles
                if (spacesPieceHasTraveled < 51) {// 51 is the number of tiles till homestretch
                    //consider where piece is
                    switch (spacesPieceHasTraveled) {
                        //safe tiles
                        case 8:
                        case 13:
                        case 21:
                        case 26:
                        case 34:
                        case 39:
                        case 47:
                            break;  //do nothing
                        default:    //else
                            //check to see if we overlap and need to kick another piece back home
                            //iterate through all active pieces

                            if (!checkIfMultiplePiecesAvailable(pieces[index].getCurrentXLoc(), pieces[index].getCurrentYLoc())) {
                                for (int i = 0; i < 16; i++) {
                                    if (pieces[i].getOwner() != playerID_active &&  //not one of my own
                                            !pieces[i].getIsHome() &&                   //is in play
                                            pieces[i].getCurrentXLoc() == pieces[index].getCurrentXLoc() &&
                                            pieces[i].getCurrentYLoc() == pieces[index].getCurrentYLoc()) {

                                        ToneFactory.on().play(R.raw.token_cut);

                                        // Skipping other actions and start token cut reverse animation
                                        setIndex(i);
                                        setAction(Action.ANIMATE_TOKEN_CUT);
                                        Log.e("cutanim", "Token got cut index: " + i);
                                        game.sendAction(new ActionAnimateTokenCut(gamePlayer));
                                        return true;
                                    }
                                }
                            }
                    }
                }

                if (diceVal != 6 && !this.scoredAPoint) {
                    //Change the current player's turn!
                    lastActivePlayer = getWhoseMove();
                    changePlayerTurn();
                } else if (this.scoredAPoint) {
                    //According to Ludo Rules, if the player either rolled a six, killed a piece, or the player scored a point
                    // then grant them another turn!
                    stillPlayersTurn = true;
                    isRollable = true;
                } else { // diceVal == 6
                    //the player rolled a six, so they get to roll again!
                    stillPlayersTurn = true;
                    isRollable = true;
                }

                //reset all the boolean variables for the next roll
                canBringOutOfStart = false;
                canMovePiece = false; //now that the player moved the token, the player can't use the diceVal to move anymore!
                killedAPiece = false;
                scoredAPoint = false;

                return true;
            } else {
                //do nothing
                return true;
            }
        }
    }

    private boolean checkIfMultiplePiecesAvailable(int xPos, int yPos) {
        int pieceCount = 0;

        for (int i = 0; i < 16; i++) {
            if (pieces[i].getOwner() != playerID_active && !pieces[i].getIsHome() &&
                    pieces[i].getCurrentXLoc() == xPos && pieces[i].getCurrentYLoc() == yPos) {

                pieceCount += 1;
            }
        }

        return pieceCount > 1;
    }

    /**
     * getTokenIndexOfFirstPieceInStart
     * Gets the Token Index Of The First Piece In Start
     * mainly used by the computer players
     *
     * @param playerID
     * @return
     */
    public int getTokenIndexOfFirstPieceInStart(int playerID) {
        for (int i = (playerID * 4); i < (playerID * 4 + 4); i++) {//traverse through the only the pieces the player owns
            if (pieces[i].getIsHome()) {
                return i;
            }
        }
        return -1;
    }

    /**
     * getTokenIndexOfFirstPieceOutOfStart
     *
     * @param playerID
     * @return returns -1 when there is no piece in the base
     */
    //used for the computer player!
    public int getTokenIndexOfFirstPieceOutOfStart(int playerID) {
        for (int i = (playerID * 4); i < (playerID * 4 + 4); i++) {//traverse through the only the pieces the player owns
            if (!pieces[i].getIsHome() && !pieces[i].getReachedHomeBase() && pieces[i].getIsMovable()) {
                return i;
            }
        }
        return -1;
    }

    /**
     * toString
     *
     * @return
     */
    @Override
    public String toString() {
        String output = "";
        for (int i = 0; i < 4; i++) {
            output += "\nPlayer " + pieces[i].getOwner() + ": ";
            for (int j = i; j < 16; j += 4) {
                output += "\nPiece " + (j - i) / 4 + " at " + pieces[j].getNumSpacesMoved() +
                        " and " + (pieces[j].getIsHome() ? "is home." : "is not home.");
            }

        }

        return output;
    }

    /**
     * getter method for dice value
     *
     * @return value of dice
     */
    public int getDiceVal() {
        return this.diceVal;
    }

    public boolean hasKilledAPiece() {
        return this.killedAPiece;
    }

    /**
     * getter method for roll boolean
     *
     * @return true if allowed to make roll
     */
    public boolean getIsRollable() {
        return isRollable;
    }

    /**
     * This method sets the skipAction flag value, which is used during token move animation
     *
     * @param shouldSkipActions is the action set by game
     */
    public void setShouldSkipActions(boolean shouldSkipActions) {
        this.shouldSkipActions = shouldSkipActions;
    }

    public boolean getShouldSkipActions() {
        return this.shouldSkipActions;
    }

    public void setStillPlayersTurn(boolean b) {
        this.stillPlayersTurn = b;
    }

    public boolean getStillPlayersTurn() {
        return this.stillPlayersTurn;
    }

    public void setCanBringOutOfStart(boolean b) {
        this.canBringOutOfStart = b;
    }

    public boolean isCanBringOutOfStart() {
        return canBringOutOfStart;
    }

    public void setCanMovePiece(boolean b) {
        this.canMovePiece = b;
    }

    public boolean getCanMovePiece() {
        return this.canMovePiece;
    }

    /**
     * getIndexOfFirstPlayerPiece
     * gets the token index of the first piece the player owns
     *
     * @param playerID
     * @return
     */
    public int getIndexOfFirstPlayerPiece(int playerID) {
        for (int i = (playerID * 4); i < (playerID * 4 + 4); i++) {//traverse through the only the pieces the player owns
            return i;
        }
        return 0;
    }

    /**
     * getIndexOfFirstPeiceInStart
     * gets the index of the first piece in start
     *
     * @param playerID
     * @return
     */
    public int getIndexOfFirstPieceInStart(int playerID) {
        for (int i = (playerID * 4); i < (playerID * 4 + 4); i++) {//traverse through the only the pieces the player owns
            if (pieces[i].getIsHome()) {
                return i;
            }
        }
        return -1;
    }


    public int getPieceFurthestTravelled(int playerID) {
        int furthest = 0;
        for (int i = (playerID * 4); i < (playerID * 4 + 4); i++) {//traverse through the only the pieces the player owns
            if (pieces[i].getNumSpacesMoved() != 57) {
                if (pieces[i].getNumSpacesMoved() > furthest) {
                    furthest = i;
                }
            }
        }
        if (furthest == 0) {
            return getTokenIndexOfFirstPieceOutOfStart(playerID);
        }
        return furthest;
    }


    public int[] getOrder(int playerID) {
        int init = playerID * 4;
        int[] order = new int[]{init + 3, init + 2, init + 1, init};
        int temp = 0;
        int index = 0;
        for (int i = 0; i < 10; i++) {
            if (pieces[order[index]].getNumSpacesMoved() > pieces[order[index + 1]].getNumSpacesMoved()) {
                temp = order[index + 1];
                order[index + 1] = order[index];
                order[index] = temp;
            }
            index++;
            if (index == 3) {
                index = 0;
            }
        }
        return order;
    }
}
