package com.w3engineers.theme.ludosix.data.remote.s3api.helper;

/*
 *  ****************************************************************************
 *  * Created by : Ahmed Mohmmad Ullah (Azim) on 5/3/2018 at 5:18 PM.
 *  * Email : azim@w3engineers.com
 *  *
 *  * Last edited by : Ahmed Mohmmad Ullah (Azim) on 5/3/2018.
 *  *
 *  * Last Reviewed by : <Reviewer Name> on <mm/dd/yy>
 *  ****************************************************************************
 */

public class S3UploaderConfig {

    /**
     * Base url to communicate with server
     * e.g: www.google.com/
     */
    public String  baseUrl;

    /**
     * Path url to obtain upload signed url
     * e.g: www.google.com/getsignedurl
     */
    public String uploadSignedUrl;
    /**
     * S3 bucket name
     */
    public String bucket;

    /**
     * User authenticaton token
     */
    public String authTokenId;
}
