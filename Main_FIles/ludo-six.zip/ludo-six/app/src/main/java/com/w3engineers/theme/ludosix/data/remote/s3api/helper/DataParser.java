package com.w3engineers.theme.ludosix.data.remote.s3api.helper;

/*
 *  ****************************************************************************
 *  * Created by : Ahmed Mohmmad Ullah (Azim) on 5/7/2018 at 5:12 PM.
 *  * Email : azim@w3engineers.com
 *  *
 *  * Last edited by : Ahmed Mohmmad Ullah (Azim) on 5/7/2018.
 *  *
 *  * Last Reviewed by : <Reviewer Name> on <mm/dd/yy>
 *  ****************************************************************************
 */

import android.text.TextUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;

public class DataParser {

    private static final int INITIAL_INDEX_TO_PARSE_STATUS_CODE = 0;
    private static final int END_INDEX_TO_PARSE_STATUS_CODE = 3;
    private static final int INITIAL_INDEX_TO_PARSE_JSON = 5;

    public static S3FileUploadResponse parseUploadUrlData(String response) {
        if (TextUtils.isEmpty(response)) {
            throw new NullPointerException();
        }
        try {
            String code = response.substring(INITIAL_INDEX_TO_PARSE_STATUS_CODE, END_INDEX_TO_PARSE_STATUS_CODE);
            response = response.substring(INITIAL_INDEX_TO_PARSE_JSON);
            JSONObject jsonObject = new JSONObject(response);

            int responseCode = Integer.valueOf(code);
            S3FileUploadResponse s3FileUploadResponse = new S3FileUploadResponse();
            s3FileUploadResponse.responseCode = responseCode;

            switch (responseCode) {
                case HttpURLConnection.HTTP_OK:

                    JSONObject jObject = jsonObject.getJSONObject(JsonConstants.DATA);

                    s3FileUploadResponse.uploadSignedUrl = jObject.getString(JsonConstants.SIGNED_URL);
                    s3FileUploadResponse.fileKey = jObject.getString(JsonConstants.FILE_KEY);

                    return s3FileUploadResponse;

                default:
                    s3FileUploadResponse.responseMessage = jsonObject.getString(JsonConstants.MESSAGE);
                    return s3FileUploadResponse;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }

}
