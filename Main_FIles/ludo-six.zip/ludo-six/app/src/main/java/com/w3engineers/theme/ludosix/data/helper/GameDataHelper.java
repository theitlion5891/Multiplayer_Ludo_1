package com.w3engineers.theme.ludosix.data.helper;

import com.google.gson.Gson;

import com.w3engineers.theme.LudoSixApp;
import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.keys.PreferenceKey;
import com.w3engineers.theme.ludosix.data.local.model.ScoreBoard;
import com.w3engineers.theme.ludosix.data.local.model.UserInfo;
import com.w3engineers.theme.util.helper.SharedPref;
import com.w3engineers.theme.util.lib.internet.ConnectivityInternetProvider;
import com.w3engineers.theme.util.lib.nearby.ConnectivityProvider;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/9/2018 at 12:21 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Helper class for saving and retrieving user info
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 03/11/2019.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 03/11/2019.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class GameDataHelper {

    private static Gson gson = new Gson();

    public static boolean saveUserInfo(UserInfo userInfo) {
        return SharedPref.write(PreferenceKey.USER_INFO, gson.toJson(userInfo));
    }

    public static boolean saveLudoScoreBoard(ScoreBoard scoreBoard) {
        return SharedPref.write(PreferenceKey.LUDO_SCORE_BOARD, gson.toJson(scoreBoard));
    }

    public static boolean saveSnakesScoreBoard(ScoreBoard scoreBoard) {
        return SharedPref.write(PreferenceKey.SNAKES_SCORE_BOARD, gson.toJson(scoreBoard));
    }

    public static ScoreBoard getScoreBoard() {
        if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
            if (ConnectivityProvider.getConnectivity().getNetworkName().equals(LudoSixApp.getContext().getString(R.string.ludo))) {
                return getLudoScoreBoard();

            } else {
                return getSnakesScoreBoard();
            }
        }else {
            if (ConnectivityInternetProvider.getConnectivity().getNetworkName().equals(LudoSixApp.getContext().getString(R.string.ludo))) {
                return getLudoScoreBoard();

            } else {
                return getSnakesScoreBoard();
            }
        }
    }

    private static ScoreBoard getLudoScoreBoard() {
        String scoreBoard = SharedPref.read(PreferenceKey.LUDO_SCORE_BOARD);

        // If scoreboard is not created yet then creating empty scoreboard
        if (scoreBoard.isEmpty()) {
            ScoreBoard emptyScoreBoard = getEmptyScoreBoard();

            // Creating empty score board
            saveLudoScoreBoard(emptyScoreBoard);
            return emptyScoreBoard;
        }

        return gson.fromJson(scoreBoard, ScoreBoard.class);
    }

    private static ScoreBoard getEmptyScoreBoard() {
        ScoreBoard emptyScoreBoard = new ScoreBoard();

        emptyScoreBoard.setVs2PlayersLose(0);
        emptyScoreBoard.setVs2PlayersWin(0);

        emptyScoreBoard.setVs3PlayersLose(0);
        emptyScoreBoard.setVs3PlayersWin(0);

        emptyScoreBoard.setVs4PlayersLose(0);
        emptyScoreBoard.setVs4PlayersWin(0);

        return emptyScoreBoard;
    }

    private static ScoreBoard getSnakesScoreBoard() {
        String scoreBoard = SharedPref.read(PreferenceKey.SNAKES_SCORE_BOARD);

        // If scoreboard is not created yet then creating empty scoreboard
        if (scoreBoard.isEmpty()) {
            ScoreBoard emptyScoreBoard = getEmptyScoreBoard();

            // Creating empty score board
            saveSnakesScoreBoard(emptyScoreBoard);
            return emptyScoreBoard;
        }

        return gson.fromJson(scoreBoard, ScoreBoard.class);
    }

    public static UserInfo getUserInfo() {
        String info = SharedPref.read(PreferenceKey.USER_INFO);
        if (info.isEmpty())
            return null;

        return gson.fromJson(info, UserInfo.class);
    }

    public static void setIsTutorialShown(boolean isShown) {
        SharedPref.write(PreferenceKey.IS_TUTORIAL_SHOWN, isShown);
    }

    public static boolean getIsTutorialShown() {
        return SharedPref.readBoolean(PreferenceKey.IS_TUTORIAL_SHOWN);
    }

    public static boolean setSoundVolume(float volume) {
        return SharedPref.write(PreferenceKey.SOUND_VOLUME, volume);
    }

    public static float getSoundVolume() {
        return SharedPref.readFloat(PreferenceKey.SOUND_VOLUME);
    }
}
