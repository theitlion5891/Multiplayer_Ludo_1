package com.w3engineers.theme.ludosix.ui.splash;

import com.w3engineers.theme.ludosix.ui.base.BasePresenter;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/7/2018 at 3:33 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Presenter class
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 11/7/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 11/7/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class SplashPresenter extends BasePresenter<SplashMvpView> {

}