package com.w3engineers.theme.util.lib.internet;

/**
 * * ============================================================================
 * * Copyright (C) 2019 W3 Engineers Ltd - All Rights Reserved.
 * * Unauthorized copying of this file, via any medium is strictly prohibited
 * * Proprietary and confidential
 * * ----------------------------------------------------------------------------
 * * Created by: Sudipta K Paik on [30-Jan-2019 at 6:56 PM].
 * * Email: sudipta@w3engineers.com
 * * ----------------------------------------------------------------------------
 * * Project: Qeasy.
 * * Code Responsibility: <Purpose of code>
 * * ----------------------------------------------------------------------------
 * * Edited by :
 * * --> <First Editor> on [30-Jan-2019 at 6:56 PM].
 * * --> <Second Editor> on [30-Jan-2019 at 6:56 PM].
 * * ----------------------------------------------------------------------------
 * * Reviewed by :
 * * --> <First Reviewer> on [30-Jan-2019 at 6:56 PM].
 * * --> <Second Reviewer> on [30-Jan-2019 at 6:56 PM].
 * * ============================================================================
 **/

public interface Constants {

    interface Remote {
        //Enter your server url
        String BASE_URL = "Enter your server url here";
    }

    interface RemoteKeys {
        String LOGIN = "login";
        String NEW_MESSAGE = "new_message";
        String USER_JOINED = "user_joined";
        String USER_LEFT = "user_left";
        String ADD_USER = "add_user";
        String HOST = "1";
        String CLIENT = "0";
    }

}
