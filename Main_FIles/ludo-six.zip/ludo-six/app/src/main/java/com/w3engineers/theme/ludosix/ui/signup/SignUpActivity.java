package com.w3engineers.theme.ludosix.ui.signup;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.NonNull;
import android.view.View;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.Calendar;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.local.model.UserInfo;
import com.w3engineers.theme.ludosix.databinding.ActivitySignUpBinding;
import com.w3engineers.theme.ludosix.ui.base.BaseActivity;
import com.w3engineers.theme.ludosix.ui.connectivity_selection.ConnectivitySelectionActivity;
import com.w3engineers.theme.ludosix.ui.game_selection.GameSelectionActivity;
import com.w3engineers.theme.util.helper.Glider;
import com.w3engineers.theme.util.helper.ImageCompressHelper;
import com.w3engineers.theme.util.helper.PermissionUtil;
import com.w3engineers.theme.util.helper.Toaster;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/9/2018 at 12:21 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: User sign up class
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 11/9/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 11/9/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class SignUpActivity extends BaseActivity<SignUpMvpView, SignUpPresenter> implements SignUpMvpView, ImageCompressHelper.ImageCompressedListener {

    private ActivitySignUpBinding mBinding;
    private Uri mProfileImageUri;
    private static int PERMISSION_REQUEST_CODE = 1001;
    private static final String[] REQUIRED_PERMISSIONS =
            new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            };


    /**
     * Start Activity (Pass value as a 2nd Parameter)
     * Date: 2018-03-13
     * Added By: Sudipta K Paik
     *
     * @param context
     **/
    public static void runActivity(Context context) {
        Intent intent = new Intent(context, SignUpActivity.class);

        runCurrentActivity(context, intent);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_sign_up;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = (ActivitySignUpBinding) getViewDataBinding();

        // Button infinite zoom animation
        YoYo.with(Techniques.Shake)
                .duration(2000)
                .repeat(-1)
                .playOn(mBinding.activitySignUpEnterBtn);

        setClickListener(mBinding.activitySignUpProfilePicIv, mBinding.activitySignUpEnterBtn);
    }

    @Override
    protected void startUI() {

    }

    @Override
    protected void stopUI() {

    }

    @Override
    protected SignUpPresenter initPresenter() {
        return new SignUpPresenter();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.right_in, R.anim.right_out);
    }

    private void startImageChooser() {
        CropImage.activity()
                .setGuidelines(CropImageView.Guidelines.ON_TOUCH)
                .setActivityTitle(getString(R.string.app_name))
                .setCropShape(CropImageView.CropShape.OVAL)
                .setCropMenuCropButtonTitle(getString(R.string.crop))
                .setFixAspectRatio(true)
                .setAspectRatio(5, 5)
                .start(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.activity_sign_up_profile_pic_iv:
                if (PermissionUtil.init(this).request(PERMISSION_REQUEST_CODE, REQUIRED_PERMISSIONS)) {
                    startImageChooser();
                }
                break;

            case R.id.activity_sign_up_enter_btn:
                UserInfo userInfo = new UserInfo();
                userInfo.setName(mBinding.activitySignUpNameEt.getText().toString().trim());
                userInfo.setImagePath(mProfileImageUri != null ? mProfileImageUri.getPath() : "");
                presenter.validateUserInfo(userInfo);
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                compressedImage(result.getUri());
            }
        }
    }

    private void compressedImage(Uri uri) {
        ImageCompressHelper compressHelper = new ImageCompressHelper(this);
        compressHelper.compress(uri);
    }

    @Override
    public void onSignUp(boolean isSuccessful) {
        if (isSuccessful) {
            Toaster.success(getString(R.string.profile_created));
            ConnectivitySelectionActivity.runActivity(this);
            onBackPressed();

        } else {
            Toaster.error(getString(R.string.something_went_wrong));
        }
    }

    @Override
    public void onUserInfoValidated(String message, UserInfo userInfo) {
        if (message.isEmpty()) {
            userInfo.setId(userInfo.getName() + ":" + Calendar.getInstance().getTimeInMillis()); // Creating unique user id
            presenter.signUp(userInfo);
        } else {
            Toaster.error(message);
        }
    }

    @Override
    public void onImageCompressed(Uri uri) {
        mProfileImageUri = uri;

        if (mProfileImageUri != null) {
            Glider.showCircleImage(mProfileImageUri.getPath(), mBinding.activitySignUpProfilePicIv);
        } else {
            Toaster.show(getString(R.string.no_image_selected));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            for (int grantResult : grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    Toaster.error("Need all permission granted!");
                    return;
                }
            }
            startImageChooser();
        }
    }
}
