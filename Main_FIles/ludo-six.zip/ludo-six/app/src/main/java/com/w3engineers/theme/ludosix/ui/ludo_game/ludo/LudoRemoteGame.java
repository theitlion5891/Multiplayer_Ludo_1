package com.w3engineers.theme.ludosix.ui.ludo_game.ludo;

import com.google.gson.Gson;

import java.util.ArrayList;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.keys.PreferenceKey;
import com.w3engineers.theme.ludosix.data.local.event.GameActionEvent;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.home.HomeActivity;
import com.w3engineers.theme.ludosix.ui.internet.InternetHomeActivity;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.GamePlayer;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.RemoteGame;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.actionMsg.GameAction;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.util.GameQueueProcessor;
import com.w3engineers.theme.util.helper.AndroidUtil;
import com.w3engineers.theme.util.helper.SharedPref;
import com.w3engineers.theme.util.helper.ToneFactory;
import com.w3engineers.theme.util.lib.internet.InternetConnectionManager;
import com.w3engineers.theme.util.lib.nearby.ConnectionManager;

import timber.log.Timber;

public class LudoRemoteGame extends RemoteGame {

    // the game's state
    private LudoState state;

    public LudoRemoteGame(ArrayList<Player> playerList) {
        state = new LudoState(playerList);
    }

    /**
     * send the updated state to a given player
     */
    @Override
    protected void sendUpdatedStateToPlayer() {
        player.sendInfo(state);
    }

    @Override
    public LudoState getCurrentGameState() {
        return state;
    }

    /**
     * canMove
     * can this player make a move
     *
     * @param playerIdx the player's player-number (ID)
     * @return true if matches
     */
    @Override
    protected boolean canMove(int playerIdx) {
        return playerIdx == state.getWhoseMove();
    }

    @Override
    protected boolean canMovePiece() {
        return state.getCanMovePiece();
    }

    /**
     * makeMove
     * this determines what moves can be made and verifies if the move made by the
     * player legal.
     *
     * @param action The move that the player has sent to the game
     * @return true if any move is possible
     */
    @Override
    protected boolean makeMove(GameAction action) {
        int playerID;
        //if its the person's turn and they are trying to make a move
        if (canMove(playerID = action.getPlayer().getPlayerInfo().getPlayerPosition())) {
            if (action instanceof ActionMoveToken && state.getCanMovePiece()) {
                //move forward, consider and react to landing on another piece
                animateToken(action.getPlayer(), ((ActionMoveToken) action).getIndex());
                return true;

            } else if (action instanceof ActionAnimateDice) {
                state.setAction(LudoState.Action.ANIMATE_DICE);
                state.setGamePlayer(action.getPlayer());
                sendUpdatedStateToPlayer();
                return true;

            } else if (action instanceof ActionRollDice && state.getIsRollable()) {
                state.setAction(null);
//                ToneFactory.on().stop();

                if (HomeActivity.mHostPlayer != null && !action.getPlayer().isProxy()) {
                    state.newRoll();
                    GameActionEvent gameActionEvent;
                    gameActionEvent = new GameActionEvent(action.getPlayer().getPlayerInfo().getPlayerBasePosition(),
                            GameActionEvent.Action.ROLL_DICE, state.getDiceVal());

                    String data = new Gson().toJson(gameActionEvent);
                    if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)) {
                        ConnectionManager.sendGameData(data, false, HomeActivity.mHostPlayer.getEndPointId());
                    }
                } else if (InternetHomeActivity.mHostPlayer != null && !action.getPlayer().isProxy()) {
                    state.newRoll();
                    GameActionEvent gameActionEvent;
                    gameActionEvent = new GameActionEvent(action.getPlayer().getPlayerInfo().getPlayerBasePosition(),
                            GameActionEvent.Action.ROLL_DICE, state.getDiceVal());

                    String data = new Gson().toJson(gameActionEvent);
                    if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)) {
                        InternetConnectionManager.sendGameData(data, false, InternetHomeActivity.mHostPlayer.getUserId());
                    }
                } else {
                    state.newCustomRoll(((ActionRollDice) action).getDiceVal());

                }

                //if the player can't make any moves
                if (state.getDiceVal() != 6 && state.getNumMovableTokens(playerID) == 0) {
                    state.setLastActivePlayer(state.getWhoseMove());
                    state.changePlayerTurn();

                    sendUpdatedStateToPlayer();
                    GameQueueProcessor.getInstance().forceProcessQueue();

                    return true;
                }
                //if the player rolls a six and doesn't have any pieces in start to bring out
                //and can't move any tokens
                if (state.getDiceVal() == 6 && state.getNumMovableTokens(playerID) == 0
                        && state.getTokenIndexOfFirstPieceInStart(playerID) == -1) {

                    state.setLastActivePlayer(state.getWhoseMove());
                    state.changePlayerTurn();

                    sendUpdatedStateToPlayer();
                    GameQueueProcessor.getInstance().forceProcessQueue();

                    return true;
                }

                state.setCanMovePiece(true);
                //if the player did not roll a six but can move a single piece
                if (state.getDiceVal() != 6 && state.getNumMovableTokens(playerID) == 1) {
                    state.setIsRollable(false);
                    int index = state.getTokenIndexOfFirstPieceOutOfStart(playerID);
                    animateToken(action.getPlayer(), index);
                    return true;
                }
                //if the player did not roll a six but can move multiple pieces
                if (state.getDiceVal() != 6 && state.getNumMovableTokens(playerID) > 1) {
                    state.setIsRollable(false);
                    state.setStillPlayersTurn(true);
                    sendUpdatedStateToPlayer();
                    GameQueueProcessor.getInstance().forceProcessQueue();

                    return true;
                }

                //if the player rolled a six but can only move one piece
                if (state.getDiceVal() == 6 && state.getNumMovableTokens(playerID) == 1
                        && state.getTokenIndexOfFirstPieceInStart(playerID) == -1) {
                    state.setStillPlayersTurn(true);
                    state.setIsRollable(false);
                    int index = state.getTokenIndexOfFirstPieceOutOfStart(playerID);
                    animateToken(action.getPlayer(), index);
                    return true;
                }

                //if the player rolls a six, let them take a piece out of base or move a piece
                if (state.getDiceVal() == 6) {
                    state.setStillPlayersTurn(true);
                    state.setIsRollable(false);
                    state.setCanBringOutOfStart(true);
                    sendUpdatedStateToPlayer();
                    GameQueueProcessor.getInstance().forceProcessQueue();

                    return true;
                }
            } else if (action instanceof ActionRemoveFromBase && state.getDiceVal() == 6 && state.isCanBringOutOfStart()) {
                //toggle boolean to false
                ToneFactory.on().play(R.raw.token_move);
//                state.changeMovableTokensHighlightState(playerID, false);

                state.pieces[((ActionRemoveFromBase) action).getIndex()].setIsHome(false);
                state.setIsRollable(true);
                state.setStillPlayersTurn(true);
                state.setCanBringOutOfStart(false);
                state.setCanMovePiece(false);
                sendUpdatedStateToPlayer();
                GameQueueProcessor.getInstance().forceProcessQueue();

                return true;

            } else if (action instanceof ActionAnimateToken) {
                int count = ((ActionAnimateToken) action).getCount();
                int index = ((ActionAnimateToken) action).getIndex();

                ToneFactory.on().play(R.raw.token_move);
                state.changeMovableTokensHighlightState(playerID, false);

                if (count == state.getDiceVal()) {
                    state.setShouldSkipActions(false);
                    state.advanceToken(playerID, index);

                    if (state.getAction() != LudoState.Action.ANIMATE_TOKEN_CUT) {
                        state.setAction(null);

                        sendUpdatedStateToPlayer();
                        checkIfGameOver();
                        GameQueueProcessor.getInstance().forceProcessQueue();
                    }

                } else {
                    state.setShouldSkipActions(true);
                    state.setAction(LudoState.Action.ANIMATE_TOKEN);

                    state.advanceToken(playerID, index);
                    state.setGamePlayer(action.getPlayer());

                    state.setIndex(index);
                    state.setCount(count);
                    sendUpdatedStateToPlayer();
                }

            } else if (action instanceof ActionAnimateTokenCut) {
                state.setShouldSkipActions(true);
                state.advanceToken(playerID, state.getIndex());
                sendUpdatedStateToPlayer();

                if (state.getAction() == null) {
                    GameQueueProcessor.getInstance().forceProcessQueue();
                }

            } else {
                GameQueueProcessor.getInstance().forceProcessQueue();
            }

        }

        return true; // do nothing since the move was not valid!
    }

    /**
     * checkIfGameOver
     * Check if the game is over / if the player has won.
     *
     * @return a message that tells who has won the game, or null if the
     * game is not over
     */
    @Override
    protected void checkIfGameOver() {
        for (int i = 0; i < state.getNumPlayers(); i++) {
            Timber.i("Player: " + players[i].getPlayerInfo().getPlayerPosition() + " Score: "
                    + state.getPlayerScore(players[i].getPlayerInfo().getPlayerPosition()));

            if (state.getPlayerScore(players[i].getPlayerInfo().getPlayerPosition()) == 4) {
                AndroidUtil.sleep(200);
                finishUpGame(players[i].getPlayerInfo());
            }
        }
    }

    private void animateToken(GamePlayer gamePlayer, int index) {
        state.setAction(LudoState.Action.ANIMATE_TOKEN);
        state.setIndex(index);
        state.setGame(getGame());

        state.setGamePlayer(gamePlayer);
        state.setCount(0);
        sendUpdatedStateToPlayer();
    }
}
