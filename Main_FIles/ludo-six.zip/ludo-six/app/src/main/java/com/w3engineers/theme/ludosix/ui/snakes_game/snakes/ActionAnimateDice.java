package com.w3engineers.theme.ludosix.ui.snakes_game.snakes;

import com.w3engineers.theme.ludosix.ui.snakes_game.game.GamePlayer;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.actionMsg.GameAction;

/**
 * ActionAnimateDice class
 * Game action that is sent to LudoLocalgame
 */
public class ActionAnimateDice extends GameAction {

    /**
     * constructor for GameAction
     *
     * @param player the player who created the action
     */
    public ActionAnimateDice(GamePlayer player) {
        super(player);
    }

}
