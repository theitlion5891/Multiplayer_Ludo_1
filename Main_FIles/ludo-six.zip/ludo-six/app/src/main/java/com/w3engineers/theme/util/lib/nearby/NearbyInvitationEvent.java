package com.w3engineers.theme.util.lib.nearby;

import com.left.core.util.lib.nearby.GameMessages.EndPoint;

import java.util.List;

/**
 * Created by pl@b0n on 11/20/2018.
 */
public class NearbyInvitationEvent {

    private InvitationPacketType type;
    private EndPoint endPoint;
    private List<EndPoint> endPoints;

    public NearbyInvitationEvent(InvitationPacketType type) {
        this.type = type;
    }

    public NearbyInvitationEvent(InvitationPacketType type, EndPoint endPoint) {
        this.type = type;
        this.endPoint = endPoint;
    }

    public NearbyInvitationEvent(InvitationPacketType type, List<EndPoint> endPointList) {
        this.type = type;
        this.endPoints = endPointList;
    }

    public NearbyInvitationEvent(InvitationPacketType type, List<EndPoint> endPointList, EndPoint endPoint) {
        this.type = type;
        this.endPoints = endPointList;
        this.endPoint = endPoint;
    }

    public InvitationPacketType getType() {
        return type;
    }

    public void setType(InvitationPacketType type) {
        this.type = type;
    }

    public EndPoint getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(EndPoint endPoint) {
        this.endPoint = endPoint;
    }


    public List<EndPoint> getEndPoints() {
        return endPoints;
    }

    public void setEndPoints(List<EndPoint> endPoints) {
        this.endPoints = endPoints;
    }
}
