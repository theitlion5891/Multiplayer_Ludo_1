package com.w3engineers.theme.ludosix.data.helper;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import androidx.work.Worker;
import androidx.work.WorkerParameters;
import com.w3engineers.theme.LudoSixApp;
import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.ui.splash.SplashActivity;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 1/28/2019 at 11:48 AM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Worker class of Work Manager
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 1/28/2019.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 1/28/2019.
 * Copyright (c) 2019, W3 Engineers Ltd. All rights reserved.
 */
public class NotifyWorker extends Worker {

    private static final int NOTIFICATION_ID = 123;

    public NotifyWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {

        try {
            if (!LudoSixApp.getIsAppRunning()) {
                notifyUser();
            }
            return Result.success();

        } catch (Throwable throwable) {
            return Result.retry();
        }
    }

    private void notifyUser() {

        // Create an explicit intent for an Activity in your app
        Intent intent = new Intent(getApplicationContext(), SplashActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);

        Uri soundUri = Uri.parse("android.resource://" + getApplicationContext().getPackageName() + "/" + R.raw.notification_sound);

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(getApplicationContext(), getApplicationContext().getString(R.string.channel_id))
                .setSmallIcon(R.drawable.ic_notification_small)
                .setLargeIcon(BitmapFactory.decodeResource(
                        getApplicationContext().getResources(),
                        R.drawable.ic_notification_large))
                .setContentTitle(getApplicationContext().getString(R.string.app_name))
                .setContentText(getApplicationContext().getString(R.string.notification_body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent) // Set the intent that will fire when the user taps the notification
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setDefaults(NotificationCompat.DEFAULT_VIBRATE | NotificationCompat.DEFAULT_LIGHTS)
                .setSound(soundUri)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(getApplicationContext());
        notificationManager.notify(NOTIFICATION_ID, mBuilder.build()); // notificationId is a unique int for each notification that you must define
    }
}
