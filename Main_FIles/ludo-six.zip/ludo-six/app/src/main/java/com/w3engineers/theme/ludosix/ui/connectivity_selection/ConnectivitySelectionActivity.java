package com.w3engineers.theme.ludosix.ui.connectivity_selection;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.keys.PreferenceKey;
import com.w3engineers.theme.ludosix.databinding.ActivityConnectivitySelectionBinding;
import com.w3engineers.theme.ludosix.databinding.ActivityGameSelectionBinding;
import com.w3engineers.theme.ludosix.ui.base.BaseActivity;
import com.w3engineers.theme.ludosix.ui.game_selection.GameSelectionActivity;
import com.w3engineers.theme.ludosix.ui.internet.InternetHomeActivity;
import com.w3engineers.theme.util.helper.AdHelper;
import com.w3engineers.theme.util.helper.NetworkUtil;
import com.w3engineers.theme.util.helper.SharedPref;
import com.w3engineers.theme.util.helper.Toaster;

public class ConnectivitySelectionActivity extends BaseActivity<ConnectivitySelectionMvpView, ConnectivitySelectionPresenter> implements ConnectivitySelectionMvpView{
    private ActivityConnectivitySelectionBinding mBinding;
    public final int LOCATION_SETTINGS_REQUEST = 300;

    /**
     * Start Activity (Pass value as a 2nd Parameter)
     * Date: 2018-03-13
     * Added By: Sudipta K Paik
     *
     * @param context
     **/
    public static void runActivity(Context context) {
        Intent intent = new Intent(context, ConnectivitySelectionActivity.class);
        runCurrentActivity(context, intent);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_connectivity_selection;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = (ActivityConnectivitySelectionBinding) getViewDataBinding();
        setClickListener(mBinding.activityGameSelectionLudoBtn, mBinding.activityGameSelectionSnakesBtn);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            init();
        }

        // Infinite float animation
        YoYo.with(Techniques.Bounce)
                .duration(8000)
                .repeat(-1)
                .playOn(mBinding.activityGameSelectionLudoBtn);

        // Infinite float animation
        YoYo.with(Techniques.Bounce)
                .duration(8000)
                .delay(3000)
                .repeat(-1)
                .playOn(mBinding.activityGameSelectionSnakesBtn);

        presenter.schedulePeriodicWork();

        // Load Banner ads
        AdHelper.loadBannerAd(this,(LinearLayout) mBinding.addLayout);
    }

    private void init() {
        LocationRequest mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(10 * 1000)
                .setFastestInterval(1 * 1000);

        LocationSettingsRequest.Builder settingsBuilder = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequest);
        settingsBuilder.setAlwaysShow(true);

        Task<LocationSettingsResponse> result = LocationServices.getSettingsClient(this)
                .checkLocationSettings(settingsBuilder.build());

        result.addOnCompleteListener(new OnCompleteListener<LocationSettingsResponse>() {
            @Override
            public void onComplete(@NonNull Task<LocationSettingsResponse> task) {
                try {
                    LocationSettingsResponse response =
                            task.getResult(ApiException.class);
                } catch (ApiException ex) {
                    switch (ex.getStatusCode()) {
                        case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                            try {
                                ResolvableApiException resolvableApiException =
                                        (ResolvableApiException) ex;
                                resolvableApiException
                                        .startResolutionForResult(ConnectivitySelectionActivity.this,
                                                LOCATION_SETTINGS_REQUEST);
                            } catch (IntentSender.SendIntentException e) {

                            }
                            break;
                        case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:

                            break;
                    }
                }
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == LOCATION_SETTINGS_REQUEST) {

            }
        }
    }

    @Override
    public void onClick(View view) {
        String connectivityStatus = view.getTag().toString();
        if (connectivityStatus.equalsIgnoreCase(getResources().getString(R.string.offline))){
            SharedPref.write(PreferenceKey.IS_INTERNET_GAME, false);
            GameSelectionActivity.runActivity(this);
        }else {
            //TODO: Need to check internet connectivity before launch online
            if (NetworkUtil.isNetworkConnected(this)){
                SharedPref.write(PreferenceKey.IS_INTERNET_GAME, true);
                GameSelectionActivity.runActivity(this);
            }else {
                Toaster.info("Need internet connection to play online");
            }

        }
    }

    @Override
    protected void startUI() {

    }

    @Override
    protected void stopUI() {

    }

    @Override
    protected ConnectivitySelectionPresenter initPresenter() {
        return new ConnectivitySelectionPresenter();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.right_in, R.anim.right_out);
    }
}
