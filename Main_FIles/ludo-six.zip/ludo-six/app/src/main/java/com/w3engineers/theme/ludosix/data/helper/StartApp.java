package com.w3engineers.theme.ludosix.data.helper;

import android.content.Context;
import android.os.AsyncTask;

//import com.facebook.stetho.Stetho;

import com.w3engineers.theme.ludosix.BuildConfig;
import com.w3engineers.theme.ludosix.data.remote.RemoteApi;
import com.w3engineers.theme.ludosix.data.remote.helper.RemoteApiOption;
import com.w3engineers.theme.util.helper.Notify;
import com.w3engineers.theme.util.helper.PermissionUtil;
import com.w3engineers.theme.util.helper.SharedPref;
import com.w3engineers.theme.util.helper.Toaster;
import timber.log.Timber;

/**
 * * ============================================================================
 * * Copyright (C) 2018 W3 Engineers Ltd - All Rights Reserved.
 * * Unauthorized copying of this file, via any medium is strictly prohibited
 * * Proprietary and confidential
 * * ----------------------------------------------------------------------------
 * * Created by: Sudipta K Paik on [13-Jul-2018 at 4:18 PM].
 * * Email: sudipta@w3engineers.com
 * * ----------------------------------------------------------------------------
 * * Project: Generic API.
 * * Code Responsibility: <Purpose of code>
 * * ----------------------------------------------------------------------------
 * * Edited by :
 * * --> <First Editor> on [13-Jul-2018 at 4:18 PM].
 * * --> <Second Editor> on [13-Jul-2018 at 4:18 PM].
 * * ----------------------------------------------------------------------------
 * * Reviewed by :
 * * --> <First Reviewer> on [13-Jul-2018 at 4:18 PM].
 * * --> <Second Reviewer> on [13-Jul-2018 at 4:18 PM].
 * * ============================================================================
 **/

public class StartApp {
    private static Context sContext;

    public synchronized void init(Context context) {
        sContext = context;

        new InitRemoteAsync().execute();
    }

    private class InitRemoteAsync extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            RemoteHelper.init();

            RemoteApiOption remoteApiOption = new RemoteApiOption(true);
            remoteApiOption.setStartRightMesh(false);

            RemoteApi.init(sContext, remoteApiOption);

            releaseLoader(sContext);
            debugLoader(sContext);

            return null;
        }
    }

    private void debugLoader(Context context) {
        if (!BuildConfig.DEBUG) return;

        Timber.plant(new Timber.DebugTree());
    }

    private void releaseLoader(Context context) {
        Toaster.init(context);
        SharedPref.init(context);
        Notify.init(context);
        PermissionUtil.init(context);
    }
}
