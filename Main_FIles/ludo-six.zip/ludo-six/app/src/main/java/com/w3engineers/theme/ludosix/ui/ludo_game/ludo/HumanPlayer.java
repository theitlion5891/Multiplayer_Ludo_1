package com.w3engineers.theme.ludosix.ui.ludo_game.ludo;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.keys.PreferenceKey;
import com.w3engineers.theme.ludosix.data.local.event.GameActionEvent;
import com.w3engineers.theme.ludosix.data.local.model.Message;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.GameHumanPlayer;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.GameMainActivity;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.GamePlayer;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.actionMsg.GameAction;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.ChatMessageInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.GameInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.IllegalMoveInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.NotYourTurnInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.util.ChatMessageProcessor;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.util.GameQueueProcessor;
import com.w3engineers.theme.util.helper.Glider;
import com.w3engineers.theme.util.helper.HandlerUtil;
import com.w3engineers.theme.util.helper.SharedPref;
import com.w3engineers.theme.util.helper.Toaster;
import com.w3engineers.theme.util.helper.ToneFactory;
import com.w3engineers.theme.util.lib.internet.InternetConnectionManager;
import com.w3engineers.theme.util.lib.nearby.ConnectionManager;

/**
 * HumanPlayer
 * The human determines, through this class, which actions to send
 * specifically: which piece they want moved and if they roll a dice.
 */

public class HumanPlayer extends GameHumanPlayer implements View.OnClickListener, View.OnTouchListener {

    private LudoSurfaceView surfaceView;
    private LinearLayout chatBoxLayout;
    private View popupView;

    private ImageView dicePlayer1, dicePlayer2, dicePlayer3, dicePlayer4;
    private List<TextView> nameViews = new ArrayList<>();

    // most recent state, an appropriately filled view of the game as given to us from LudoLocalGame
    private LudoState state;

    // the android activity that we are running
    private GameMainActivity myActivity;
    private boolean canTouchToken = false;

    private boolean shouldHighlightToken;
    private Handler handler = new Handler();
    private PopupWindow popupWindow;


    /**
     * constructor
     *
     * @param playerInfo is the info of the player
     */
    public HumanPlayer(Player playerInfo) {
        super(playerInfo);
    }

    /**
     * setAsGui
     *
     * @param activity GameMainActivity object
     *                 Sets this player as the one attached to the GUI. Saves the
     *                 activity, links listeners to IO to invoke specific methods.
     */
    @Override
    public void setAsGui(GameMainActivity activity) {
        //remember the activity
        myActivity = activity;
        activity.setContentView(R.layout.ludo_board);

        //find references
        surfaceView = activity.findViewById(R.id.ludo_board_surface_view);
        chatBoxLayout = activity.findViewById(R.id.ludo_board_chatbox_ll);
        createPopupWindow();

        // Showing emoji button based on players
        activity.findViewById(R.id.ludo_board_emoji_icon).setVisibility(getShouldShowEmoji() ? View.VISIBLE : View.GONE);

        dicePlayer1 = activity.findViewById(R.id.ludo_board_red_dice_iv);
        dicePlayer2 = activity.findViewById(R.id.ludo_board_blue_dice_iv);
        dicePlayer3 = activity.findViewById(R.id.ludo_board_yellow_dice_iv);
        dicePlayer4 = activity.findViewById(R.id.ludo_board_green_dice_iv);

        nameViews.add(activity.findViewById(R.id.ludo_board_player1_name_tv));
        nameViews.add(activity.findViewById(R.id.ludo_board_player2_name_tv));
        nameViews.add(activity.findViewById(R.id.ludo_board_player3_name_tv));
        nameViews.add(activity.findViewById(R.id.ludo_board_player4_name_tv));

        for (int i = 0; i < activity.getGamePlayers().length; i++) {
            GamePlayer gamePlayer = activity.getGamePlayers()[i];
            nameViews.get(gamePlayer.getPlayerInfo().getPlayerPosition()).setText(gamePlayer.getPlayerInfo().getName());
        }

        //set the listeners
        surfaceView.setOnTouchListener(this);
        dicePlayer3.setOnClickListener(this);

        // Home button click listener
        activity.findViewById(R.id.ludo_board_home_btn).setOnClickListener(view -> activity.onBackPressed());

        // Emoji text click listener
        activity.findViewById(R.id.ludo_board_emoji_icon).setOnClickListener(view -> showPopup(dicePlayer2));
    }

    private boolean getShouldShowEmoji() {

        for (GamePlayer player : myActivity.getGamePlayers()) {
            if (player.isProxy()) {
                return true;
            }
        }

        return false;
    }

    /**
     * getTopview
     *
     * @return the gui that is displayed currenty.
     */
    @Override
    public View getTopView() {
        return myActivity.findViewById(R.id.ludo_board_parent_cl);
    }

    /**
     * Callback method, called when player gets a message
     *
     * @param info the message
     */
    @Override
    public void receiveInfo(GameInfo info) {

        if (info instanceof ChatMessageInfo) {
            processMessage(((ChatMessageInfo) info).getMessage());

        } else {
            if (surfaceView == null) return;
            if (info instanceof IllegalMoveInfo || info instanceof NotYourTurnInfo) {
                // if the move was out of turn or otherwise illegal, flash the screen
                //surfaceView.flash(Color.RED, 50);
            } else if (!(info instanceof LudoState)) {
                // if we do not have a LudoState, ignore
                return;

            } else {
                state = (LudoState) info;
                ImageView playerDice = getPlayerImageView(state.getWhoseMove());
                ImageView selfDice = getPlayerImageView(playerNum);

                if (selfDice != null) {
                    selfDice.setBackgroundResource(R.drawable.ic_dice_back_highlighted);

                    if (state.getWhoseMove() == playerNum && state.getIsRollable()) {

                        Animation animation = new AlphaAnimation(1f, 0.3f); // Change alpha from fully visible to invisible
                        animation.setDuration(200); // duration - half a second
                        animation.setInterpolator(new LinearInterpolator()); // do not alter animation rate
                        animation.setRepeatCount(Animation.INFINITE); // Repeat animation infinitely
                        animation.setRepeatMode(Animation.REVERSE); // Reverse animation at the end so the button will fade back in
                        selfDice.startAnimation(animation);

                    } else {
                        selfDice.clearAnimation();
                    }
                }

                dicePlayer4.setClickable(false);
                dicePlayer1.setAlpha(0.3f);
                dicePlayer2.setAlpha(0.3f);
                dicePlayer3.setAlpha(0.3f);
                dicePlayer4.setAlpha(0.3f);

                if (playerDice != null) {
                    playerDice.setAlpha(1f);
                    playerDice.setClickable(true);
                }

                if (!state.getStillPlayersTurn() && state.getAction() == null) {
                    setDiceImage(state.getLastActivePlayer(), state.getDiceVal());
                }

                setDiceImage(state.getWhoseMove(), state.getDiceVal());

                if (state.getWhoseMove() == this.playerNum) {
                    canTouchToken = state.getCanMovePiece();

                    if (canTouchToken && state.getAction() == null) {
                        handler.postDelayed(tokenHighlightRunnable, 200);

                    } else {
                        surfaceView.setState(state);
                        surfaceView.invalidate();
                    }

                } else {
                    surfaceView.setState(state);
                    surfaceView.invalidate();
                }

                if (state.getAction() != null) {

                    switch (state.getAction()) {
                        case ANIMATE_DICE:
                            if (selfDice != null)
                                selfDice.clearAnimation();

                            ToneFactory.on().play(R.raw.dice_roll);
                            Glider.showGifImage(R.drawable.ic_rolling_dice, getPlayerImageView(state.getWhoseMove()));

                            if (!state.getGamePlayer().isProxy()) {
                                HandlerUtil.postForeground(() -> game.sendAction(new ActionRollDice(state.getGamePlayer())), 800);

                            } else {
                                HandlerUtil.postForeground(() -> GameQueueProcessor.getInstance().forceProcessQueue(), 500);
                            }

                            break;

                        case ANIMATE_TOKEN:
                            game.sendAction(new ActionAnimateToken(state.getGamePlayer(), state.getIndex(), state.getCount() + 1));
                            break;

                        case ANIMATE_TOKEN_CUT:
                            game.sendAction(new ActionAnimateTokenCut(state.getGamePlayer()));
                            break;
                    }
                }
            }
        }
    }

    private void createPopupWindow() {
        LayoutInflater layoutInflater = (LayoutInflater) myActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        popupView = layoutInflater.inflate(R.layout.dialog_emoji, null);

        popupWindow = new PopupWindow(popupView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        popupWindow.setOutsideTouchable(true);
    }

    private void showPopup(View anchorView) {

        if (!popupWindow.isShowing()) {
            popupWindow.showAsDropDown(anchorView, 0, 0, Gravity.END);
        }

        popupView.findViewById(R.id.dialog_emoji_text1).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text2).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text3).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text4).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text5).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text6).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text7).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text8).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text9).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text10).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text11).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text12).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text13).setOnClickListener(this);
        popupView.findViewById(R.id.dialog_emoji_text14).setOnClickListener(this);

        ImageView emoji1 = popupView.findViewById(R.id.dialog_emoji_icon1);
        emoji1.setOnClickListener(this);
        emoji1.setTag(R.drawable.emoji1);

        ImageView emoji2 = popupView.findViewById(R.id.dialog_emoji_icon2);
        emoji2.setOnClickListener(this);
        emoji2.setTag(R.drawable.emoji2);

        ImageView emoji3 = popupView.findViewById(R.id.dialog_emoji_icon3);
        emoji3.setOnClickListener(this);
        emoji3.setTag(R.drawable.emoji3);

        ImageView emoji4 = popupView.findViewById(R.id.dialog_emoji_icon4);
        emoji4.setOnClickListener(this);
        emoji4.setTag(R.drawable.emoji4);

        ImageView emoji5 = popupView.findViewById(R.id.dialog_emoji_icon5);
        emoji5.setOnClickListener(this);
        emoji5.setTag(R.drawable.emoji5);

        ImageView emoji6 = popupView.findViewById(R.id.dialog_emoji_icon6);
        emoji6.setOnClickListener(this);
        emoji6.setTag(R.drawable.emoji6);

        ImageView emoji7 = popupView.findViewById(R.id.dialog_emoji_icon7);
        emoji7.setOnClickListener(this);
        emoji7.setTag(R.drawable.emoji7);

        ImageView emoji8 = popupView.findViewById(R.id.dialog_emoji_icon8);
        emoji8.setOnClickListener(this);
        emoji8.setTag(R.drawable.emoji8);

    }

    private Runnable tokenHighlightRunnable = new Runnable() {
        @Override
        public void run() {
            if (canTouchToken && state.getWhoseMove() == playerNum) {

                shouldHighlightToken = !shouldHighlightToken;
                state.changeMovableTokensHighlightState(playerNum, shouldHighlightToken);

                surfaceView.setState(state);
                surfaceView.invalidate();

                handler.postDelayed(tokenHighlightRunnable, 200);
            }
        }
    };

    /**
     * onTouch
     * determines if a piece was touched or not
     *
     * @param v     View object
     * @param event Event Object
     * @return Always returns true
     */
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        //make sure that the thing that was touched was the surface view
        if (v.getId() == surfaceView.getId()) {
            if (state != null && state.getWhoseMove() == this.playerNum) {
                float xTouch = event.getX();
                float yTouch = event.getY();
                float width = surfaceView.getWidth();
                float box = width / 15;
                //create instance of gameAction
                GameAction action;
                int index;
                index = getIndexOfPieceTouched(xTouch, yTouch, box);
                if (index == -1) {
                    Log.i("OnTouch", "No piece was pressed");
                } else {
                    //Checks to see if the the user touched inside the homebase
                    Log.i("OnTouch", "The piece that was touched was: " + index);
                    if (!checkIfAHomeBaseWasTouched(xTouch, yTouch, box)) { //the user is trying to move a piece forward
                        action = new ActionMoveToken(this, index);

                        if (canTouchToken) {
                            canTouchToken = false;

                            handler.removeCallbacks(tokenHighlightRunnable);
                            state.changeMovableTokensHighlightState(playerNum, false);

                            surfaceView.setState(state);
                            surfaceView.invalidate();
                            game.sendAction(action);
                        }
                    } else { // the user is trying to move a piece out of start base
                        //TODO I CHANGED  THIS!
                        if (state.getTokenIndexOfFirstPieceInStart(playerNum) != -1) {
                            action = new ActionRemoveFromBase(this, index);

                            handler.removeCallbacks(tokenHighlightRunnable);
                            state.changeMovableTokensHighlightState(playerNum, false);

                            surfaceView.setState(state);
                            surfaceView.invalidate();
                            game.sendAction(action);

                        }
                    }
                }
            }
        }
        return true;
    }

    /**
     * getIndexOfPieceTouched
     * Each peice has an index, this method gets that index
     *
     * @param xTouch
     * @param yTouch
     * @param box
     * @return
     */
    public int getIndexOfPieceTouched(float xTouch, float yTouch, float box) {
        boolean aHomeBaseWasTouched = checkIfAHomeBaseWasTouched(xTouch, yTouch, box);
        int playerID = this.playerNum;
        float xPos, yPos;
        for (int i = (playerID * 4); i < (playerID * 4 + 4); i++) {//traverse through the pieces the player owns
            if (!aHomeBaseWasTouched) {//check the board tiles
                if (!state.pieces[i].getIsHome()) {
                    xPos = (state.pieces[i].getCurrentXLoc() * box);
                    yPos = (state.pieces[i].getCurrentYLoc() * box);
                    if ((xTouch >= xPos) && (xTouch <= (xPos + box))) {
                        if ((yTouch >= yPos) && (yTouch <= (yPos + box))) {
                            return i;
                        }
                    }
                }
            } else {//check the pieces in the start tiles
                xPos = (float) state.pieces[i].getStartXPos() * box;
                yPos = (float) state.pieces[i].getStartYPos() * box;
                if ((xTouch >= xPos) && (xTouch <= (xPos + (box + (box / 2))))) {
                    if ((yTouch >= yPos) && (yTouch <= (yPos + (box + (box / 2))))) {
                        return i;
                    }
                }
            }
        }
        return -1;//return negative 1 if no pieces were pressed!
    }

    /**
     * checkIfAHomeBaseWasTouched
     *
     * @param xTouch
     * @param yTouch
     * @param box
     * @return
     */
    public boolean checkIfAHomeBaseWasTouched(float xTouch, float yTouch, float box) {
        //first check if the coordinates touched were in start base or actually on the board coordinates
        if ((xTouch > (box * 0)) && (xTouch < (box * 6)) && (yTouch > (box * 0)) && (yTouch < (box * 6))) {
            return true;
        } else if ((xTouch > (box * 9)) && (xTouch < (box * 15)) && (yTouch > (box * 0)) && (yTouch < (box * 6))) {
            return true;
        } else if ((xTouch > (box * 0)) && (xTouch < (box * 6)) && (yTouch > (box * 9)) && (yTouch < (box * 15))) {
            return true;
        } else if ((xTouch > (box * 9)) && (xTouch < (box * 15)) && (yTouch > (box * 9)) && (yTouch < (box * 15))) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * onClick
     * Rolls the dice
     *
     * @param v a view object
     */
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ludo_board_yellow_dice_iv) {

            // Create instance of gameAction associated with button pressed
            if (state != null) {
                if (state.getWhoseMove() == this.playerNum && state.getIsRollable()) {
                    ToneFactory.on().play(R.raw.dice_roll);
                    game.sendAction(new ActionAnimateDice(this));

                } else if (state.getWhoseMove() == this.playerNum && state.getCanMovePiece()) {
                    Toaster.info("Please move your token!");
                }
            }

        } else {
            popupWindow.dismiss();
            Message message;

            if (v instanceof TextView) {
                message = new Message(playerInfo.getName(), ((TextView) v).getText().toString(), Message.Type.TEXT);

            } else {
                message = new Message(playerInfo.getName(), (Integer) v.getTag(), Message.Type.ICON);
            }

            GameActionEvent gameActionEvent = new GameActionEvent(playerInfo.getPlayerPosition(), message, GameActionEvent.Action.CHAT_MESSAGE);
            String data = new Gson().toJson(gameActionEvent);

            for (GamePlayer playerToSend : myActivity.getGamePlayers()) {
                if (playerToSend.isProxy()) {
                    if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
                        ConnectionManager.sendGameData(data, false, playerToSend.getPlayerInfo().getEndPointId());
                    }else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
                        InternetConnectionManager.sendGameData(data, false, playerToSend.getPlayerInfo().getUserId());
                    }

                }
            }

            processMessage(message);
        }
    }

    private void processMessage(Message message) {
        ChatMessageProcessor.getInstance().addMessage(message);

        if (chatBoxLayout.getChildCount() >= 4) {
            ChatMessageProcessor.getInstance().removeLastMessage();
        }

        chatBoxLayout.removeAllViews();
        chatBoxLayout.setVisibility(View.VISIBLE);

        for (View view : ChatMessageProcessor.getInstance().getChatMessageViews(myActivity)) {
            chatBoxLayout.addView(view);
        }

    }


    private ImageView getPlayerImageView(int whoseMove) {
        switch (whoseMove) {
            case 0:
                return dicePlayer1;

            case 1:
                return dicePlayer2;

            case 2:
                return dicePlayer3;

            case 3:
                return dicePlayer4;

            default:
                return null;
        }
    }

    private void setDiceImage(int whoseMove, int diceVal) {
        ImageView imageView = getPlayerImageView(whoseMove);

        if (imageView != null)
            switch (diceVal) {
                case 1:
                    imageView.setImageResource(R.drawable.ic_white_dice_side1);
                    break;

                case 2:
                    imageView.setImageResource(R.drawable.ic_white_dice_side2);
                    break;

                case 3:
                    imageView.setImageResource(R.drawable.ic_white_dice_side3);
                    break;

                case 4:
                    imageView.setImageResource(R.drawable.ic_white_dice_side4);
                    break;

                case 5:
                    imageView.setImageResource(R.drawable.ic_white_dice_side5);
                    break;

                case 6:
                    imageView.setImageResource(R.drawable.ic_white_dice_side6);
                    break;
            }
    }
}
