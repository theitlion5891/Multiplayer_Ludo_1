package com.w3engineers.theme.ludosix.data.remote.s3api;

import android.content.Context;

import java.io.File;

import com.w3engineers.theme.ludosix.data.remote.helper.callback.FileTransferCallback;
import com.w3engineers.theme.ludosix.data.remote.s3api.helper.S3FileUploader;
import com.w3engineers.theme.ludosix.data.remote.s3api.helper.S3FileUploaderListener;

/**
 * * ============================================================================
 * * Copyright (C) 2018 W3 Engineers Ltd - All Rights Reserved.
 * * Unauthorized copying of this file, via any medium is strictly prohibited
 * * Proprietary and confidential
 * * ----------------------------------------------------------------------------
 * * Created by: Sudipta K Paik on [16-Jul-2018 at 10:55 AM].
 * * Email: sudipta@w3engineers.com
 * * ----------------------------------------------------------------------------
 * * Project: Generic API.
 * * Code Responsibility: <Purpose of code>
 * * ----------------------------------------------------------------------------
 * * Edited by :
 * * --> <First Editor> on [16-Jul-2018 at 10:55 AM].
 * * --> <Second Editor> on [16-Jul-2018 at 10:55 AM].
 * * ----------------------------------------------------------------------------
 * * Reviewed by :
 * * --> <First Reviewer> on [16-Jul-2018 at 10:55 AM].
 * * --> <Second Reviewer> on [16-Jul-2018 at 10:55 AM].
 * * ============================================================================
 **/
public class S3Manager {
    private static volatile S3Manager ourInstance;
    private static Object mutex = new Object();
    private static Context sContext = null;


    private S3Manager() {
    }

    public synchronized static void init(Context context) {
        sContext = context;

        synchronized (mutex) {
            if (ourInstance == null)
                ourInstance = new S3Manager();
        }


    }

    public static S3Manager on() {
        return ourInstance;
    }

    public void uploadFile(String url, String file_key, File file, final FileTransferCallback callback) {
        S3FileUploader.getInstance().uploadToServer(file, url, new S3FileUploaderListener() {
            @Override
            public void onFileUploadSuccess(String filePath) {
                callback.onFileUploadSuccess(filePath);
            }

            @Override
            public void onFileUploadFailed(String filePath, int reason) {
                callback.onFileUploadFailed(filePath, reason);
            }

            @Override
            public void onFileUploadProgress(String filePath, int percentage) {
                callback.onFileUploadProgress(filePath, percentage);
            }
        });
    }
}