package com.w3engineers.theme.util.lib.internet.model;

import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetDataType;

public class DataModel {
    InternetDataType internetDataType;
    InvitationModel invitationModel;
    GameDataModel gameDataModel;
    GameSettingsModel gameSettingsModel;
    ImageFileNameModel  imageFileNameModel;
    Player senderId;

    public DataModel() {
    }

    public DataModel(InternetDataType internetDataType, InvitationModel invitationModel, GameDataModel gameDataModel, GameSettingsModel gameSettingsModel, ImageFileNameModel imageFileNameModel, Player senderId) {
        this.internetDataType = internetDataType;
        this.invitationModel = invitationModel;
        this.gameDataModel = gameDataModel;
        this.gameSettingsModel = gameSettingsModel;
        this.imageFileNameModel = imageFileNameModel;
        this.senderId = senderId;
    }

    public InternetDataType getInternetDataType() {
        return internetDataType;
    }

    public void setInternetDataType(InternetDataType internetDataType) {
        this.internetDataType = internetDataType;
    }

    public InvitationModel getInvitationModel() {
        return invitationModel;
    }

    public void setInvitationModel(InvitationModel invitationModel) {
        this.invitationModel = invitationModel;
    }

    public GameDataModel getGameDataModel() {
        return gameDataModel;
    }

    public void setGameDataModel(GameDataModel gameDataModel) {
        this.gameDataModel = gameDataModel;
    }

    public GameSettingsModel getGameSettingsModel() {
        return gameSettingsModel;
    }

    public void setGameSettingsModel(GameSettingsModel gameSettingsModel) {
        this.gameSettingsModel = gameSettingsModel;
    }

    public ImageFileNameModel getImageFileNameModel() {
        return imageFileNameModel;
    }

    public void setImageFileNameModel(ImageFileNameModel imageFileNameModel) {
        this.imageFileNameModel = imageFileNameModel;
    }

    public Player getSenderId() {
        return senderId;
    }

    public void setSenderId(Player senderId) {
        this.senderId = senderId;
    }
}
