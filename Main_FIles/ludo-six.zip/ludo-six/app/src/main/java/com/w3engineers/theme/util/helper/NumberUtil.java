package com.w3engineers.theme.util.helper;

import android.content.Context;

import java.text.DecimalFormat;

import com.w3engineers.theme.ludosix.R;

/*
* ****************************************************************************
* * Copyright © 2018 W3 Engineers Ltd., All rights reserved.
* *
* * Created by:
* * Name : SUDIPTA KUMAR PAIK
* * Date : 2/14/18
* * Email : sudipta@w3engineers.com
* *
* * Purpose: NumberUtil for all type of number processing
* *
* * Last Edited by : SUDIPTA KUMAR PAIK on 2/14/18.
* * History:
* * 1:
* * 2:
* *
* * Last Reviewed by : SUDIPTA KUMAR PAIK on 2/14/18.
* ****************************************************************************
*/

public class NumberUtil {
    private static final String DECIMAL_PATTERN = "##.########";

    public static String DecimalFormat(double value) {
        return new DecimalFormat(DECIMAL_PATTERN).format(value);
    }

    public static String textViewLocation(Context context, double myLat, double myLang) {
        if(context == null) return "";

        return String.format(context.getString(R.string.splitter_space) +
                new DecimalFormat(DECIMAL_PATTERN).format(myLat) +
                context.getString(R.string.splitter_semicolon) +
                new DecimalFormat(DECIMAL_PATTERN).format(myLang));
    }
}
