package com.w3engineers.theme.ludosix.data.local.event;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 12/3/2018 at 1:54 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Event class for dice roll
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 12/3/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 12/3/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class DiceRollEvent {

    private int diceVal;
    private int whoseMove;

    public DiceRollEvent(int whoseMove) {
        this.whoseMove = whoseMove;
    }

    public int getWhoseMove() {
        return whoseMove;
    }

    public void setWhoseMove(int whoseMove) {
        this.whoseMove = whoseMove;
    }

    public int getDiceVal() {
        return diceVal;
    }

    public void setDiceVal(int diceVal) {
        this.diceVal = diceVal;
    }
}
