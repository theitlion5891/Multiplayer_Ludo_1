package com.w3engineers.theme.ludosix.data.local.event;

import com.w3engineers.theme.ludosix.data.local.model.Message;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 12/12/2018 at 10:45 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Event class for game actions
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 12/12/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 12/12/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class GameActionEvent {

    public interface Action {
        int ROLL_DICE = 1;
        int MOVE_TOKEN = 2;
        int REMOVE_FROM_BASE = 3;
        int LEFT_GAME = 4;
        int ANIMATE_DICE = 5;
        int CHAT_MESSAGE = 6;
    }

    private int playerId;
    private String userId;
    private int action;
    private int index;
    private Message message;

    public GameActionEvent(int playerId, Message message, int action) {
        this.playerId = playerId;
        this.message = message;
        this.action = action;
    }

    public GameActionEvent(String userId, int action) {
        this.userId = userId;
        this.action = action;
    }

    public GameActionEvent(int playerId, int action) {
        this.playerId = playerId;
        this.action = action;
    }

    public GameActionEvent(int playerId, int action, int index) {
        this.playerId = playerId;
        this.action = action;
        this.index = index;
    }

    public int getPlayerId() {
        return playerId;
    }

    public void setPlayerId(int playerId) {
        this.playerId = playerId;
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }
}
