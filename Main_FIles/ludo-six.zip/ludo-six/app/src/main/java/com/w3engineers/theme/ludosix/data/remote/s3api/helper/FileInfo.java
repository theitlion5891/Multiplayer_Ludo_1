package com.w3engineers.theme.ludosix.data.remote.s3api.helper;

/*
 *  ****************************************************************************
 *  * Created by : Ahmed Mohmmad Ullah (Azim) on 5/8/2018 at 12:10 PM.
 *  * Email : azim@w3engineers.com
 *  *
 *  * Last edited by : Ahmed Mohmmad Ullah (Azim) on 5/8/2018.
 *  *
 *  * Last Reviewed by : <Reviewer Name> on <mm/dd/yy>
 *  ****************************************************************************
 */

import android.net.Uri;

public class FileInfo {

    public String name, filePath;
    public long size;
    public Uri fileUri;

}
