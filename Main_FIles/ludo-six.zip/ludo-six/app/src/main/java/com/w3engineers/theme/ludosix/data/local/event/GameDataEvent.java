package com.w3engineers.theme.ludosix.data.local.event;

import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.GameInfo;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 12/3/2018 at 1:54 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Event class for game state change
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 12/3/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 12/3/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class GameDataEvent {

    private GameActionEvent gameAction;
    private GameInfo gameInfo;
    private boolean isGameInfo;

    public  GameDataEvent(GameActionEvent gameAction, boolean isGameInfo) {
        this.gameAction = gameAction;
        this.isGameInfo = isGameInfo;
    }

    public GameDataEvent(GameInfo gameInfo, boolean isGameInfo) {
        this.gameInfo = gameInfo;
        this.isGameInfo = isGameInfo;
    }

    public GameInfo getGameInfo() {
        return gameInfo;
    }

    public void setGameInfo(GameInfo gameInfo) {
        this.gameInfo = gameInfo;
    }

    public void setGameAction(GameActionEvent gameAction) {
        this.gameAction = gameAction;
    }

    public GameActionEvent getGameAction() {
        return gameAction;
    }

    public boolean isGameInfo() {
        return isGameInfo;
    }

    public void setIsGameInfo(boolean gameInfo) {
        isGameInfo = gameInfo;
    }

}
