package com.w3engineers.theme.ludosix.ui.ludo_game.ludo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import androidx.core.graphics.PathParser;

import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.SparseArray;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.util.FlashSurfaceView;
import com.w3engineers.theme.util.lib.nearby.ConnectivityProvider;

/**
 * LudoSurfaceView
 * This draws the entire board, all the pieces, and the dice.
 * It also updates the board according to touch events and button presses * *
 */

public class LudoSurfaceView extends FlashSurfaceView {

    //instance variables
    protected LudoState mState = new LudoState(new ArrayList<>());
    private boolean[] mIsDrawn;
    List<Token> outOfHomeTokens = new ArrayList<>();
    private static SparseArray<Bitmap> resourceMap = new SparseArray<>();

    //Creating Color Objects
    private Paint greenPaint = new Paint();
    private Paint greenPaint2 = new Paint();
    private Paint redPaint = new Paint();
    private Paint redPaint2 = new Paint();
    private Paint bluePaint = new Paint();
    private Paint bluePaint2 = new Paint();
    private Paint yellowPaint = new Paint();
    private Paint yellowPaint2 = new Paint();
    private Paint whitePaint = new Paint();
    private Paint transparentPaint = new Paint();
    private Paint blackStrokePaint = new Paint();
    private Paint ashPaint = new Paint();

    /**
     * Constructors
     */
    public LudoSurfaceView(Context context) {
        super(context);
        setWillNotDraw(false);
    }

    public LudoSurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);
    }

    public void setState(LudoState mState) {
        this.mState = mState;
    }

    private Bitmap createResMap(int resId) {
        resourceMap.put(resId, BitmapFactory.decodeResource(getResources(), resId));
        return resourceMap.get(resId);
    }

    private Bitmap getBitmapFromResMap(int resId) {
        return resourceMap.get(resId) != null ? resourceMap.get(resId) : createResMap(resId);
    }

    /**
     * onDraw
     * the starting place for all drawing that takes place
     * implements the use of helper methods.
     *
     * @param canvas - draw on this
     */
    @Override
    public void onDraw(Canvas canvas) {

        //define the canvas instance variables
        float heightAndWidth = getWidth();//height and width are the same because the surface view is a square
        float box = heightAndWidth / 15;

        //Creating the colors
        redPaint.setColor(Color.rgb(220, 34, 38));
        redPaint2.setColor(Color.rgb(198, 32, 30));
        greenPaint.setColor(Color.rgb(7, 140, 67));
        greenPaint2.setColor(Color.rgb(0, 121, 32));
        bluePaint.setColor(Color.rgb(54, 87, 161));
        bluePaint2.setColor(Color.rgb(41, 128, 199));

        yellowPaint.setColor(Color.rgb(242, 186, 20));
        yellowPaint2.setColor(Color.rgb(209, 144, 25));
        ashPaint.setColor(Color.rgb(193, 193, 193));
        whitePaint.setColor(Color.WHITE);

        transparentPaint.setColor(Color.rgb(255, 212, 85));
        transparentPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        transparentPaint.setStrokeWidth(3);

        blackStrokePaint.setColor(Color.BLACK);
        blackStrokePaint.setStyle(Paint.Style.STROKE);
        blackStrokePaint.setStrokeWidth(3);

        //draw the white background
        this.setBackgroundColor(Color.WHITE);

        //Drawing all HomeStretch and Opening Tiles
        float i, j;
        for (i = box; i < (box * 6); i = i + box) {
            j = (box * 7);
            canvas.drawRect(i, j, i + box, j + box, getPaintBasedOnPlayer(0));
        } //Red Homestretch
        canvas.drawRect(box, (box * 6), (box * 2), (box * 7), getPaintBasedOnPlayer(0)); //Red Open Tile
        for (i = (box * 9); i < (box * 13); i = i + box) {
            j = (box * 7);
            canvas.drawRect(i, j, i + box, j + box, getPaintBasedOnPlayer(2));
        } //Yellow Homestretch
        canvas.drawRect((box * 13), (box * 8), (box * 14), (box * 9), getPaintBasedOnPlayer(2)); //Yellow Open Tile
        for (j = box; j < (box * 6); j = j + box) {
            i = (box * 7);
            canvas.drawRect(i, j, i + box, j + box, getPaintBasedOnPlayer(1));
        } //Blue Homestretch
        canvas.drawRect((box * 8), box, (box * 9), (box * 2), getPaintBasedOnPlayer(1)); //Blue Open Tile
        for (j = (box * 9); j < (box * 13); j = j + box) {
            i = (box * 7);
            canvas.drawRect(i, j, i + box, j + box, getPaintBasedOnPlayer(3));
        } //Green Homestretch
        canvas.drawRect((box * 6), (box * 13), (box * 7), (box * 14), getPaintBasedOnPlayer(3)); //Green Open Tile

        //Ash safe tiles
        canvas.drawRect((box * 6), (box * 2), (box * 7), (box * 3), ashPaint);
        canvas.drawRect((box * 2), (box * 8), (box * 3), (box * 9), ashPaint);
        canvas.drawRect((box * 8), (box * 12), (box * 9), (box * 13), ashPaint);
        canvas.drawRect((box * 12), (box * 6), (box * 13), (box * 7), ashPaint);

        //Drawing ALL Valid and Invalid small tile squares
        for (i = 0; i < box * 15; i = i + box) {
            for (j = 0; j < box * 15; j = j + box) {
                canvas.drawRect(i, j, i + box, j + box, blackStrokePaint);
            }
        }

        // Erasing four corner tiles for showing corner radius clearly
        canvas.drawRect(0, 0, box, box, transparentPaint);
        canvas.drawRect(0, (box * 14), box, (box * 15), transparentPaint);
        canvas.drawRect((box * 14), 0, (box * 15), box, transparentPaint);
        canvas.drawRect((box * 14), (box * 14), (box * 15), (box * 15), transparentPaint);

        // Filling three round corners of red home base
        canvas.drawRect(0, (box * 5), box, (box * 6), getPaintBasedOnPlayer(0));
        canvas.drawRect((box * 5), (box * 5), (box * 6), (box * 6), getPaintBasedOnPlayer(0));
        canvas.drawRect((box * 5), 0, (box * 6), box, getPaintBasedOnPlayer(0));

        // Filling three round corners of blue home base
        canvas.drawRect((box * 14), (box * 5), (box * 15), (box * 6), getPaintBasedOnPlayer(1));
        canvas.drawRect((box * 9), (box * 5), (box * 10), (box * 6), getPaintBasedOnPlayer(1));
        canvas.drawRect((box * 9), 0, (box * 10), box, getPaintBasedOnPlayer(1));

        // Filling three round corners of green home base
        canvas.drawRect(0, (box * 9), box, (box * 10), getPaintBasedOnPlayer(3));
        canvas.drawRect((box * 5), (box * 9), (box * 6), (box * 10), getPaintBasedOnPlayer(3));
        canvas.drawRect((box * 5), (box * 14), (box * 6), (box * 15), getPaintBasedOnPlayer(3));

        // Filling three round corners of yellow home base
        canvas.drawRect((box * 14), (box * 9), (box * 15), (box * 10), getPaintBasedOnPlayer(2));
        canvas.drawRect((box * 9), (box * 9), (box * 10), (box * 10), getPaintBasedOnPlayer(2));
        canvas.drawRect((box * 9), (box * 14), (box * 10), (box * 15), getPaintBasedOnPlayer(2));

        //draw red HomeBase
        drawHomeBase(canvas, box, 0, 0, getPaintBasedOnPlayer(0), getMatchingPaintFromColor(getPaintBasedOnPlayer(0).getColor()));
        //draw blue HomeBase
        drawHomeBase(canvas, box, box * 9, 0, getPaintBasedOnPlayer(1), getMatchingPaintFromColor(getPaintBasedOnPlayer(1).getColor()));
        //draw yellow HomeBase
        drawHomeBase(canvas, box, box * 9, box * 9, getPaintBasedOnPlayer(2), getMatchingPaintFromColor(getPaintBasedOnPlayer(2).getColor()));
        //draw green HomeBase
        drawHomeBase(canvas, box, 0, box * 9, getPaintBasedOnPlayer(3), getMatchingPaintFromColor(getPaintBasedOnPlayer(3).getColor()));

        // Drawing home base player image bitmaps based on total players
        if (mState.getPlayerList().size() > 1) {

            drawHomeBaseUserImageBitmap(canvas, box, 0, 0, getPlayerBasedOnPosition(0));
            drawHomeBaseUserImageBitmap(canvas, box, box * 9, 0, mState.getNumPlayers() == 2 ? null : getPlayerBasedOnPosition(1));
            drawHomeBaseUserImageBitmap(canvas, box, box * 9, box * 9, getPlayerBasedOnPosition(2));
            drawHomeBaseUserImageBitmap(canvas, box, 0, box * 9, mState.getNumPlayers() == 2 ? null : getPlayerBasedOnPosition(3));
        }

        //Drawing Center Square
        drawCenterSquare(canvas, box, whitePaint, getPaintBasedOnPlayer(0), getPaintBasedOnPlayer(3),
                getPaintBasedOnPlayer(2), getPaintBasedOnPlayer(1));

        //draw the safe tile star bitmaps
        drawSafeTileBitmap((box * 2), (box * 8), canvas, box, R.drawable.ic_star);
        drawSafeTileBitmap((box * 8), (box * 12), canvas, box, R.drawable.ic_star);
        drawSafeTileBitmap((box * 6), (box * 2), canvas, box, R.drawable.ic_star);
        drawSafeTileBitmap((box * 12), (box * 6), canvas, box, R.drawable.ic_star);

        //draw the safe tile globe bitmaps
        drawSafeTileBitmap((box * 6), (box * 13), canvas, box, R.drawable.ic_globe);
        drawSafeTileBitmap((box * 1), (box * 6), canvas, box, R.drawable.ic_globe);
        drawSafeTileBitmap((box * 8), (box * 1), canvas, box, R.drawable.ic_globe);
        drawSafeTileBitmap((box * 13), (box * 8), canvas, box, R.drawable.ic_globe);

        //draw all the pieces
        drawPieces(canvas, box);
    }

    private Paint getPaintBasedOnPlayer(int homePos) {

        if (mState.getPlayerList().size() > 1) {
            Player player = getPlayerBasedOnPosition(homePos);

            if (player != null) {
                return getPaintFromColor(player.getPlayerColor());

            } else {
                if (mState.getPlayerList().size() == 2) {

                    if (homePos == 1) {
                        return ConnectivityProvider.getConnectivity().getCurrentRole() == ConnectivityProvider.ConnectionRole.CLIENT
                                ? greenPaint : bluePaint;

                    } else {
                        return ConnectivityProvider.getConnectivity().getCurrentRole() == ConnectivityProvider.ConnectionRole.CLIENT
                                ? bluePaint : greenPaint;
                    }

                } else {
                    return greenPaint;
                }
            }
        }
        return redPaint;
    }

    private Player getPlayerBasedOnPosition(int pos) {
        for (Player player : mState.getPlayerList()) {

            if (player.getPlayerPosition() == pos) {
                return player;
            }
        }

        return null;
    }

    private Paint getPaintFromColor(int color) {

        switch (color) {
            case Color.RED:
                return redPaint;

            case Color.BLUE:
                return bluePaint;

            case Color.YELLOW:
                return yellowPaint;

            case Color.GREEN:
                return greenPaint;

            default:
                return greenPaint;
        }
    }

    private int getPieceDrawableFromColor(int color) {

        if (color == greenPaint.getColor()) {
            return R.drawable.ic_piece_green;

        } else if (color == bluePaint.getColor()) {
            return R.drawable.ic_piece_blue;

        } else if (color == yellowPaint.getColor()) {
            return R.drawable.ic_piece_yellow;

        } else {
            return R.drawable.ic_piece_red;
        }
    }

    private Paint getMatchingPaintFromColor(int color) {

        if (color == redPaint.getColor()) {
            return redPaint2;

        } else if (color == bluePaint.getColor()) {
            return bluePaint2;

        } else if (color == yellowPaint.getColor()) {
            return yellowPaint2;

        } else {
            return greenPaint2;
        }
    }

    public void drawSafeTileBitmap(float xPos, float yPos, Canvas canvas, float box, int resId) {
        Bitmap mBitmap = getBitmapFromResMap(resId);
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(mBitmap, Math.round(box), Math.round(box), false);
        canvas.drawBitmap(resizedBitmap, xPos, yPos, null);
    }

    /**
     * drawPieces
     * this draws the pieces. They are moved according to touch events etc.
     *
     * @param canvas Canvas objects
     * @param box    This is the width of the board divided by 15. This is used to scale everything
     *               according to the screens dimensions
     */
    public void drawPieces(Canvas canvas, float box) {
        outOfHomeTokens.clear();

        //initialize the isdrawn array to false
        mIsDrawn = new boolean[16];
        Arrays.fill(mIsDrawn, false);

        if (mState.getPlayerList().size() > 1) {
            if (mState.getPlayerList().size() == 2) {

                loopThroughPieces(0, 3, canvas, box);
                loopThroughPieces(8, 11, canvas, box);

            } else if (mState.getPlayerList().size() == 3) {

                if (getPlayerBasedOnPosition(0) != null) {
                    loopThroughPieces(0, 3, canvas, box);

                }

                if (getPlayerBasedOnPosition(1) != null) {
                    loopThroughPieces(4, 7, canvas, box);

                }

                if (getPlayerBasedOnPosition(3) != null) {
                    loopThroughPieces(12, 15, canvas, box);

                }

                loopThroughPieces(8, 11, canvas, box);

            } else {
                // Drawing pieces based on total players
                loopThroughPieces(0, 15, canvas, box);
            }
        }

        if (outOfHomeTokens.size() > 0) {
            // Sorting according lower token position on board
            Collections.sort(outOfHomeTokens, (t1, t2) -> (t1.getCurrentXLoc() + t1.getCurrentYLoc()) - (t2.getCurrentXLoc() + t2.getCurrentYLoc()));

            for (int j = 0; j < outOfHomeTokens.size(); j++) {
                drawPiece(outOfHomeTokens.get(j).getIndex(), canvas, box);
            }
        }
    }

    private void loopThroughPieces(int startVal, int endVal, Canvas canvas, float box) {

        Token token;

        for (int i = startVal; i <= endVal; i++) {
            if (!mState.pieces[i].getIsHome()) {

                token = mState.pieces[i];
                token.setIndex(i);
                outOfHomeTokens.add(token);

            } else {
                drawPiece(i, canvas, box);
            }
        }

    }

    private void drawPiece(int i, Canvas canvas, float box) {
        int xPos, yPos;

        if (!mState.pieces[i].getIsHome()) {//draw the pieces out of base
            if (!mIsDrawn[i]) {//only draw the pieces that haven't been drawn yet
                if (mState.pieces[i].getOwner() == 0) {//use the red path
                    xPos = mState.pieces[i].getCurrentXLoc();
                    yPos = mState.pieces[i].getCurrentYLoc();
                    checkOverlap(mState.pieces[i], i, (box * xPos), (box * yPos), box, canvas, getPieceDrawableFromColor(getPaintBasedOnPlayer(0).getColor()));
                }
                if (mState.pieces[i].getOwner() == 1) {//use the blue path
                    xPos = mState.pieces[i].getCurrentXLoc();
                    yPos = mState.pieces[i].getCurrentYLoc();
                    checkOverlap(mState.pieces[i], i, (box * xPos), (box * yPos), box, canvas, getPieceDrawableFromColor(getPaintBasedOnPlayer(1).getColor()));
                }
                if (mState.pieces[i].getOwner() == 2) {//use the yellow path
                    xPos = mState.pieces[i].getCurrentXLoc();
                    yPos = mState.pieces[i].getCurrentYLoc();
                    checkOverlap(mState.pieces[i], i, (box * xPos), (box * yPos), box, canvas, getPieceDrawableFromColor(getPaintBasedOnPlayer(2).getColor()));
                }
                if (mState.pieces[i].getOwner() == 3) {//use the green path
                    xPos = mState.pieces[i].getCurrentXLoc();
                    yPos = mState.pieces[i].getCurrentYLoc();
                    checkOverlap(mState.pieces[i], i, (box * xPos), (box * yPos), box, canvas, getPieceDrawableFromColor(getPaintBasedOnPlayer(3).getColor()));
                }
            }

        } else {//draw the pieces in the start square
            if (mState.pieces[i].getOwner() == 0) {//red piece
                drawPieceBitmap(canvas, getPieceDrawableFromColor(getPaintBasedOnPlayer(0).getColor()), i, box);
            }
            if (mState.pieces[i].getOwner() == 1) {//blue piece
                drawPieceBitmap(canvas, getPieceDrawableFromColor(getPaintBasedOnPlayer(1).getColor()), i, box);
            }
            if (mState.pieces[i].getOwner() == 2) {//yellow piece
                drawPieceBitmap(canvas, getPieceDrawableFromColor(getPaintBasedOnPlayer(2).getColor()), i, box);
            }
            if (mState.pieces[i].getOwner() == 3) {//green piece
                drawPieceBitmap(canvas, getPieceDrawableFromColor(getPaintBasedOnPlayer(3).getColor()), i, box);
            }
        }
    }

    /**
     * Draw the image bitmap into canvas
     *
     * @param canvas is the canvas to draw in
     * @param resId  is the bitmap res
     * @param i      the index of array
     * @param box    is the single box of ludo board
     */
    private void drawPieceBitmap(Canvas canvas, int resId, int i, float box) {
        float x, y;
        x = (float) mState.pieces[i].getStartXPos() * box;
        y = (float) mState.pieces[i].getStartYPos() * box;
        Bitmap mBitmap = getBitmapFromResMap(mState.pieces[i].isShouldHighlight() ? getHighlightedToken(resId) : resId);
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(mBitmap, Math.round(box + (box / 2)), Math.round(box + (box / 2)), false);
        canvas.drawBitmap(resizedBitmap, x, y, null);
    }

    /*
     * FIXED BY AVERY GUILLERMO
     *
     */
    //Draws the pieces entirely and ensures that all pieces can be seen even if another piece lands
    //on the same spot.
    public void checkOverlap(Token piece, int currentIndex, float xPos, float yPos, float box, Canvas canvas, int resId) {

        //initialize local instance variables
        boolean overlapHappened = false;
        List<Integer> overlapPieceIndexies = new ArrayList<>();
        ArrayList<Integer> resIds = new ArrayList<>();
        overlapPieceIndexies.add(currentIndex);
        resIds.add(resId);

        //store the indexies and the paints of the pieces that overlap
        for (int i = 0; i < 16; i++) {
            if ((i != currentIndex) &&
                    !mState.pieces[i].getIsHome() &&
                    (piece.getCurrentXLoc() == mState.pieces[i].getCurrentXLoc()) &&
                    (piece.getCurrentYLoc() == mState.pieces[i].getCurrentYLoc())
            ) {
                //overlap found!!
                overlapHappened = true;
                overlapPieceIndexies.add(i);
                switch (mState.pieces[i].getOwner()) {
                    case 0:
                        resIds.add(getPieceDrawableFromColor(getPaintBasedOnPlayer(0).getColor()));
                        break;

                    case 1:
                        resIds.add(getPieceDrawableFromColor(getPaintBasedOnPlayer(1).getColor()));
                        break;

                    case 2:
                        resIds.add(getPieceDrawableFromColor(getPaintBasedOnPlayer(2).getColor()));
                        break;

                    case 3:
                        resIds.add(getPieceDrawableFromColor(getPaintBasedOnPlayer(3).getColor()));
                        break;
                }
            }
        }

        if (overlapHappened) {
            drawOverlapPieces(canvas, box, xPos, yPos, overlapPieceIndexies, resIds);

        } else {
            Bitmap mBitmap = getBitmapFromResMap(piece.isShouldHighlight() ? getHighlightedToken(resId) : resId);
            if ((xPos >= (box * 6) && xPos <= (box * 8)) && yPos == 0) {
                Bitmap resizedBitmap = Bitmap.createScaledBitmap(mBitmap, Math.round(box + (box / 4)), Math.round(box + (box / 4)), false);
                canvas.drawBitmap(resizedBitmap, xPos - (box / 7), yPos, null);

            } else {
                Bitmap resizedBitmap = Bitmap.createScaledBitmap(mBitmap, Math.round(box + (box / 4)), Math.round(box + (box / 4)), false);
                canvas.drawBitmap(resizedBitmap, xPos - (box / 7), yPos - (box / 6), null);
            }
        }
    }

    private int getHighlightedToken(int resId) {
        switch (resId) {

            case R.drawable.ic_piece_red:
                return R.drawable.ic_piece_red_highlighted;

            case R.drawable.ic_piece_yellow:
                return R.drawable.ic_piece_yellow_highlighted;

            case R.drawable.ic_piece_green:
                return R.drawable.ic_piece_green_highlighted;

            case R.drawable.ic_piece_blue:
                return R.drawable.ic_piece_blue_highlighted;

            default:
                return -1;
        }
    }

    public void drawHomeBase(Canvas canvas, float box, float xPos, float yPos, Paint colorPaint, Paint shapePaint) {
        canvas.drawRoundRect(new RectF(xPos + 0, yPos + 0, xPos + (box * 6), yPos + (box * 6)), 5, 5, colorPaint);

        canvas.drawRoundRect(new RectF(xPos + (box / 2), yPos + (box / 2),
                xPos + ((box * 5) + (box / 2)), yPos + ((box * 5) + (box / 2))), 15, 15, shapePaint);
        RectF squareRect = new RectF(xPos + (box + (box / 2)), yPos + (box + (box / 2)),
                xPos + ((box * 4) + (box / 2)), yPos + ((box * 4) + (box / 2)));
        canvas.drawRoundRect(squareRect, 15, 15, whitePaint);
    }

    private void drawHomeBaseUserImageBitmap(Canvas canvas, float box, float xPos, float yPos, Player player) {

        if (player != null) {
            Bitmap bitmap;
            if (!TextUtils.isEmpty(player.getImagePath())) {
                bitmap = getImageBitmapFromPath(player.getImagePath());

                if (bitmap != null) {
                    Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
                    Canvas canvas2 = new Canvas(output);
                    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    paint.setColor(0XFF000000);
                    canvas2.drawPath(getPath(bitmap), paint);
                    paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                    canvas2.drawBitmap(bitmap, 0, 0, paint);

                    drawImageBitmap(canvas, box, xPos, yPos, output);
                }

            } else {
                if (player.getUserId().contains(":")) {
                    // Human player
                    drawImageBitmap(canvas, box, xPos, yPos, getBitmapFromDrawableRes(R.drawable.ic_avatar));

                } else {
                    // Bot
                    drawImageBitmap(canvas, box, xPos, yPos, getBitmapFromDrawableRes(R.drawable.ic_bot));
                }
            }

        } else {
            drawImageBitmap(canvas, box, xPos, yPos, getBitmapFromDrawableRes(R.drawable.ic_no_player_filled));
        }
    }

    @SuppressLint("RestrictedApi")
    private Path getPath(Bitmap src) {
        String circle = "M32 16A16 16 0 0 1 16 32 16 16 0 0 1 0 16 16 16 0 0 1 16 0 16 16 0 0 1 32 16Z";
        return resizePath(PathParser.createPathFromPathData(circle),
                src.getWidth(), src.getHeight());
    }

    private Path resizePath(Path path, float width, float height) {
        RectF bounds = new RectF(0, 0, width, height);
        Path resizedPath = new Path(path);
        RectF src = new RectF();
        resizedPath.computeBounds(src, true);

        Matrix resizeMatrix = new Matrix();
        resizeMatrix.setRectToRect(src, bounds, Matrix.ScaleToFit.CENTER);
        resizedPath.transform(resizeMatrix);

        return resizedPath;
    }

    private void drawImageBitmap(Canvas canvas, float box, float xPos, float yPos, Bitmap bitmap) {
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, Math.round(box * 2), Math.round(box * 2), false);
        canvas.drawBitmap(resizedBitmap, xPos + (box * 2), yPos + (box * 2), null);
    }

    private Bitmap getImageBitmapFromPath(String path) {
        if (path == null)
            return null;

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeFile(path, options);
    }

    private Bitmap getBitmapFromDrawableRes(int resId) {
        return getBitmapFromResMap(resId);
    }

    public void drawCenterSquare(Canvas canvas, float box, Paint whitePaint, Paint redPaint, Paint greenPaint, Paint yellowPaint, Paint bluePaint) {
        canvas.drawRect((box * 6), (box * 6), (box * 9), (box * 9), whitePaint);
        PointF p1 = new PointF((box * 6), (box * 6)); //Top Left
        PointF p2 = new PointF((getWidth() / 2), (getWidth() / 2)); //Dead Center
        PointF p3 = new PointF((box * 9), (box * 6)); //Top Right
        PointF p4 = new PointF((box * 6), (box * 9)); //Bottom Left
        PointF p5 = new PointF((box * 9), (box * 9)); //Bottom Right
        //Drawing the green Center Triangle
        Path tri1 = new Path();
        tri1.moveTo(p1.x, p1.y);
        tri1.lineTo(p2.x, p2.y);
        tri1.lineTo(p3.x, p3.y);
        tri1.close();
        canvas.drawPath(tri1, bluePaint);

        //Drawing the red Center Triangle
        Path tri2 = new Path();
        tri2.moveTo(p1.x, p1.y);
        tri2.lineTo(p2.x, p2.y);
        tri2.lineTo(p4.x, p4.y);
        tri2.close();
        canvas.drawPath(tri2, redPaint);

        //Drawing the blue Center Triangle
        Path tri3 = new Path();
        tri3.moveTo(p4.x, p4.y);
        tri3.lineTo(p2.x, p2.y);
        tri3.lineTo(p5.x, p5.y);
        tri3.close();
        canvas.drawPath(tri3, greenPaint);

        //Drawing the yellow Center Triangle
        Path tri4 = new Path();
        tri4.moveTo(p3.x, p3.y);
        tri4.lineTo(p2.x, p2.y);
        tri4.lineTo(p5.x, p5.y);
        tri4.close();
        canvas.drawPath(tri4, yellowPaint);
    }

    private void drawOverlapPieceBitmap(Canvas canvas, int resId, int pieceIndex, float x, float y, float resWidth, float resHeight) {
        Bitmap mBitmap = getBitmapFromResMap(mState.pieces[pieceIndex].isShouldHighlight() ? getHighlightedToken(resId) : resId);
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(mBitmap, Math.round(resWidth), Math.round(resHeight), false);
        canvas.drawBitmap(resizedBitmap, x, y, null);
    }

    public void drawOverlapPieces(Canvas canvas, float box, float xPos, float yPos, List<Integer> indexies, ArrayList<Integer> resIds) {

        Paint whitePaint = new Paint();
        whitePaint.setColor(Color.rgb(255, 255, 255));

        switch (indexies.size()) {
            case 2: //draw two overlapping pieces
                // Two overlapping pieces
                drawOverlapPieceBitmap(canvas, resIds.get(0), indexies.get(0), xPos - (box / 12), yPos, (float) (box / 1.2), (float) (box / 1.2));
                drawOverlapPieceBitmap(canvas, resIds.get(1), indexies.get(1), (float) (xPos + (box / 3.8)), (float) (yPos + (box / 4.5)), (float) (box / 1.2), (float) (box / 1.2));

                //set the two pieces to true
                this.mIsDrawn[indexies.get(0)] = true;
                this.mIsDrawn[indexies.get(1)] = true;
                break;

            case 3: //draw three overlapping pieces
                // Three overlapping pieces
                drawOverlapPieceBitmap(canvas, resIds.get(0), indexies.get(0), xPos + (box / 6), yPos, (float) (box / 1.45), (float) (box / 1.45));
                drawOverlapPieceBitmap(canvas, resIds.get(1), indexies.get(1), (float) (xPos + (box / 2.5)), (float) (yPos + (box / 3.2)), (float) (box / 1.45), (float) (box / 1.45));
                drawOverlapPieceBitmap(canvas, resIds.get(2), indexies.get(2), xPos - (box / 12), (float) (yPos + (box / 3.2)), (float) (box / 1.45), (float) (box / 1.45));

                //set the two pieces to true
                this.mIsDrawn[indexies.get(0)] = true;
                this.mIsDrawn[indexies.get(1)] = true;
                this.mIsDrawn[indexies.get(2)] = true;
                break;

            case 4: //draw four overlapping pieces
                // Four overlapping pieces
                drawOverlapPieceBitmap(canvas, resIds.get(0), indexies.get(0), xPos - (box / 12), yPos, (float) (box / 1.5), (float) (box / 1.5));
                drawOverlapPieceBitmap(canvas, resIds.get(1), indexies.get(1), (float) (xPos + (box / 2.5)), yPos, (float) (box / 1.5), (float) (box / 1.5));
                drawOverlapPieceBitmap(canvas, resIds.get(2), indexies.get(2), xPos - (box / 12), (float) (yPos + (box / 2.8)), (float) (box / 1.5), (float) (box / 1.5));
                drawOverlapPieceBitmap(canvas, resIds.get(3), indexies.get(3), (float) (xPos + (box / 2.5)), (float) (yPos + (box / 2.8)), (float) (box / 1.5), (float) (box / 1.5));

                //set the two pieces to true
                this.mIsDrawn[indexies.get(0)] = true;
                this.mIsDrawn[indexies.get(1)] = true;
                this.mIsDrawn[indexies.get(2)] = true;
                this.mIsDrawn[indexies.get(3)] = true;
                break;

            case 5: //draw five overlapping pieces

                // Five overlapping pieces
                drawOverlapPieceBitmap(canvas, resIds.get(0), indexies.get(0), xPos - (box / 12), yPos, (float) (box / 1.7), (float) (box / 1.7));
                drawOverlapPieceBitmap(canvas, resIds.get(1), indexies.get(1), (float) (xPos + (box / 2.0)), yPos, (float) (box / 1.7), (float) (box / 1.7));
                drawOverlapPieceBitmap(canvas, resIds.get(2), indexies.get(2), xPos - (box / 12), (float) (yPos + (box / 2.2)), (float) (box / 1.7), (float) (box / 1.7));
                drawOverlapPieceBitmap(canvas, resIds.get(3), indexies.get(3), (float) (xPos + (box / 2.0)), (float) (yPos + (box / 2.2)), (float) (box / 1.7), (float) (box / 1.7));
                drawOverlapPieceBitmap(canvas, resIds.get(4), indexies.get(4), xPos + (box / 5), yPos + (box / 4), (float) (box / 1.7), (float) (box / 1.7));
                break;

            default: //draw six or more overlapping pieces

                // Six overlapping pieces
                drawOverlapPieceBitmap(canvas, resIds.get(0), indexies.get(0), xPos - (box / 12), yPos, (float) (box / 1.85), (float) (box / 1.85));
                drawOverlapPieceBitmap(canvas, resIds.get(1), indexies.get(1), (float) (xPos + (box / 1.9)), yPos, (float) (box / 1.85), (float) (box / 1.85));
                drawOverlapPieceBitmap(canvas, resIds.get(2), indexies.get(2), xPos - (box / 12), yPos + (box / 2), (float) (box / 1.85), (float) (box / 1.85));
                drawOverlapPieceBitmap(canvas, resIds.get(3), indexies.get(3), (float) (xPos + (box / 1.9)), yPos + (box / 2), (float) (box / 1.85), (float) (box / 1.85));
                drawOverlapPieceBitmap(canvas, resIds.get(4), indexies.get(4), (float) (xPos + (box / 4.6)), yPos, (float) (box / 1.85), (float) (box / 1.85));
                drawOverlapPieceBitmap(canvas, resIds.get(5), indexies.get(5), (float) (xPos + (box / 4.6)), yPos + (box / 2), (float) (box / 1.85), (float) (box / 1.85));

                //Don't implement higher than six because it is extremely improbable that more than 7 pieces
                //would land on the same tile. Even if it did, it would just draw over each other.
        }

    }

}

