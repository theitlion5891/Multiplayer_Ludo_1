package com.w3engineers.theme.ludosix.data.helper.keys;

public interface JsonKeys {
    interface Flag {
        byte FLAG_PEER = 0;
    }
}