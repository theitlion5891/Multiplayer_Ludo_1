package com.w3engineers.theme.ludosix.data.helper;

import android.media.MediaPlayer;

import com.w3engineers.theme.LudoSixApp;
import com.w3engineers.theme.ludosix.R;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 3/18/2019 at 3:58 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Manages music playback
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 3/18/2019.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 3/18/2019.
 * Copyright (c) 2019, W3 Engineers Ltd. All rights reserved.
 */
public class MusicManager {

    private static MusicManager sManager;
    private MediaPlayer mPlayer;
    private int mLength = 0;

    public static MusicManager getInstance() {
        if (sManager == null) {
            sManager = new MusicManager();
        }
        return sManager;
    }


    public void play() {
        mPlayer = MediaPlayer.create(LudoSixApp.getContext(), R.raw.game_background_music);
        mPlayer.setLooping(true);
        mPlayer.setVolume(GameDataHelper.getSoundVolume(), GameDataHelper.getSoundVolume());
        mPlayer.start();
    }

    /**
     * Sets music volume
     */
    public void setMusicVolume(float volume) {
        if (mPlayer != null) {
            mPlayer.setVolume(volume, volume);
        }
    }

    /**
     * Pauses Music
     */
    public void pauseMusic() {
        try {
            if (mPlayer != null && mPlayer.isPlaying()) {
                mPlayer.pause();
                mLength = mPlayer.getCurrentPosition();
            }
        } catch (Exception e) {
            // Handle exception here
        }
    }

    /**
     * Resumes Music
     */
    public void resumeMusic() {
        try {
            if (mPlayer != null && !mPlayer.isPlaying()) {
                mPlayer.seekTo(mLength);
                mPlayer.start();
            }

        } catch (Exception e) {
            // Handle exception here
        }
    }

    /**
     * Stops Music
     */
    public void stopMusic() {
        try {
            if (mPlayer != null && mPlayer.isPlaying()) {
                mPlayer.stop();
                mPlayer.release();
                mPlayer = null;
            }
        } catch (Exception e) {
            // Handle exception here
        }
    }
}
