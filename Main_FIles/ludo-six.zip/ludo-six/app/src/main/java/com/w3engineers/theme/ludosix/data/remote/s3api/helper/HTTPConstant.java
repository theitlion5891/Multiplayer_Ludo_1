package com.w3engineers.theme.ludosix.data.remote.s3api.helper;

/*
 *  ****************************************************************************
 *  * Created by : Ahmed Mohmmad Ullah (Azim) on 5/4/2018 at 11:06 AM.
 *  * Email : azim@w3engineers.com
 *  *
 *  * Last edited by : Ahmed Mohmmad Ullah (Azim) on 5/4/2018.
 *  *
 *  * Last Reviewed by : <Reviewer Name> on <mm/dd/yy>
 *  ****************************************************************************
 */
public interface HTTPConstant {

    String S3BUCKET = "s3_bucket";
    String FILE_NAME = "file_name";

    String UPLOAD_SIGNED_URL = "upload-signed-url";


    int FILE_UPLOAD_FAILED_REASON_DEFAULT = -1;
    int FILE_UPLOAD_FAILED_REASON_FILE_SIZE = -2;
    int FILE_UPLOAD_FAILED_REASON_CANCELLED = 1;

}
