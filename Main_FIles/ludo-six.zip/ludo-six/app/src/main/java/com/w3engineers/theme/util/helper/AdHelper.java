package com.w3engineers.theme.util.helper;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.widget.LinearLayout;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.w3engineers.theme.ludosix.R;



public class AdHelper {
    private final String TAG = AdHelper.class.getSimpleName();
    private InterstitialAd interstitialAd;

    public static void loadBannerAd(Context context, LinearLayout linearLayout) {
        MobileAds.initialize(context);

        LinearLayout layout = linearLayout;
        layout.setOrientation(LinearLayout.VERTICAL);

        // Create a banner ad
        AdView mAdView = new AdView(context);
        mAdView.setAdSize(AdSize.SMART_BANNER);
        mAdView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
        // Add the AdView to the view hierarchy.
        layout.addView(mAdView);
        // Create an ad request.
        AdRequest adRequestBuilder = new AdRequest.Builder().build();
        // Start loading the ad.
        mAdView.setBackgroundColor(context.getResources().getColor(R.color.white));
        mAdView.loadAd(adRequestBuilder);
    }

    public void interstitialAd(Context context, AdCloseListener adCloseListener) {
        MobileAds.initialize(context, "ca-app-pub-9097356930465867~2247284033");

        InterstitialAd mInterstitialAd = new InterstitialAd(context);
        mInterstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
                mInterstitialAd.show();
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                // Code to be executed when an ad request fails.
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when the ad is displayed.
            }

            @Override
            public void onAdLeftApplication() {
                // Code to be executed when the user has left the app.
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when when the interstitial ad is closed.
              //  adCloseListener.onAdClosed();
            }
        });

    }


    public interface AdCloseListener {
        void onAdClosed();
    }
}
