package com.w3engineers.theme.util.helper;

import android.util.Log;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

import com.w3engineers.theme.LudoSixApp;
import com.w3engineers.theme.ludosix.R;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/9/2018 at 12:21 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Helper class for glider library
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 11/9/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 11/9/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class Glider {

    public static void show(String location, ImageView imageView) {
        if (location != null && !location.isEmpty() && imageView != null) {
            Glide.with(LudoSixApp.getContext())
                    .load(location)
                    .into(imageView);
        }
    }

    public static void showCircleImage(String location, ImageView imageView) {
     //   try {
            if (location != null && !location.isEmpty() && imageView != null) {

                RequestOptions options = new RequestOptions()
                        .placeholder(R.drawable.ic_avatar)
                        .error(R.drawable.ic_avatar)
                        .diskCacheStrategy(DiskCacheStrategy.DATA);

                Glide.with(LudoSixApp.getContext())
                        .load(location)
                        .apply(RequestOptions.circleCropTransform())
                        .apply(options)
                        .into(imageView);
            }
  /*      }catch(IllegalArgumentException ex) {
            Log.wtf("Glide-tag", String.valueOf(imageView.getTag()));
        }*/

    }

    public static void showGifImage(int resId, ImageView imageView) {
        if (imageView != null) {
            RequestOptions options = new RequestOptions()
                    .diskCacheStrategy(DiskCacheStrategy.NONE);

            Glide.with(LudoSixApp.getContext())
                    .asGif()
                    .load(resId)
                    .apply(options)
                    .into(imageView);
        }
    }
}