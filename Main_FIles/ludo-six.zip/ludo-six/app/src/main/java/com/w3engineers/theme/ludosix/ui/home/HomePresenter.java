package com.w3engineers.theme.ludosix.ui.home;

import android.graphics.Color;
import android.util.Log;

import com.left.core.util.lib.nearby.GameMessages;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.data.helper.keys.GameMode;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.data.local.model.UserInfo;
import com.w3engineers.theme.ludosix.ui.base.BasePresenter;
import com.w3engineers.theme.util.lib.GSonHelper;
import com.w3engineers.theme.util.lib.nearby.ConnectionManager;
import com.w3engineers.theme.util.lib.nearby.ConnectivityProvider;
import com.w3engineers.theme.util.lib.nearby.ImageRecievedEvent;
import com.w3engineers.theme.util.lib.nearby.NearbyConnectionEvent;
import com.w3engineers.theme.util.lib.nearby.NearbyGameSettingsEvent;
import com.w3engineers.theme.util.lib.nearby.NearbyInvitationEvent;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 13/11/2018 at 3:38 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Presenter class
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 18/02/2019.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 18/02/2019.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class HomePresenter extends BasePresenter<HomeMvpView> {
    private static final String TAG = "HomePresenter";

    /**
     * Creates game player list based on game mode
     *
     * @return the created game player list
     */
    public ArrayList<Player> getGamePlayers(Player player1, Player player2, Player player3, int currentGameMode, boolean isNotInAnyGame, Player mSelfPlayer) {
        ArrayList<Player> gamePlayers = new ArrayList<>();

        Player botPlayer1 = new Player("bot1", "bot1", "Com 1", "", Player.Type.BOT);
        Player botPlayer2 = new Player("bot2", "bot2", "Com 2", "", Player.Type.BOT);
        Player botPlayer3 = new Player("bot3", "bot3", "Com 3", "", Player.Type.BOT);

        if (player1 != null) {
            player1.setPlayerType(Player.Type.PROXY_PLAYER);
            player1.setHasAcknowledged(false);
        }

        if (player2 != null) {
            player2.setPlayerType(Player.Type.PROXY_PLAYER);
            player2.setHasAcknowledged(false);
        }

        if (player3 != null) {
            player3.setPlayerType(Player.Type.PROXY_PLAYER);
            player3.setHasAcknowledged(false);
        }

        switch (currentGameMode) {
            case GameMode.TWO_PLAYER:

                if (player1 != null) {
                    gamePlayers.add(player1);

                } else {
                    gamePlayers.add(botPlayer1);
                }

                break;

            case GameMode.THREE_PLAYER:
                if (player1 != null && player2 != null) {
                    gamePlayers.add(player1);
                    gamePlayers.add(player2);

                } else if (player1 != null || player2 != null) {
                    gamePlayers.add(botPlayer1);

                    if (player1 != null) {
                        gamePlayers.add(player1);
                    } else {
                        gamePlayers.add(player2);
                    }

                } else {
                    gamePlayers.add(botPlayer1);
                    gamePlayers.add(botPlayer2);
                }
                break;

            case GameMode.FOUR_PLAYER:
                if (player1 != null && player2 != null && player3 != null) {
                    gamePlayers.add(player1);
                    gamePlayers.add(player2);
                    gamePlayers.add(player3);

                } else if (player1 != null || player2 != null || player3 != null) {

                    if (player1 != null) {
                        gamePlayers.add(player1);
                    }
                    if (player2 != null) {
                        gamePlayers.add(player2);
                    }
                    if (player3 != null) {
                        gamePlayers.add(player3);
                    }
                    if (gamePlayers.size() == 1) {
                        gamePlayers.add(botPlayer1);
                        gamePlayers.add(botPlayer2);
                    }
                    if (gamePlayers.size() == 2) {
                        gamePlayers.add(botPlayer1);
                    }

                } else {
                    gamePlayers.add(botPlayer1);
                    gamePlayers.add(botPlayer2);
                    gamePlayers.add(botPlayer3);
                }
                break;
        }

        if (gamePlayers.size() > 1) {
            Collections.shuffle(gamePlayers);
        }

        for (int i = 0; i < gamePlayers.size(); i++) {
            Player player = gamePlayers.get(i);

            // If player position is 2 then shifting to position 3
            if (i == 2) {
                i += 1;
            }

            player.setPlayerPosition(i);
            player.setPlayerColor(getPlayerColor(i));
        }

        UserInfo userInfo = GameDataHelper.getUserInfo();

        // Adding self player
        if (userInfo != null) {
            Player selfPlayer = new Player(userInfo.getId(), mSelfPlayer != null ? mSelfPlayer.getEndPointId() : "", userInfo.getName(), userInfo.getImagePath(), Player.Type.HUMAN_LOCAL);
            selfPlayer.setPlayerPosition(2);
            selfPlayer.setPlayerColor(getPlayerColor(2));
            gamePlayers.add(selfPlayer);
        }

        if (!isNotInAnyGame) {

            if (gamePlayers.size() == 2) {
                gamePlayers.add(new Player("dummy", "dummy", "dummy", "", Player.Type.PROXY_PLAYER));
                gamePlayers.add(new Player("dummy", "dummy2", "dummy", "", Player.Type.PROXY_PLAYER));

            } else if (gamePlayers.size() == 3) {
                gamePlayers.add(new Player("dummy", "dummy", "dummy", "", Player.Type.PROXY_PLAYER));
            }
        }

        return gamePlayers;
    }

    private int getPlayerColor(int position) {

        switch (position) {
            case 0:
                return Color.RED;

            case 1:
                return Color.BLUE;

            case 2:
                return Color.YELLOW;

            case 3:
                return Color.GREEN;

            default:
                return -1;
        }
    }

    public void startSearchingNearby(ConnectivityProvider.ConnectionRole role) {
        ConnectivityProvider.getConnectivity().startFindingNearbyDevices(role);

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    public void stopSearchingNearby() {
        ConnectivityProvider.getConnectivity().stopAllEndpoints();

        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    public void acceptInvitation(Player player) {
        List<GameMessages.EndPoint> endPoints = new ArrayList<>();
        endPoints.add(mapPlayerToEndPoint(player));

        UserInfo userInfo = GameDataHelper.getUserInfo();
        if (userInfo != null) {
            endPoints.add(mapPlayerToEndPoint(new Player(userInfo.getId(), "", userInfo.getName(),
                    userInfo.getImagePath(), Player.Type.HUMAN_REMOTE, GSonHelper.toJson(GameDataHelper.getScoreBoard()))));
        }

        ConnectionManager.sendInvitationAccept(endPoints);
    }

    public void declineInvitation(Player player) {
        ConnectionManager.sendInvitationDecline(mapPlayerToEndPoint(player));
    }

    public void sendUpdateAccept(List<Player> players, Player newPlayer) {
        List<String> endPointIds = new ArrayList<>();
        for (Player p : players) {
            endPointIds.add(p.getEndPointId());
        }
        ConnectionManager.sendUpdateAccept(endPointIds, mapPlayerToEndPoint(newPlayer));
    }

    public void sendImageUpdateToPlayers(List<Player> players, Player newPlayer) {
        List<String> endPointIds = new ArrayList<>();
        for (Player p : players) {
            endPointIds.add(p.getEndPointId());
        }
        if (endPointIds.size() > 0)
            ConnectionManager.broadCastImagesUpdate(endPointIds, mapPlayerToEndPoint(newPlayer), newPlayer.getImagePath());
    }

    public void sendPayersInfoToNewPlayer(List<Player> players, Player newPlayer) {
        List<GameMessages.EndPoint> endPoints = new ArrayList<>();
        for (Player p : players) {
            endPoints.add(mapPlayerToEndPoint(p));
        }
        ConnectionManager.sendPlayersInfoToNewPlayer(endPoints, mapPlayerToEndPoint(newPlayer));
    }

    public void sendInvitation(Player player) {
        if (player.getState() == Player.State.NOT_IN_GAME) {
            List<GameMessages.EndPoint> endPoints = new ArrayList<>();
            endPoints.add(mapPlayerToEndPoint(player));

            UserInfo userInfo = GameDataHelper.getUserInfo();
            if (userInfo != null) {
                endPoints.add(mapPlayerToEndPoint(new Player(userInfo.getId(), "", userInfo.getName(), userInfo.getImagePath(),
                        Player.Type.HUMAN_LOCAL, GSonHelper.toJson(GameDataHelper.getScoreBoard()))));
            }

            ConnectionManager.sendInvitation(endPoints);
        }
    }

    private Player mapEndPointToPlayer(GameMessages.EndPoint endPoint) {

        Player player = new Player(endPoint.getUserId(), endPoint.getEndPointId(), endPoint.getEndPointName(), endPoint.getImagePath(),
                endPoint.getPlayerType(), endPoint.getUserScore());

        player.setPlayerPosition(endPoint.getPlayerPosition());
        player.setPlayerColor(endPoint.getPlayerColor());

        return player;
    }

    private List<Player> mapEndPointListToPlayerList(List<GameMessages.EndPoint> endPoints) {
        List<Player> players = new ArrayList<>();
        for (GameMessages.EndPoint e : endPoints) {
            players.add(mapEndPointToPlayer(e));
        }
        return players;
    }

    private GameMessages.EndPoint mapPlayerToEndPoint(Player player) {
        return GameMessages.EndPoint.newBuilder()
                .setUserId(player.getUserId())
                .setEndPointId(player.getEndPointId())
                .setEndPointName(player.getName())
                .setImagePath(player.getImagePath())
                .setPlayerType(player.getPlayerType())
                .setPlayerPosition(player.getPlayerPosition())
                .setPlayerColor(player.getPlayerColor())
                .setUserScore(player.getPlayerScoreJson())
                .build();

    }

    public void sendInGamePlayerImagesToNewPlayer(List<Player> players, Player newPlayer) {
        List<GameMessages.EndPoint> endPoints = new ArrayList<>();
        for (Player p : players) {
            endPoints.add(mapPlayerToEndPoint(p));
        }
        ConnectionManager.sendInGamePlayerImagesToNewPlayer(endPoints, mapPlayerToEndPoint(newPlayer));
    }

    public void broadcastGameMode(List<Player> players, GameMessages.GameSettingsPacket.GameMode gameMode) {
        List<String> endPointIds = new ArrayList<>();
        for (Player p : players) {
            endPointIds.add(p.getEndPointId());
        }
        if (endPointIds.size() > 0)
            ConnectionManager.sendGameSettingsToPlayers(endPointIds, gameMode);
    }

    public void broadcastGameInitMessage(List<Player> players, GameMessages.InvitationPacket.InvitationPacketType type) {
        List<String> sendToEndPointIds = getProxyPlayerEndpoints(players);

        if (sendToEndPointIds.size() > 0) {
            if (type == GameMessages.InvitationPacket.InvitationPacketType.READY_TO_PLAY) {
                ConnectionManager.broadcastReadyToPlayMessage(sendToEndPointIds, mapPlayerListToEndpointList(players));

            } else if (type == GameMessages.InvitationPacket.InvitationPacketType.GAME_START) {
                ConnectionManager.broadcastGameStartMessage(sendToEndPointIds);
            }
        }
    }

    public void sendReadyToPlayAck(Player player) {
        Player host = HomeActivity.mHostPlayer;

        if (host != null) {
            ConnectionManager.sendReadyToPlayAckToHost(mapPlayerToEndPoint(player), host.getEndPointId());
        }
    }

    public List<String> getProxyPlayerEndpoints(List<Player> players) {
        List<String> proxyPlayerEndpoints = new ArrayList<>();

        for (int i = 0; i < players.size(); i++) {
            Player player = players.get(i);

            if (player.getPlayerType() == Player.Type.PROXY_PLAYER && player.getEndPointId() != null) {
                proxyPlayerEndpoints.add(player.getEndPointId());
            }
        }

        return proxyPlayerEndpoints;
    }

    private List<GameMessages.EndPoint> mapPlayerListToEndpointList(List<Player> players) {
        List<GameMessages.EndPoint> endpointList = new ArrayList<>();

        for (Player player : players) {
            endpointList.add(mapPlayerToEndPoint(player));
        }

        return endpointList;
    }

    public void broadCastPlayerDisconnectedEvent(List<Player> players, Player disconnectedPlayer) {
        List<String> endPointIds = new ArrayList<>();
        for (Player p : players) {
            endPointIds.add(p.getEndPointId());
        }
        if (endPointIds.size() > 0)
            ConnectionManager.broadcastPlayerDisconnectedEvent(endPointIds, mapPlayerToEndPoint(disconnectedPlayer));
    }

    public void broadcastRemovePlayerFromGame(List<Player> players, Player player) {
        List<String> endPointIds = new ArrayList<>();
        for (Player p : players) {
            endPointIds.add(p.getEndPointId());
        }
        if (endPointIds.size() > 0)
            ConnectionManager.removePlayerByHost(mapPlayerToEndPoint(player), endPointIds);
    }

    public void removePlayer(Player player) {
        ConnectionManager.remove(mapPlayerToEndPoint(player));
    }

    @Subscribe
    public void onImageReceivedEvent(ImageRecievedEvent event) {
        if (getMvpView() != null) {
            getMvpView().onProfilePicReceived(mapEndPointToPlayer(event.getEndPoint()), event.getImagePath());
        }
    }


    @Subscribe
    public void onNearbyEndpointInvitationEvent(NearbyInvitationEvent event) {
        if (getMvpView() != null) {
            switch (event.getType()) {
                case INVITE:
                    Player invitedByPlayer = mapEndPointToPlayer(event.getEndPoints().get(1));
                    invitedByPlayer.setEndPointId(event.getEndPoint().getEndPointId());

                    getMvpView().onInvitationReceived(invitedByPlayer, mapEndPointToPlayer(event.getEndPoints().get(0)));
                    break;

                case ACCEPT:
                    Player acceptedByPlayer = mapEndPointToPlayer(event.getEndPoints().get(1));
                    acceptedByPlayer.setEndPointId(event.getEndPoint().getEndPointId());

                    getMvpView().onInvitationAcceptByPeer(acceptedByPlayer, mapEndPointToPlayer(event.getEndPoints().get(0)));
                    break;

                case DECLINE:
                    getMvpView().onInvitationRejectByPeer(mapEndPointToPlayer(event.getEndPoint()));
                    break;

                case UPDATE_ACCEPT:
                    getMvpView().onNewPeerAccepted(mapEndPointToPlayer(event.getEndPoint()));
                    break;

                case MESH_PLAYER_INFO:
                    getMvpView().onMeshPlayerInfoReceived(mapEndPointListToPlayerList(event.getEndPoints()));
                    break;

                case PLAYER_DISCONNECTED:
                    getMvpView().onOtherPlayerDisconnected(mapEndPointToPlayer(event.getEndPoint()));
                    break;

                case PLAYER_REMOVED:
                    getMvpView().onPlayerRemovedByHost(mapEndPointToPlayer(event.getEndPoint()));
                    break;

                case REMOVED:
                    getMvpView().onRemoved();
                    break;

                case READY_TO_PLAY:
                    getMvpView().onReadyToPlayMessage(mapEndPointListToPlayerList(event.getEndPoints()));
                    break;

                case GAME_START:
                    getMvpView().onGameStartedByHost();
                    break;

                case READY_TO_PLAY_ACK:
                    getMvpView().onReadyToPlayAckMessage(mapEndPointToPlayer(event.getEndPoint()));
                    break;
            }
        }
    }

    @Subscribe
    public void onNearbyEndpointConnectionEvent(NearbyConnectionEvent event) {
        if (event.getType() == NearbyConnectionEvent.ConnectionType.CONNECTED) {
            if (getMvpView() != null)
                getMvpView().onNearbyDeviceConnected(mapEndPointToPlayer(event.getEndPoint()));
            else
                Log.e(TAG, "onNearbyEndpointConnected: getMvpView Null!!!!");
        } else if (event.getType() == NearbyConnectionEvent.ConnectionType.DISCONNECTED) {
            if (getMvpView() != null)
                getMvpView().onNearbyDeviceDisconnected(mapEndPointToPlayer(event.getEndPoint()));
            else
                Log.e(TAG, "onNearbyEndPointDisconnected: getMvpView Null!!!!");
        }
    }

    @Subscribe
    public void onNearbyGameSettingsEvent(NearbyGameSettingsEvent event) {
        if (getMvpView() != null) {
            getMvpView().onGameModeDataChanged(event.getGameMode());
        }
    }

}
