package com.w3engineers.theme.util.helper;

/**
 * Created by janisharali on 24/05/17.
 */
public final class AppUtils {
    private static final String MESSAGE_ID_SEPARATOR = "__";

    private AppUtils() {
        // This class is not publicly instantiable
    }

    public static String getUniqueId(long rowId, long headerTime) {
        return new StringBuilder().append(rowId).append(MESSAGE_ID_SEPARATOR).append(headerTime).toString();
    }

    public static String getUniqueId() {
        return java.util.UUID.randomUUID().toString();
    }

    public static String getUniqueId(String peerId) {
        return peerId + "_" + TimeUtil.currentTime();
    }
}