package com.w3engineers.theme.ludosix.ui.ludo_game.game;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import com.google.gson.Gson;

import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.data.helper.keys.PreferenceKey;
import com.w3engineers.theme.ludosix.data.local.event.GameActionEvent;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.data.local.model.ScoreBoard;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.actionMsg.GameAction;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.actionMsg.MyNameIsAction;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.actionMsg.ReadyAction;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.actionMsg.TimerAction;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.BindGameInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.ChatMessageInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.GameOverInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.IllegalMoveInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.NotYourTurnInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.StartGameInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.util.GameTimer;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.util.Tickable;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionAnimateDice;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionAnimateToken;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionAnimateTokenCut;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionChatMessage;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionMoveToken;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionRemoveFromBase;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.LudoState;
import com.w3engineers.theme.util.helper.AndroidUtil;
import com.w3engineers.theme.util.helper.SharedPref;
import com.w3engineers.theme.util.lib.internet.InternetConnectionManager;
import com.w3engineers.theme.util.lib.nearby.ConnectionManager;
import timber.log.Timber;

/**
 * A class that knows how to play the game. The data in this class represent the
 * state of a game. The state represented by an instance of this class can be a
 * complete state (as might be used by the main game activity) or a partial
 * state as it would be seen from the perspective of an individual player.
 * <p>
 * Each game has a unique state definition, so this abstract base class has
 * little inherent functionality.
 *
 * @author Steven R. Vegdahl
 * @author Andrew Nuxoll
 * @version July 2013
 */
public abstract class LocalGame implements Game, Tickable {

    // the stage that the game is in
    private GameStage gameStage = GameStage.BEFORE_GAME;

    // the handler for the game's thread
    private Handler myHandler;

    // the players in the game, in order of  player number
    public GamePlayer[] players;

    // whether the game's thread is running
    private boolean running = false;

    // the players' names, paralleling the 'players' array
    private String[] playerNames;
    private int playerNameCount = 0; // number of players who have told us their name

    // the players are ready to start
    private boolean[] playersReady;
    private int playerReadyCount = 0; // number of players who are ready to start the game

    // the players which have acknowledged that the game is over
    private boolean[] playersFinished;
    private int playerFinishedCount = 0; // number of player who have so acknowledged

    // this game's timer and timer action
    private GameTimer myTimer = new GameTimer(this);

    /**
     * Returns the game's timer
     *
     * @return the game's timer
     */
    protected final GameTimer getTimer() {
        return myTimer;
    }

    /**
     * starts the game
     *
     * @param players the list of players who are playing in the game
     */
    public void start(GamePlayer[] players) {
        // if the game has already started, don't restart
        if (this.players != null) return;

        // create/store a copy of the player array
        this.players = players.clone();

        // create an array for the players' names; these names will be
        // filled during the initial message-protocol between the game
        // and players
        this.playerNames = new String[players.length];

        // start the thread for this game
        synchronized (this) {
            // if already started, don't restart
            if (running) return;
            running = true; // mark as running

            // create a thread that loops, waiting for actions;
            // start the thread
            Runnable runnable = new Runnable() {
                public void run() {
                    Looper.prepare();
                    myHandler = new MyHandler(LocalGame.this);
                    Looper.loop();
                }
            };
            Thread thread = new Thread(runnable);
            thread.setName("Local Game");
            thread.start();
        }

        // at this point the game is running, so set our game stage to be that of
        // waiting for the players to tell us their names
        gameStage = GameStage.WAITING_FOR_NAMES;

        // start each player, telling them each who their game and playerID are
        for (int i = 0; i < players.length; i++) {
            players[i].start();
            players[i].sendInfo(new BindGameInfo(this, players[i].getPlayerInfo().getPlayerPosition()));
        }
    }

    protected Game getGame() {
        return LocalGame.this;
    }

    /**
     * Notify the given player that its state has changed. This should involve sending
     * a GameInfo object to the player. If the game is not a perfect-information game
     * this method should remove any information from the game that the player is not
     * allowed to know.
     */
    protected abstract void sendUpdatedStateToAll();

    public abstract LudoState getCurrentGameState();

    /**
     * Determines the numeric player ID (0 through whatever) for the given player.
     *
     * @param p the player whose player ID we want
     * @return the player's ID, or -1 if the player is not a player in this game
     */
    protected final int getPlayerIdx(GamePlayer p) {
        for (int i = 0; i < players.length; i++) {
            if (p == players[i]) {
                return i;
            }
        }
        return -1;
    }

    public GamePlayer getPlayerFromIndex(int index) {
        for (GamePlayer player : players) {

            if (player.getPlayerInfo().getPlayerPosition() == index) {
                return player;
            }
        }
        return players[0];
    }

    public void replacePlayer(int playerIndex, GamePlayer replacementPlayer) {
        players[playerIndex] = replacementPlayer;
        players[playerIndex].start();
        sendUpdatedStateToAll();
    }

    /**
     * Invoked whenever the game's thread receives a message (e.g., from a player
     * or from a timer).
     *
     * @param msg the message that was received
     */
    private void receiveMessage(Message msg) {
        if (msg.obj instanceof GameAction) { // ignore if not GameAction
            GameAction action = (GameAction) msg.obj;

            // CASE 1: the game is at the stage where we we waiting for
            // players to tell us their names. In this case, we expect
            // a MyNameIsAction object. Once each player have told us its
            // name, we move on to the next stage.

            if (action instanceof MyNameIsAction &&
                    gameStage == GameStage.WAITING_FOR_NAMES) {
                MyNameIsAction mnis = (MyNameIsAction) action;
                Log.i("LocalGame", "received 'myNameIs' (" + mnis.getName() + ")");

                // mark that player as having given us its name
                int playerIdx = getPlayerIdx(mnis.getPlayer());
                if (playerIdx >= 0 && playerNames[playerIdx] == null) {
                    playerNames[playerIdx] = mnis.getName(); // store player name
                    playerNameCount++;
                }

                // If all players have told us their name, then move onto the next
                // game stage, and send a message to each player that the game is
                // about to start
                if (playerNameCount >= playerNames.length) {
                    Log.i("LocalGame", "broadcasting player names");
                    gameStage = GameStage.WAITING_FOR_READY;
                    playersReady = new boolean[players.length]; // array to keep track of players responding
                    for (GamePlayer p : players) {
                        p.sendInfo(new StartGameInfo(playerNames.clone()));
                        AndroidUtil.sleep(80);
                    }
                }
            } else if (action instanceof ReadyAction &&
                    gameStage == GameStage.WAITING_FOR_READY) {

                // CASE 2: we have told all players that the game is about to start;
                // we are now processing ReadyAction messages from each player to
                // acknowledge this.
                ReadyAction ra = (ReadyAction) action;

                // mark the given player as being ready
                int playerIdx = getPlayerIdx(ra.getPlayer());
                Log.i("LocalGame", "got 'ready' (" + playerNames[playerIdx] + ")");
                if (playerIdx >= 0 && !playersReady[playerIdx]) {
                    playersReady[playerIdx] = true;
                    playerReadyCount++;
                }

                // if all players are ready, set the game stage to "during game", and
                // send each player the initial state
                if (playerReadyCount >= playerNames.length) {
                    gameStage = GameStage.DURING_GAME;
                    Log.i("LocalGame", "broadcasting initial state");
                    // send each player the initial state of the game
//                    sendAllUpdatedState();
                    sendUpdatedStateToAll();
                }
            } else if (action instanceof TimerAction && gameStage == GameStage.DURING_GAME) {

                // CASE 3: it's during the game, and we get a timer action

                // Only perform the "tick" if it was our timer; otherwise, just post the message
                if (((TimerAction) action).getTimer() == myTimer) {
                    this.timerTicked();
                } else {
                    this.checkAndHandleAction(action);
                }
            } else if (action instanceof ActionAnimateToken && gameStage == GameStage.DURING_GAME) {
                if (((ActionAnimateToken) action).getCount() > 1) {
                    AndroidUtil.sleep(150);
                }

                makeMove(action);

            } else if (action instanceof ActionAnimateTokenCut && gameStage == GameStage.DURING_GAME) {
                Log.e("cutanim", "ActionAnimateTokenCut in LocalGame");

                AndroidUtil.sleep(50);
                makeMove(action);

            } else if (action instanceof ActionChatMessage) {
                players[players.length - 1].sendInfo(new ChatMessageInfo(((ActionChatMessage) action).getMessage()));

            } else if (action instanceof GameAction && gameStage == GameStage.DURING_GAME) {

                // CASE 4: it's during the game, and we get an action from a player
                this.checkAndHandleAction(action);
            }
        }
    }

    /**
     * Handles an action that is sent to the game, checking to ensure
     * checkIfGameOver player is allowed to move, that the move is legal, etc.
     *
     * @param action the action that was sent
     */
    private void checkAndHandleAction(GameAction action) {

        // get the player and player ID
        GamePlayer player = action.getPlayer();

        if (!player.isProxy()) {
            int playerId = player.getPlayerInfo().getPlayerPosition();

            GameActionEvent gameActionEvent = null;

            if (action instanceof ActionMoveToken && canMovePiece()) {
                gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.MOVE_TOKEN, ((ActionMoveToken) action).getIndex());

            } else if (action instanceof ActionRemoveFromBase && getCurrentGameState().isCanBringOutOfStart()) {
                gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.REMOVE_FROM_BASE, ((ActionRemoveFromBase) action).getIndex());

            } else if (action instanceof ActionAnimateDice) {
                gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.ANIMATE_DICE);

            }

//            else if (player.isProxy() && action instanceof ActionRollDice) {
//                gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.ROLL_DICE, ((ActionRollDice) action).getDiceVal());
//            }

            if (gameActionEvent != null) {
                String data = new Gson().toJson(gameActionEvent);

                for (GamePlayer playerToSend : players) {
                    if (playerToSend.isProxy()) {
                        if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
                            ConnectionManager.sendGameData(data, false, playerToSend.getPlayerInfo().getEndPointId());
                        }else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
                            InternetConnectionManager.sendGameData(data, false, playerToSend.getPlayerInfo().getUserId());
                        }

                    }
                }
            }
        }

        // if the player is NOT a player who is presently allowed to
        // move, send the player a message
        if (!canMove(player.getPlayerInfo().getPlayerPosition())) {
            player.sendInfo(new NotYourTurnInfo());
            return;
        }

        // attempt to make the move; if the move was not a legal one,
        // send the player a message to that effect
        if (!makeMove(action)) {
            player.sendInfo(new IllegalMoveInfo());
            return;
        }
    }

    /**
     * Tell whether the given player is allowed to make a move at the
     * present point in the game.
     *
     * @param playerIdx the player's player-number (ID)
     * @return true iff the player is allowed to move
     */
    protected abstract boolean canMove(int playerIdx);

    protected abstract boolean canMovePiece();

    /**
     * Check if the game is over. It is over, return a string that tells
     * who the winner(s), if any, are. If the game is not over, return null;
     */
    protected abstract void checkIfGameOver();

    /**
     * Finishes up the game
     *
     * @param winnerPlayer The message that tells who, if anyone, won the game
     */
    protected void finishUpGame(Player winnerPlayer) {
        Timber.i("Finishing up game.");

        // send all players a "game over" message
        for (GamePlayer p : players) {
            // Sending game end info to non proxy players

            if (!p.isProxy() && p.requiresGui()) {
                String msg;

                if (winnerPlayer.getPlayerPosition() == p.getPlayerInfo().getPlayerPosition()) {
                    msg = "Congrats, you have won the game!";
                    updateScoreBoard(true);

                } else {
                    msg = winnerPlayer.getName() + " has won the game!";
                    updateScoreBoard(false);
                }

                p.sendInfo(new GameOverInfo(msg));
            }
        }
    }

    private void updateScoreBoard(boolean hasWon) {
        Timber.i("Updating scoreboard.");

        ScoreBoard scoreBoard = GameDataHelper.getScoreBoard();

        switch (players.length) {
            case 2:
                if (hasWon) {
                    scoreBoard.setVs2PlayersWin(scoreBoard.getVs2PlayersWin() + 1);
                } else {
                    scoreBoard.setVs2PlayersLose(scoreBoard.getVs2PlayersLose() + 1);
                }
                break;

            case 3:
                if (hasWon) {
                    scoreBoard.setVs3PlayersWin(scoreBoard.getVs3PlayersWin() + 1);
                } else {
                    scoreBoard.setVs3PlayersLose(scoreBoard.getVs3PlayersLose() + 1);
                }
                break;

            case 4:
                if (hasWon) {
                    scoreBoard.setVs4PlayersWin(scoreBoard.getVs4PlayersWin() + 1);
                } else {
                    scoreBoard.setVs4PlayersLose(scoreBoard.getVs4PlayersLose() + 1);
                }
                break;
        }

        // Saving updated scoreboard
        GameDataHelper.saveLudoScoreBoard(scoreBoard);
    }

    /**
     * Makes a move on behalf of a player.
     *
     * @param action The move that the player has sent to the game
     * @return Tells whether the move was a legal one.
     */
    protected abstract boolean makeMove(GameAction action);

    /**
     * sends a given action to the Game object
     *
     * @param action the action to send
     */
    public final void sendAction(GameAction action) {
        // wait until handler is set
        while (myHandler == null) Thread.yield();

        // package the action into a message and send it to the handler
        Message msg = new Message();
        msg.obj = action;
        myHandler.dispatchMessage(msg);
    }

    /**
     * sends a timer action to the game
     */
    public final void tick(GameTimer timer) {
        sendAction(new TimerAction(timer));
    }

    /**
     * Invoked whenever the game's timer has ticked. It is expected
     * that this will be overridden in many games.
     */
    private void timerTicked() {
        // default behavior is to do nothing
    }

    // an enum-class that itemizes the game stages
    private enum GameStage {
        BEFORE_GAME, WAITING_FOR_NAMES, WAITING_FOR_READY, DURING_GAME, GAME_OVER
    }

    // a handler class for the game's thread
    private static class MyHandler extends Handler {
        // the game
        private LocalGame game;

        // constructor; parameter is expected to be this game
        public MyHandler(LocalGame game) {
            this.game = game;
        }

        // callback when message is received; invoke the 'gameReceived' message
        public void handleMessage(Message msg) {
            game.receiveMessage(msg);
        }
    }

}// class LocalGame
