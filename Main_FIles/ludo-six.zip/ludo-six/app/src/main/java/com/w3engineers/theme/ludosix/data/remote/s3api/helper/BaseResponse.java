package com.w3engineers.theme.ludosix.data.remote.s3api.helper;

/*
 *  ****************************************************************************
 *  * Created by : Ahmed Mohmmad Ullah (Azim) on 5/4/2018 at 3:48 PM.
 *  * Email : azim@w3engineers.com
 *  *
 *  * Last edited by : Ahmed Mohmmad Ullah (Azim) on 5/4/2018.
 *  *
 *  * Last Reviewed by : <Reviewer Name> on <mm/dd/yy>
 *  ****************************************************************************
 */
public class BaseResponse {

    public int responseCode;
    public String responseMessage;

}
