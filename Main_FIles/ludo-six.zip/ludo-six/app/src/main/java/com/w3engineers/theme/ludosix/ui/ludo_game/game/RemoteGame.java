package com.w3engineers.theme.ludosix.ui.ludo_game.game;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.google.gson.Gson;

import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.data.helper.keys.PreferenceKey;
import com.w3engineers.theme.ludosix.data.local.event.GameActionEvent;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.data.local.model.ScoreBoard;
import com.w3engineers.theme.ludosix.ui.home.HomeActivity;
import com.w3engineers.theme.ludosix.ui.internet.InternetHomeActivity;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.actionMsg.GameAction;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.actionMsg.MyNameIsAction;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.BindGameInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.ChatMessageInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.GameOverInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.HostDisconnectedInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.IllegalMoveInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.NotYourTurnInfo;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionAnimateDice;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionAnimateToken;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionChatMessage;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionAnimateTokenCut;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionHostDisconnected;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionMoveToken;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.ActionRemoveFromBase;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.LudoState;
import com.w3engineers.theme.util.helper.AndroidUtil;
import com.w3engineers.theme.util.helper.SharedPref;
import com.w3engineers.theme.util.lib.internet.InternetConnectionManager;
import com.w3engineers.theme.util.lib.nearby.ConnectionManager;
import timber.log.Timber;

/**
 * A class that knows how to play the game. The data in this class represent the
 * state of a game. The state represented by an instance of this class can be a
 * complete state (as might be used by the main game activity) or a partial
 * state as it would be seen from the perspective of an individual player.
 * <p>
 * Each game has a unique state definition, so this abstract base class has
 * little inherent functionality.
 *
 * @author Steven R. Vegdahl
 * @author Andrew Nuxoll
 * @version July 2013
 */
public abstract class RemoteGame implements Game {

    // the handler for the game's thread
    private Handler myHandler;

    // the players in the game, in order of  player number
    protected GamePlayer player;
    protected GamePlayer[] players;

    protected int remoteHumanPlayerNum;

    // whether the game's thread is running
    private boolean running = false;

    /**
     * starts the game
     *
     * @param players the player who is playing the game
     */
    public void start(GamePlayer[] players) {
        // if the game has already started, don't restart
        if (this.player != null) return;

        // create/store a copy of the player array
        this.player = getHumanPlayer(players);

        this.players = players;

        // start the thread for this game
        synchronized (this) {
            // if already started, don't restart
            if (running) return;
            running = true; // mark as running

            // create a thread that loops, waiting for actions;
            // start the thread
            Runnable runnable = () -> {
                Looper.prepare();
                myHandler = new MyHandler(RemoteGame.this);
                Looper.loop();
            };

            Thread thread = new Thread(runnable);
            thread.setName("Remote Game");
            thread.start();
        }

        // start each player, telling them each who their game and playerID are

        player.start();
        player.sendInfo(new BindGameInfo(this, remoteHumanPlayerNum));

    }

    private GamePlayer getHumanPlayer(GamePlayer[] players) {

        for (GamePlayer player : players) {
            if (player.requiresGui()) {
                remoteHumanPlayerNum = player.getPlayerInfo().getPlayerPosition();
                return player;
            }
        }

        return players[0];
    }

    public GamePlayer getPlayerFromIndex(int index) {

        for (GamePlayer player1 : players) {
            if (player1.getPlayerInfo().getPlayerBasePosition() == index) {

                return player1;
            }
        }

        return players[0];
    }

    protected Game getGame() {
        return RemoteGame.this;
    }

    public GamePlayer getRemoteHumanPlayer() {
        return player;
    }

    /**
     * Notify the given player that its state has changed. This should involve sending
     * a GameInfo object to the player. If the game is not a perfect-information game
     * this method should remove any information from the game that the player is not
     * allowed to know.
     */
    protected abstract void sendUpdatedStateToPlayer();

    public abstract LudoState getCurrentGameState();

    /**
     * Invoked whenever the game's thread receives a message (e.g., from a player
     * or from a timer).
     *
     * @param msg the message that was received
     */
    private void receiveMessage(Message msg) {
        if (msg.obj instanceof GameAction) { // ignore if not GameAction
            GameAction action = (GameAction) msg.obj;

            if (action instanceof MyNameIsAction) {
                sendUpdatedStateToPlayer();

            } else if (action instanceof ActionAnimateToken) {
                if (((ActionAnimateToken) action).getCount() > 1) {
                    AndroidUtil.sleep(150);
                }

                makeMove(action);

            } else if (action instanceof ActionAnimateTokenCut) {
                AndroidUtil.sleep(50);
                makeMove(action);

            } else if (action instanceof ActionHostDisconnected) {
                player.sendInfo(new HostDisconnectedInfo());

            } else if (action instanceof ActionChatMessage) {
                player.sendInfo(new ChatMessageInfo(((ActionChatMessage) action).getMessage()));

            } else {
                checkAndHandleAction(action);
            }
        }
    }

    /**
     * Tell whether the given player is allowed to make a move at the
     * present point in the game.
     *
     * @param playerIdx the player's player-number (ID)
     * @return true iff the player is allowed to move
     */
    protected abstract boolean canMove(int playerIdx);

    protected abstract boolean canMovePiece();

    /**
     * Makes a move on behalf of a player.
     *
     * @param action The move that the player has sent to the game
     * @return Tells whether the move was a legal one.
     */
    protected abstract boolean makeMove(GameAction action);

    /**
     * Check if the game is over. It is over, return a string that tells
     * who the winner(s), if any, are. If the game is not over, return null;
     */
    protected abstract void checkIfGameOver();

    /**
     * Handles an action that is sent to the game, checking to ensure
     * checkIfGameOver player is allowed to move, that the move is legal, etc.
     *
     * @param action the action that was sent
     */
    private void checkAndHandleAction(GameAction action) {
        if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
            if (HomeActivity.mHostPlayer != null && !action.getPlayer().isProxy()) {

                GameActionEvent gameActionEvent = null;
                int playerId = player.getPlayerInfo().getPlayerBasePosition();

                if (action instanceof ActionMoveToken && canMovePiece()) {
                    gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.MOVE_TOKEN, getBaseTokenIndex(((ActionMoveToken) action).getIndex(), player.getPlayerInfo(), true));

                } else if (action instanceof ActionRemoveFromBase && getCurrentGameState().isCanBringOutOfStart()) {
                    gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.REMOVE_FROM_BASE, getBaseTokenIndex(((ActionRemoveFromBase) action).getIndex(), player.getPlayerInfo(), true));

                } else if (action instanceof ActionAnimateDice) {
                    gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.ANIMATE_DICE);
                }

                if (gameActionEvent != null) {
                    String data = new Gson().toJson(gameActionEvent);
                        ConnectionManager.sendGameData(data, false, HomeActivity.mHostPlayer.getEndPointId());
                }
            }
        }else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
            if (InternetHomeActivity.mHostPlayer != null && !action.getPlayer().isProxy()) {

                GameActionEvent gameActionEvent = null;
                int playerId = player.getPlayerInfo().getPlayerBasePosition();

                if (action instanceof ActionMoveToken && canMovePiece()) {
                    gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.MOVE_TOKEN, getBaseTokenIndex(((ActionMoveToken) action).getIndex(), player.getPlayerInfo(), true));

                } else if (action instanceof ActionRemoveFromBase && getCurrentGameState().isCanBringOutOfStart()) {
                    gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.REMOVE_FROM_BASE, getBaseTokenIndex(((ActionRemoveFromBase) action).getIndex(), player.getPlayerInfo(), true));

                } else if (action instanceof ActionAnimateDice) {
                    gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.ANIMATE_DICE);
                }

                if (gameActionEvent != null) {
                    String data = new Gson().toJson(gameActionEvent);
                        InternetConnectionManager.sendGameData(data, false, InternetHomeActivity.mHostPlayer.getUserId());
                }
            }
        }


        // get the player and player ID
        GamePlayer player = action.getPlayer();

        // if the player is NOT a player who is presently allowed to
        // move, send the player a message
        if (!canMove(player.getPlayerInfo().getPlayerPosition())) {
            player.sendInfo(new NotYourTurnInfo());
            return;
        }

        // attempt to make the move; if the move was not a legal one,
        // send the player a message to that effect
        if (!makeMove(action)) {
            player.sendInfo(new IllegalMoveInfo());
            return;
        }
    }

    public int getBaseTokenIndex(int currentIndex, Player player, boolean isfromRemoteGame) {
        int difference = (player.getPlayerBasePosition() - player.getPlayerPosition());

        if (isfromRemoteGame) {
            return currentIndex + (difference * 4);

        } else {
            return currentIndex - (difference * 4);
        }
    }

    /**
     * Finishes up the game
     *
     * @param winnerPlayer The message that tells who, if anyone, won the game
     */
    protected void finishUpGame(Player winnerPlayer) {
        Timber.i("Finishing up game.");

        // send all players a "game over" message
        for (GamePlayer p : players) {
            // Sending game end info to non proxy players

            if (!p.isProxy() && p.requiresGui()) {
                String msg;

                if (winnerPlayer.getPlayerPosition() == p.getPlayerInfo().getPlayerPosition()) {
                    msg = "Congrats, you have won the game!";
                    updateScoreBoard(true);

                } else {
                    msg = winnerPlayer.getName() + " has won the game!";
                    updateScoreBoard(false);
                }

                p.sendInfo(new GameOverInfo(msg));
            }
        }
    }

    private void updateScoreBoard(boolean hasWon) {
        Timber.i("Updating scoreboard.");

        ScoreBoard scoreBoard = GameDataHelper.getScoreBoard();

        switch (players.length) {
            case 2:
                if (hasWon) {
                    scoreBoard.setVs2PlayersWin(scoreBoard.getVs2PlayersWin() + 1);
                } else {
                    scoreBoard.setVs2PlayersLose(scoreBoard.getVs2PlayersLose() + 1);
                }
                break;

            case 3:
                if (hasWon) {
                    scoreBoard.setVs3PlayersWin(scoreBoard.getVs3PlayersWin() + 1);
                } else {
                    scoreBoard.setVs3PlayersLose(scoreBoard.getVs3PlayersLose() + 1);
                }
                break;

            case 4:
                if (hasWon) {
                    scoreBoard.setVs4PlayersWin(scoreBoard.getVs4PlayersWin() + 1);
                } else {
                    scoreBoard.setVs4PlayersLose(scoreBoard.getVs4PlayersLose() + 1);
                }
                break;
        }

        // Saving updated scoreboard
        GameDataHelper.saveLudoScoreBoard(scoreBoard);
    }

    /**
     * sends a given action to the Game object
     *
     * @param action the action to send
     */
    public final void sendAction(GameAction action) {
        // wait until handler is set
        while (myHandler == null) Thread.yield();

        // package the action into a message and send it to the handler
        Message msg = new Message();
        msg.obj = action;
        myHandler.dispatchMessage(msg);
    }

    // a handler class for the game's thread
    private static class MyHandler extends Handler {
        // the game
        private RemoteGame game;

        // constructor; parameter is expected to be this game
        public MyHandler(RemoteGame game) {
            this.game = game;
        }

        // callback when message is received; invoke the 'gameReceived' message
        public void handleMessage(Message msg) {
            game.receiveMessage(msg);
        }
    }

}