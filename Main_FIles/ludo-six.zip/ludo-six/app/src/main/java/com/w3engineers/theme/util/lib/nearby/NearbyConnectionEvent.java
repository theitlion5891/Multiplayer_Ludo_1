package com.w3engineers.theme.util.lib.nearby;

import com.left.core.util.lib.nearby.GameMessages.EndPoint;

/**
 * Created by pl@b0n on 11/20/2018.
 */
public class NearbyConnectionEvent {

    public NearbyConnectionEvent(ConnectionType type, EndPoint endPoint) {
        this.type = type;
        this.endPoint = endPoint;
    }

    public enum ConnectionType {CONNECTED,DISCONNECTED}
    private ConnectionType type;
    private EndPoint endPoint;

    public ConnectionType getType() {
        return type;
    }

    public void setType(ConnectionType type) {
        this.type = type;
    }

    public EndPoint getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(EndPoint endPoint) {
        this.endPoint = endPoint;
    }

}
