package com.w3engineers.theme.ludosix.data.helper.keys;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/26/2018 at 3:38 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Game mood interface class
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 11/26/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 11/26/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public interface GameMode {
    int TWO_PLAYER = 2;
    int THREE_PLAYER = 3;
    int FOUR_PLAYER = 4;
}
