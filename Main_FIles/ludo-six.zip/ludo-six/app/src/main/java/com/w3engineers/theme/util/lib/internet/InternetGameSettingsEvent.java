package com.w3engineers.theme.util.lib.internet;

import com.w3engineers.theme.util.lib.internet.enumkeys.InternetGameModeType;

public class InternetGameSettingsEvent {
    private InternetGameModeType gameMode;


    public InternetGameSettingsEvent(InternetGameModeType gameMode) {
        this.gameMode = gameMode;
    }

    public InternetGameModeType getGameMode() {
        return gameMode;
    }

    public void setGameMode(InternetGameModeType gameMode) {
        this.gameMode = gameMode;
    }
}
