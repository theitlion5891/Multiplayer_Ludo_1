package com.w3engineers.theme.util.lib.internet.enumkeys;

public enum InternetDataType {
    INVITATION_DATA,
    USER_DATA,
    GAME_SETTINGS,
    GAME_DATA
}
