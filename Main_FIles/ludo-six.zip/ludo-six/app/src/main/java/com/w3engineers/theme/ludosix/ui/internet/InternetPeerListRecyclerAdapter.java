package com.w3engineers.theme.ludosix.ui.internet;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.util.helper.Glider;

import java.util.List;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/13/2018 at 4:33 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Recycler adapter class for nearby peers
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 11/13/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 11/13/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */

public class InternetPeerListRecyclerAdapter extends RecyclerView.Adapter<InternetPeerListRecyclerAdapter.ItemRowHolder> {

    private static final String TAG = "PeerListRecyclerAdapter";
    private List<Player> mDataList;
    private Context mContext;
    private ItemClickListener mListener;

    public InternetPeerListRecyclerAdapter(List<Player> mDataList, Context mContext) {
        this.mDataList = mDataList;
        this.mContext = mContext;
        this.mListener = (ItemClickListener) mContext;
    }

    @NonNull
    @Override
    public ItemRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_nearby_peers, parent, false);
        return new ItemRowHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemRowHolder holder, int position) {
        Player player = mDataList.get(position);
        holder.list_item_nearby_peers_player_name_tv.setText(player.getName());

        if (player.getImagePath() != null) {
            Glider.showCircleImage(player.getImagePath(), holder.list_item_nearby_peers_player_image_civ);
        } else {
            holder.list_item_nearby_peers_player_image_civ.setImageResource(R.drawable.ic_avatar);
        }

        switch (player.getState()) {
            case IN_GAME:
                holder.list_item_nearby_peers_waiting_lav.setVisibility(View.GONE);
                holder.list_item_nearby_peers_player_add_ib.setVisibility(View.VISIBLE);
                holder.list_item_nearby_peers_player_add_ib.setImageResource(R.drawable.ic_tick);
                break;

            case PENDING:
                holder.list_item_nearby_peers_player_add_ib.setVisibility(View.INVISIBLE);
                holder.list_item_nearby_peers_waiting_lav.setVisibility(View.VISIBLE);
                break;

            case NOT_IN_GAME:
                holder.list_item_nearby_peers_waiting_lav.setVisibility(View.GONE);
                holder.list_item_nearby_peers_player_add_ib.setVisibility(View.VISIBLE);
                holder.list_item_nearby_peers_player_add_ib.setImageResource(R.drawable.ic_add);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    class ItemRowHolder extends RecyclerView.ViewHolder {
        private ImageButton list_item_nearby_peers_player_add_ib;
        private TextView list_item_nearby_peers_player_name_tv;
        private CircularImageView list_item_nearby_peers_player_image_civ;
        private LottieAnimationView list_item_nearby_peers_waiting_lav;

        ItemRowHolder(View itemView) {
            super(itemView);
            list_item_nearby_peers_player_image_civ = itemView.findViewById(R.id.list_item_nearby_peers_player_image_civ);
            list_item_nearby_peers_player_name_tv = itemView.findViewById(R.id.list_item_nearby_peers_player_name_tv);
            list_item_nearby_peers_player_add_ib = itemView.findViewById(R.id.list_item_nearby_peers_player_add_ib);
            list_item_nearby_peers_waiting_lav = itemView.findViewById(R.id.list_item_nearby_peers_waiting_lav);

            // Player add button click listener
            list_item_nearby_peers_player_add_ib.setOnClickListener(view ->
                    mListener.onItemClick(view, mDataList.get(getAdapterPosition())));
        }
    }

    /**
     * Interface listener class for list item click events
     */
    public interface ItemClickListener {
        void onItemClick(View view, Player player);
    }
}