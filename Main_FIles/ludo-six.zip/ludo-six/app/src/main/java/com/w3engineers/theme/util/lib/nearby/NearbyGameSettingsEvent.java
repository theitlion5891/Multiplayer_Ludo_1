package com.w3engineers.theme.util.lib.nearby;

import com.left.core.util.lib.nearby.GameMessages;
import com.left.core.util.lib.nearby.GameMessages.EndPoint;

/**
 * Created by pl@b0n on 11/20/2018.
 */
public class NearbyGameSettingsEvent {

    private GameMessages.GameSettingsPacket.GameMode gameMode;


    public NearbyGameSettingsEvent(GameMessages.GameSettingsPacket.GameMode gameMode) {
        this.gameMode = gameMode;
    }

    public GameMessages.GameSettingsPacket.GameMode getGameMode() {
        return gameMode;
    }

    public void setGameMode(GameMessages.GameSettingsPacket.GameMode gameMode) {
        this.gameMode = gameMode;
    }
}
