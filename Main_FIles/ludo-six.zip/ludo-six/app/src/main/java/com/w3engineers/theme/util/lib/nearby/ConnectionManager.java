package com.w3engineers.theme.util.lib.nearby;

import android.util.Log;

import com.google.android.gms.nearby.connection.Payload;
import com.left.core.util.lib.nearby.GameMessages;
import com.left.core.util.lib.nearby.GameMessages.EndPoint;

import java.util.List;


/**
 * Created by pl@b0n on 11/22/2018.
 */
public class ConnectionManager {

    private static final String TAG = "ConnectionManager";

    public static void sendInvitation(List<EndPoint> endPoints) {
        Log.d(TAG, "sendInvitation: ");
        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.INVITE)
                .addAllEndpoints(endPoints)
                .build();

        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();

        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), endPoints.get(0));
    }

    public static void sendGameData(String data, boolean isGameInfo, String endPointId) {
        GameMessages.GameDataPacket gameDataPacket = GameMessages.GameDataPacket.newBuilder()
                .setData(data)
                .setDataType(isGameInfo ? GameMessages.GameDataPacket.DataType.GAME_INFO : GameMessages.GameDataPacket.DataType.GAME_ACTION)
                .build();

        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setGameData(gameDataPacket)
                .setPacketType(GameMessages.PacketType.GAME_DATA)
                .build();

        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), endPointId, 1);
    }

    public static void sendInvitationAccept(List<EndPoint> endPoints) {
        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .addAllEndpoints(endPoints)
                .setType(GameMessages.InvitationPacket.InvitationPacketType.ACCEPT)
                .build();
        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();
        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), endPoints.get(0));
    }

    public static void sendInvitationDecline(EndPoint endPoint) {
        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.DECLINE)
                .build();
        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();
        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), endPoint);
    }

    /**
     * Send mesh update(new endpoint added) to specified endpoints
     *
     * @param endpointIds
     * @param endpoint
     */
    public static void sendUpdateAccept(List<String> endpointIds, EndPoint endpoint) {
        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.UPDATE_ACCEPT)
                .setEndpoint(endpoint)
                .build();
        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();
        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), endpointIds);
    }

    public static void sendPlayersInfoToNewPlayer(List<EndPoint> endPoints, EndPoint targetEndPoint) {
        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.MESH_PLAYER_INFO)
                .addAllEndpoints(endPoints)
                .build();
        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();
        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), targetEndPoint);
    }

    public static void broadCastImagesUpdate(List<String> endPointIds, EndPoint owner, String imagePath) {
        for (String endPointId : endPointIds) {
            ConnectivityProvider.getConnectivity().startSendingImage(endPointId, owner, imagePath);
        }
    }

    public static void sendInGamePlayerImagesToNewPlayer(List<EndPoint> endPoints, EndPoint destinationEndPoint) {
        for (EndPoint endPoint : endPoints) {
            ConnectivityProvider.getConnectivity().startSendingImage(destinationEndPoint, endPoint, endPoint.getImagePath());
        }
    }

    public static void sendGameSettingsToPlayers(List<String> endPointIds, GameMessages.GameSettingsPacket.GameMode gameMode) {
        GameMessages.GameSettingsPacket gameSettingsPacket = GameMessages.GameSettingsPacket.newBuilder()
                .setGameMode(gameMode)
                .build();
        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setGameSettingsPacket(gameSettingsPacket)
                .setPacketType(GameMessages.PacketType.GAME_SETTINGS)
                .build();
        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), endPointIds);
    }

    public static void broadcastReadyToPlayMessage(List<String> sendToEndPointIds, List<EndPoint> gamePlayerList) {
        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.READY_TO_PLAY)
                .addAllEndpoints(gamePlayerList)
                .build();

        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();

        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), sendToEndPointIds);
    }

    public static void broadcastGameStartMessage(List<String> sendToEndPointIds) {
        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.GAME_START)
                .build();

        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();

        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), sendToEndPointIds);
    }

    public static void sendReadyToPlayAckToHost(EndPoint endPoint, String hostEndpointId) {
        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.READY_TO_PLAY_ACK)
                .setEndpoint(endPoint)
                .build();

        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();

        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), hostEndpointId, 0);
    }

    public static void broadcastPlayerDisconnectedEvent(List<String> endPointIds, EndPoint endPoint) {
        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.PLAYER_DISCONNECTED)
                .setEndpoint(endPoint)
                .build();
        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();
        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), endPointIds);
    }


    public static void removePlayerByHost(EndPoint endPoint, List<String> endPointIds) {
        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.PLAYER_REMOVED)
                .setEndpoint(endPoint)
                .build();
        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();
        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), endPointIds);
    }

    public static void remove(EndPoint targetEndPoint) {
        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.REMOVED)
                .build();
        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();
        ConnectivityProvider.getConnectivity().send(Payload.fromBytes(dataPacket.toByteArray()), targetEndPoint);
    }

}
