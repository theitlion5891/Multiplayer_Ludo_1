package com.w3engineers.theme.ludosix.ui.app_tutorial;

import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.appcompat.content.res.AppCompatResources;

import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.github.paolorotolo.appintro.AppIntro2;
import com.github.paolorotolo.appintro.AppIntroFragment;
import com.github.paolorotolo.appintro.model.SliderPage;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.ui.signup.SignUpActivity;
import com.w3engineers.theme.util.helper.ScreenUtils;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 1/4/2019 at 11:14 AM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: This class shows app tutorial pages
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 1/4/2019.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 1/4/2019.
 * Copyright (c) 2019, W3 Engineers Ltd. All rights reserved.
 */
public class TutorialActivity extends AppIntro2 {

    private static final int TOTAL_PAGES = 10;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Making the activity full screen in IMMERSIVE_STICKY fullscreen mode
        ScreenUtils.hideSystemUI(this);

        // Creating pages based on total page number
        for (int i = 0; i < TOTAL_PAGES; i++) {
            addSlide(AppIntroFragment.newInstance(new SliderPage()));
        }

        // Setting button custom images
        ((ImageButton) findViewById(R.id.skip)).setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.ic_skip_text));
        ((ImageButton) findViewById(R.id.next)).setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.ic_next_text));
        ((ImageButton) findViewById(R.id.done)).setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.ic_done_text));
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            ScreenUtils.hideSystemUI(this);
        }
    }

    @Override
    public void onSkipPressed(Fragment currentFragment) {
        super.onSkipPressed(currentFragment);

        if (GameDataHelper.getUserInfo() == null) {
            SignUpActivity.runActivity(this);
        }

        finish();
    }

    @Override
    public void onDonePressed(Fragment currentFragment) {
        super.onDonePressed(currentFragment);

        if (GameDataHelper.getUserInfo() == null) {
            SignUpActivity.runActivity(this);
        }

        finish();
    }

    @Override
    protected void onPageSelected(int position) {
        super.onPageSelected(position);

        // Changing background image based on page number
        setImageBackground(position);
    }

    /**
     * Sets background image based on page number
     *
     * @param page is the current page number
     */
    private void setImageBackground(int page) {

        switch (page) {
            case 0:
                setBackgroundView(getImageView(R.drawable.image_tutorial_page1));
                break;

            case 1:
                setBackgroundView(getImageView(R.drawable.image_tutorial_page10));
                break;

            case 2:
                setBackgroundView(getImageView(R.drawable.image_tutorial_page7));
                break;

            case 3:
                setBackgroundView(getImageView(R.drawable.image_tutorial_page2));
                break;

            case 4:
                setBackgroundView(getImageView(R.drawable.image_tutorial_page3));
                break;

            case 5:
                setBackgroundView(getImageView(R.drawable.image_tutorial_page4));
                break;

            case 6:
                setBackgroundView(getImageView(R.drawable.image_tutorial_page5));
                break;

            case 7:
                setBackgroundView(getImageView(R.drawable.image_tutorial_page6));
                break;

            case 8:
                setBackgroundView(getImageView(R.drawable.image_tutorial_page8));
                break;

            case 9:
                setBackgroundView(getImageView(R.drawable.image_tutorial_page9));
                break;

            default:
                setBackgroundView(getImageView(R.drawable.image_tutorial_page1));
        }
    }

    /**
     * Creates an ImageView instance containing passed image resource
     *
     * @param imageRes is image to create ImageView with
     * @return the created ImageView instance
     */
    private ImageView getImageView(int imageRes) {
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(imageRes);

        imageView.setBackgroundColor(Color.BLACK);
        imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        imageView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        return imageView;
    }
}
