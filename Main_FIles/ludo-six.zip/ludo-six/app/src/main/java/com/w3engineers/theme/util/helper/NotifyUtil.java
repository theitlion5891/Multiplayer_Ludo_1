package com.w3engineers.theme.util.helper;



/*
*  ****************************************************************************
*  * Created by : Md. Azizul Islam on 1/23/2018 at 11:24 AM.
*  * Email : azizul@w3engineers.com
*  *
*  * Last edited by : Mohd. Asfaq-E-Azam Rifat on 29-Jan-18.
*  *
*  * Last Reviewed by : <Reviewer Name> on <mm/dd/yy>
*  ****************************************************************************
*/

public class NotifyUtil {
    // Static constants
    public static final String REPLY_ACTION = "io.left.core.utils.reply";
    public static final String MAKE_AS_READ = "io.left.core.utils.read";
    public static final String MAKE_SEEN = "seen";
    public static final String NOTIFICATION_ID = "notify_id";
    public static final int NOTIFICATION_ID_New = 1;
}
