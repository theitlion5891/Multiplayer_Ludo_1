package com.w3engineers.theme.ludosix.ui.ludo_game.ludo;

import com.w3engineers.theme.ludosix.ui.ludo_game.game.GamePlayer;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.actionMsg.GameAction;

/**
 * ActionMoveToken class
 * Game action that is sent to LudoLocalgame
 */
public class ActionAnimateTokenCut extends GameAction {

    /**
     * constructor for GameAction
     *
     * @param player the player who created the action
//     * @param index  index of piece
     */
    public ActionAnimateTokenCut(GamePlayer player) {
        super(player);
    }
}
