package com.w3engineers.theme.util.lib.internet;

import com.left.core.util.lib.nearby.GameMessages;
import com.w3engineers.theme.ludosix.data.local.model.Player;

public class InternetImageReceivedEvent {
    Player endPoint;
    String imagePath;

    public InternetImageReceivedEvent(Player endPoint, String imagePath) {
        this.endPoint = endPoint;
        this.imagePath = imagePath;
    }

    public Player getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(Player endPoint) {
        this.endPoint = endPoint;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}
