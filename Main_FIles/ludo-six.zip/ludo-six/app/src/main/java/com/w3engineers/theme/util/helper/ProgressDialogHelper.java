package com.w3engineers.theme.util.helper;

import android.app.Activity;
import android.app.ProgressDialog;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 9/11/2018 at 6:06 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Progress dialog helper class
 * Last edited by : Rezwanur on 10/22/18.
 * Last Reviewed by : Rezwanur on 10/22/18.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class ProgressDialogHelper {

    private ProgressDialog mProgressDialog;

    public ProgressDialogHelper(Activity context) {
        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setCancelable(true);
        mProgressDialog.setIndeterminate(true);
    }

    public void show(String text) {
        if (mProgressDialog != null && !mProgressDialog.isShowing()) {
            mProgressDialog.setMessage(text);
            mProgressDialog.show();
        }
    }

    public void hide() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.dismiss();
        }
    }
}
