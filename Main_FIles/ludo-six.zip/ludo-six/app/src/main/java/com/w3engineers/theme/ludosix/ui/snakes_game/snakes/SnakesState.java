package com.w3engineers.theme.ludosix.ui.snakes_game.snakes;

import android.util.SparseArray;
import android.util.SparseIntArray;

import java.util.ArrayList;
import java.util.Random;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.keys.PreferenceKey;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.home.HomeActivity;
import com.w3engineers.theme.ludosix.ui.internet.InternetHomeActivity;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.Game;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.GamePlayer;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg.GameState;
import com.w3engineers.theme.util.helper.SharedPref;
import com.w3engineers.theme.util.helper.ToneFactory;
import com.w3engineers.theme.util.lib.internet.ConnectivityInternetProvider;
import com.w3engineers.theme.util.lib.nearby.ConnectivityProvider;
import timber.log.Timber;

/**
 * Ludo State
 * This contains the official state for the Ludo Game.
 * based on GameFramework by Steven R. Vegdahl
 * CounterGame
 * TickTackToe2
 * PigGame - implemented by us in lab
 *
 * @author Raj Nayyar
 * @author Avery Guillermo
 * @author Luke Danowski
 * @author Chris Sebrechts
 */

public class SnakesState extends GameState {

    //instance variables
    private Random dice;
    private int diceVal;

    private boolean isRollable;
    protected Token[] pieces;

    private int numPlayers;
    private ArrayList<Player> playerList;

    private int playerID_active;
    private int[] playerScore;

    private boolean stillPlayersTurn;
    private boolean canBringOutOfStart;

    private boolean canMovePiece;
    private boolean scoredAPoint;
    private boolean shouldSkipActions = false;

    private int index;
    private int lastActivePlayer;
    private SparseArray<float[][]> pathMap;
    private SparseIntArray indexMap;
    private Game game;

    public enum Action {ANIMATE_TOKEN, ANIMATE_TOKEN_CUT, ANIMATE_DICE}

    private int count;
    private Action action;

    /**
     * LudoState
     * Initializing the entire state on its first creation
     */
    public SnakesState(ArrayList<Player> playerList) {
        scoredAPoint = false;
        canMovePiece = false;

        stillPlayersTurn = false;
        numPlayers = playerList.size();
        this.playerList = playerList;

        dice = new Random();
        diceVal = 1;
        isRollable = true;

        if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
            if (ConnectivityProvider.getConnectivity().getCurrentRole() == ConnectivityProvider.ConnectionRole.CLIENT && HomeActivity.mHostPlayer != null) {
                playerID_active = getActivePlayerId();

            } else {
                playerID_active = 0;
            }
        }else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
            if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.CLIENT && InternetHomeActivity.mHostPlayer != null) {
                playerID_active = getActivePlayerId();

            } else {
                playerID_active = 0;
            }
        }



        pieces = new Token[]{
                new Token(0), //red piece
                new Token(1), //blue piece
                new Token(2), //yellow piece
                new Token(3)}; //green piece

        //scores are 0;
        playerScore = new int[]{0, 0, 0, 0};

        indexMap = new SparseIntArray();
        // Ladder index map
        indexMap.put(3, 13);
        indexMap.put(8, 30);
        indexMap.put(19, 37);
        indexMap.put(27, 83);
        indexMap.put(39, 58);
        indexMap.put(62, 80);
        indexMap.put(70, 90);

        // Snakes index map
        indexMap.put(16, 6);
        indexMap.put(61, 17);
        indexMap.put(53, 33);
        indexMap.put(63, 59);
        indexMap.put(98, 77);
        indexMap.put(94, 74);
        indexMap.put(92, 72);
        indexMap.put(86, 23);

        pathMap = new SparseArray<>();
        // Ladder path map
        pathMap.put(3, new float[][]{{3, 9}, {4, 8.6f}, {5, 8.3f}});
        pathMap.put(8, new float[][]{{8, 9}, {8.4f, 8}, {8.8f, 7}});
        pathMap.put(19, new float[][]{{0, 8}, {1, 7}});
        pathMap.put(27, new float[][]{{7, 7}, {6.4f, 6}, {5.7f, 5}, {5, 4}, {4.3f, 3}, {3.7f, 2}});
        pathMap.put(39, new float[][]{{0, 6}, {0.5f, 5}});
        pathMap.put(62, new float[][]{{2, 3}, {1, 2}});
        pathMap.put(70, new float[][]{{9, 2}, {9, 1}});

        // Snakes path map
        pathMap.put(16, new float[][]{{3, 8}, {4, 8.7f}, {5, 8.9f}});
        pathMap.put(61, new float[][]{{1, 3}, {1.1f, 4.5f}, {1.8f, 5.4f}, {1.6f, 6.5f}});
        pathMap.put(63, new float[][]{{3, 3}, {2, 3}, {1, 3.6f}});
        pathMap.put(53, new float[][]{{6, 4}, {6.6f, 4.5f}, {6.2f, 5.1f}});
        pathMap.put(98, new float[][]{{1, 0}, {1.8f, 0.6f}, {2.5f, 1}});
        pathMap.put(94, new float[][]{{5, 0}, {4.5f, 0.5f}, {4.8f, 1.2f}});
        pathMap.put(92, new float[][]{{7, 0}, {7.5f, 0.6f}, {8.2f, 1.2f}});
        pathMap.put(86, new float[][]{{6, 1}, {5.3f, 2}, {5.5f, 3}, {5, 3.6f}, {4.3f, 4.5f}, {4, 5.7f}});
    }

    private int getActivePlayerId() {
        for (int i = 0; i < numPlayers; i++) {

            if (playerList.get(i).getPlayerBasePosition() == 0) {
                return playerList.get(i).getPlayerPosition();
            }
        }

        return -1;
    }


    public GamePlayer getGamePlayer() {
        return gamePlayer;
    }

    public void setGamePlayer(GamePlayer gamePlayer) {
        this.gamePlayer = gamePlayer;
    }

    private GamePlayer gamePlayer;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    /**
     * Ludostate
     * copies the entire game state
     * (It is a copy constructor)
     *
     * @param original the object from which the copy should be made
     */
    public SnakesState(SnakesState original) {
        this.scoredAPoint = original.scoredAPoint;
        this.canMovePiece = original.canMovePiece;
        this.numPlayers = original.numPlayers;
        this.playerList = original.playerList;
        this.playerID_active = original.playerID_active;
        this.dice = original.dice;
        this.diceVal = original.diceVal;
        this.isRollable = original.isRollable;
        this.stillPlayersTurn = original.stillPlayersTurn;

        //set the piece array
        this.pieces = new Token[original.pieces.length];
        for (int i = 0; i < original.pieces.length; i++) {
            pieces[i] = new Token(original.pieces[i]);
        }

        //set the scores
        this.playerScore = new int[original.playerScore.length];
        for (int i = 0; i < original.playerScore.length; i++) {
            this.playerScore[i] = original.playerScore[i];
        }

    }

    public void setPlayerList(ArrayList<Player> playerList) {
        this.playerList = playerList;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public Action getAction() {
        return this.action;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getLastActivePlayer() {
        return lastActivePlayer;
    }

    public void setLastActivePlayer(int lastActivePlayer) {
        this.lastActivePlayer = lastActivePlayer;
    }

    /**
     * getWhoseMove
     * Tells whose move it is.
     *
     * @return the index (0 or 1) of the player whose move it is.
     */
    public int getWhoseMove() {
        return playerID_active;
    }


    /**
     * getPlayerScore
     * getter method for score
     *
     * @return score array
     */
    public int getPlayerScore(int index) {
        return playerScore[index];
    }

    /**
     * getNumplayers
     * getter method for numPlayers
     *
     * @return number of active players
     */
    public int getNumPlayers() {
        return numPlayers;
    }

    public ArrayList<Player> getPlayerList() {
        return playerList;
    }

    /**
     * newRoll
     * generates a new random roll if player is allowed to play.
     * considers if it is their turn and if roll a 6, they get to roll again
     * <p>
     * //     * @param playerID who sent action
     *
     * @return is move possible with current roll
     */
    public boolean newRoll() {
        if (isRollable) {
            diceVal = dice.nextInt(6) + 1;

//            if (GameDataHelper.getSoundVolume() > 0) {
//                diceVal = dice.nextInt(6) + 1;
//
//            } else {
//                diceVal = 1;
//            }

            isRollable = !isRollable;
            //if no moves exist based on diceVal just go to next player
            updateMovesAvailable();
            return true;
        }
        return false;
    }

    public boolean newCustomRoll(int diceValue) {
        if (isRollable) {

            diceVal = diceValue;
            isRollable = !isRollable;

            //if no moves exist based on diceVal just go to next player
            updateMovesAvailable();
            return true;
        }
        return false;
    }

    /**
     * updateMovesAvailable
     * Called after a dice roll. We go through the active player's pieces and checks for pieces
     * which can move by the rules of the game, each piece has a boolean which is changed to
     * reflect the outcome of the check;
     *
     * @return true if valid moves exist
     */
    private void updateMovesAvailable() {
        Token piece = pieces[playerID_active];

        //first, check the pieces in home base
        if (piece.getIsHome() && diceVal == 1) {
            piece.setIsMovable(true);
            piece.setIsHome(false);
            piece.setShouldHighlight(true);

        } else if (!piece.getIsHome() && (piece.getNumSpacesMoved() + diceVal) <= 99) {
            //in home stretch and total will be less than or equal to 56
            piece.setIsMovable(true);
            piece.setShouldHighlight(false);

        } else {
            piece.setIsMovable(false);
        }
    }


    /**
     * increments player score
     * increments player score
     */
    public void incPlayerScore(int playerID) {
        playerScore[playerID]++;
    }

    /**
     * changePlayerTurn
     * <p>
     * this changes the players turn
     */
    public void changePlayerTurn() {
        this.stillPlayersTurn = false;
        this.isRollable = true;

        lastActivePlayer = getWhoseMove();
        canMovePiece = false; // Now that the player moved the token, the player can't use the diceVal to move anymore!

        if (numPlayers == 2) {
            if (playerID_active == 0) {
                playerID_active = 2;

            } else {
                playerID_active = 0;
            }

        } else {
            if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
                if (ConnectivityProvider.getConnectivity().getCurrentRole() == ConnectivityProvider.ConnectionRole.CLIENT && HomeActivity.mHostPlayer != null) {
                    getNextActivePlayerId();

                } else {
                    if ((++playerID_active) >= numPlayers) {
                        playerID_active = 0;
                    }
                }
            }else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
                if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.CLIENT && InternetHomeActivity.mHostPlayer != null) {
                    getNextActivePlayerId();

                } else {
                    if ((++playerID_active) >= numPlayers) {
                        playerID_active = 0;
                    }
                }
            }

        }
    }

    private void getNextActivePlayerId() {
        if (playerID_active != -1) {
            int nextPlayerId = (playerID_active == 3) ? 0 : (playerID_active + 1);

            if (isActivePlayerIdValid(nextPlayerId)) {
                playerID_active = nextPlayerId;

            } else {
                playerID_active = nextPlayerId + 1;
            }

            Timber.i("Active player id: %d", playerID_active);

        }
    }

    private boolean isActivePlayerIdValid(int id) {
        for (int i = 0; i < numPlayers; i++) {

            if (playerList.get(i).getPlayerPosition() == id)
                return true;
        }

        return false;
    }

    public void setIsRollable(boolean bol) {
        this.isRollable = bol;
    }


    /**
     * advanceToken
     * This advances the token
     * it determines if a piece can move while within the homestretch row.
     *
     * @param playerID
     * @return
     */
    public boolean advanceToken(int playerID) {
        Token piece = pieces[playerID];

        if (shouldSkipActions) {
            canMovePiece = false;
            piece.incNumSpacesMoved(1);

            return true;

        } else {
            //only act on movable pieces. Always updated after each dice roll.
            if (piece.getIsMovable()) {
                setAction(null);

                if (diceVal > 1) {
                    piece.incNumSpacesMoved(-(diceVal - 1));
                }

                piece.incNumSpacesMoved(diceVal);
                int spacesPieceHasTraveled = piece.getNumSpacesMoved();

                if (spacesPieceHasTraveled == 99) {
                    incPlayerScore(playerID);

                    ToneFactory.on().play(R.raw.reach_home);
                    Timber.i("Player: " + playerID + " Scored a Point" + "Score: " + playerScore[playerID]);
                    return true;
                }

                float[][] snakeLadderPath = pathMap.get(spacesPieceHasTraveled);

                // Checking if token stepped over any ladder or snake
                if (snakeLadderPath != null) {
                    piece.setPath(snakeLadderPath);
                    setIndex(indexMap.get(spacesPieceHasTraveled)); // Path end index
                    setAction(Action.ANIMATE_TOKEN_CUT);

                    if (spacesPieceHasTraveled == 3 || spacesPieceHasTraveled == 8 || spacesPieceHasTraveled == 19 ||
                            spacesPieceHasTraveled == 27 || spacesPieceHasTraveled == 39
                            || spacesPieceHasTraveled == 62 || spacesPieceHasTraveled == 70) {
                        ToneFactory.on().play(R.raw.ladder_climb);

                    } else {
                        ToneFactory.on().play(R.raw.snake_cut);
                    }

                } else {
                    //Change the current player's turn!
                    changePlayerTurn();
                }

                return true;

            } else {
                //do nothing
                return true;
            }
        }
    }

    /**
     * toString
     *
     * @return
     */
    @Override
    public String toString() {
        String output = "";
        for (int i = 0; i < 4; i++) {
            output += "\nPlayer " + pieces[i].getOwner() + ": ";
            for (int j = i; j < 16; j += 4) {
                output += "\nPiece " + (j - i) / 4 + " at " + pieces[j].getNumSpacesMoved() +
                        " and " + (pieces[j].getIsHome() ? "is home." : "is not home.");
            }

        }

        return output;
    }

    /**
     * getter method for dice value
     *
     * @return value of dice
     */
    public int getDiceVal() {
        return this.diceVal;
    }

    /**
     * getter method for roll boolean
     *
     * @return true if allowed to make roll
     */
    public boolean getIsRollable() {
        return isRollable;
    }

    /**
     * This method sets the skipAction flag value, which is used during token move animation
     *
     * @param shouldSkipActions is the action set by game
     */
    public void setShouldSkipActions(boolean shouldSkipActions) {
        this.shouldSkipActions = shouldSkipActions;
    }

    public boolean getShouldSkipActions() {
        return this.shouldSkipActions;
    }

    public void setStillPlayersTurn(boolean b) {
        this.stillPlayersTurn = b;
    }

    public boolean getStillPlayersTurn() {
        return this.stillPlayersTurn;
    }

    public void setCanBringOutOfStart(boolean b) {
        this.canBringOutOfStart = b;
    }

    public boolean isCanBringOutOfStart() {
        return canBringOutOfStart;
    }

    public void setCanMovePiece(boolean b) {
        this.canMovePiece = b;
    }

    public boolean getCanMovePiece() {
        return this.canMovePiece;
    }
}
