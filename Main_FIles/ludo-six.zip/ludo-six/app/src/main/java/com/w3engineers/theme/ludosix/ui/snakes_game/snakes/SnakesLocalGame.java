package com.w3engineers.theme.ludosix.ui.snakes_game.snakes;

import com.google.gson.Gson;

import java.util.ArrayList;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.keys.PreferenceKey;
import com.w3engineers.theme.ludosix.data.local.event.GameActionEvent;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.GamePlayer;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.LocalGame;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.actionMsg.GameAction;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.util.GameQueueProcessor;
import com.w3engineers.theme.util.helper.AndroidUtil;
import com.w3engineers.theme.util.helper.SharedPref;
import com.w3engineers.theme.util.helper.ToneFactory;
import com.w3engineers.theme.util.lib.internet.InternetConnectionManager;
import com.w3engineers.theme.util.lib.nearby.ConnectionManager;


/**
 * A class that represents the state of our game available to the player.
 * Defines and enforces the game rules; handles interactions with players.
 *
 * @author God, through which all is possible
 * @author Avery Guillermo
 * @author Ravi Nayyar
 * @author Luke Danowski
 * @author Chris Sebrechts
 * @author Nuxoll, Andrew
 * @author Veghdal, Steven
 */

public class SnakesLocalGame extends LocalGame {

    // the game's state
    private SnakesState state;

    public SnakesLocalGame(ArrayList<Player> playerList) {
        state = new SnakesState(playerList);
    }


    /**
     * send the updated state to a given player
     */
    @Override
    protected void sendUpdatedStateToAll() {
        for (GamePlayer p : players) {
            if (!p.isProxy()) {
                p.sendInfo(state);
            }
        }
    }

    private void sendUpdatedStateToGuiPlayer() {
        for (GamePlayer p : players) {
            if (!p.isProxy() && p.requiresGui()) {
                p.sendInfo(state);
            }
        }
    }

    @Override
    public SnakesState getCurrentGameState() {
        return state;
    }

    /**
     * canMove
     * can this player make a move
     *
     * @param playerIdx the player's player-number (ID)
     * @return true if matches
     */
    @Override
    protected boolean canMove(int playerIdx) {
        return playerIdx == state.getWhoseMove();
    }

    @Override
    protected boolean canMovePiece() {
        return state.getCanMovePiece();
    }

    /**
     * checkIfGameOver
     * Check if the game is over / if the player has won.
     *
     * @return a message that tells who has won the game, or null if the
     * game is not over
     */
    @Override
    protected void checkIfGameOver() {
        for (int i = 0; i < state.getNumPlayers(); i++) {

            if (state.getPlayerScore(players[i].getPlayerInfo().getPlayerPosition()) == 1) {
                AndroidUtil.sleep(200);
                finishUpGame(players[i].getPlayerInfo());
            }
        }
    }

    /**
     * makeMove
     * this determines what moves can be made and verifies if the move made by the
     * player legal.
     *
     * @param action The move that the player has sent to the game
     * @return true if any move is possible
     */
    @Override
    protected boolean makeMove(GameAction action) {
        //if its the person's turn and they are trying to make a move
        int playerID;
        if (canMove(playerID = action.getPlayer().getPlayerInfo().getPlayerPosition())) {
            Token piece = state.pieces[playerID];

            if (action instanceof ActionAnimateDice) {
                state.setAction(SnakesState.Action.ANIMATE_DICE);
                state.setGamePlayer(action.getPlayer());
                sendUpdatedStateToGuiPlayer();
                return true;

            } else if (action instanceof ActionRollDice && state.getIsRollable()) {
                state.setAction(null);
                ToneFactory.on().stop();

                if (!action.getPlayer().isProxy()) {
                    state.newRoll();

                    GameActionEvent gameActionEvent = new GameActionEvent(playerID, GameActionEvent.Action.ROLL_DICE, state.getDiceVal());
                    String data = new Gson().toJson(gameActionEvent);

                    for (GamePlayer playerToSend : players) {
                        if (playerToSend.isProxy()) {
                            if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
                                ConnectionManager.sendGameData(data, false, playerToSend.getPlayerInfo().getEndPointId());
                            }else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
                                InternetConnectionManager.sendGameData(data, false, playerToSend.getPlayerInfo().getUserId());
                            }
                        }
                    }

                } else {
                    state.newCustomRoll(((ActionRollDice) action).getDiceVal());
                }

                if (piece.getIsMovable() && !piece.getIsHome()) {
                    animateToken(action.getPlayer());
                } else {
                    state.setLastActivePlayer(state.getWhoseMove());
                    state.changePlayerTurn();

                    sendUpdatedStateToAll();
                    GameQueueProcessor.getInstance().forceProcessQueue();
                }

                return true;

            } else if (action instanceof ActionAnimateToken) {
                int count = ((ActionAnimateToken) action).getCount();
                ToneFactory.on().play(R.raw.token_move);

                if (count == state.getDiceVal()) {
                    state.setShouldSkipActions(false);
                    state.advanceToken(playerID);

                    sendUpdatedStateToAll();

                    if (state.getAction() != SnakesState.Action.ANIMATE_TOKEN_CUT) {
                        checkIfGameOver();
                        GameQueueProcessor.getInstance().forceProcessQueue();
                    }

                } else {
                    state.setShouldSkipActions(true);
                    state.setAction(SnakesState.Action.ANIMATE_TOKEN);
                    state.advanceToken(playerID);

                    state.setGamePlayer(action.getPlayer());
                    state.setCount(count);
                    sendUpdatedStateToGuiPlayer();
                }

            } else if (action instanceof ActionAnimateTokenCut) {
                piece.incNumSpacesMoved(1);

                if (piece.getPathLength() == piece.getNumSpacesMoved()) {
                    state.setAction(null);
                    state.changePlayerTurn();

                    piece.setBasePath(state.getIndex());
                    sendUpdatedStateToAll();
                    GameQueueProcessor.getInstance().forceProcessQueue();

                } else {
                    sendUpdatedStateToGuiPlayer();
                }

            } else {
                GameQueueProcessor.getInstance().forceProcessQueue();
            }
        }

        return true; // do nothing since the move was not valid!
    }

    private void animateToken(GamePlayer gamePlayer) {
        state.setAction(SnakesState.Action.ANIMATE_TOKEN);
        state.setGame(getGame());

        state.setGamePlayer(gamePlayer);
        state.setCount(0);
        sendUpdatedStateToGuiPlayer();
    }
}
