package com.w3engineers.theme.ludosix.ui.snakes_game.game;

import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg.GameInfo;

/**
 * A player who plays a (generic) game. Each class that implements a player for
 * a particular game should implement this interface.
 *
 * @author Steven R. Vegdahl
 * @author Andrew M. Nuxoll
 * @version July 2013
 */

public interface GamePlayer {

    // sets this player as the GUI player (implemented as final in the
    // major player classes)
    void gameSetAsGui(GameMainActivity activity);

    // sets this player as the GUI player (overrideable)
    void setAsGui(GameMainActivity activity);

    // sends a message to the player
    void sendInfo(GameInfo info);

    // start the player
    void start();

    // whether this player requires a GUI
    boolean requiresGui();

    // whether this player supports a GUI
    boolean supportsGui();

    // whether this player is a proxy player
    boolean isProxy();

    // Returns player info
    Player getPlayerInfo();

}// interface GamePlayer
