package com.w3engineers.theme.util.helper;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
/*
*  ****************************************************************************
*  * Created by : Sudipta K Paik process 17-OCT-17 at 4:02 PM.
*  * Email : sudipta@w3engineers.com
*  *
*  * Responsibility: To start the main service in project we use this class
*  * RightMesh start and stop from this service based process requirements.
*  *
*  * Last edited by : Sudipta process 17-Oct-17.
*  *
*  * Last Reviewed by : <Reviewer Name> process <mm/dd/yy>
*  ****************************************************************************
*/

public class MyAppService extends Service {
    public static void start(Context context) {
        if (!ViewUtils.isServiceRunning(MyAppService.class, context)) {
            Intent starter = new Intent(context, MyAppService.class);
            context.startService(starter);
        }
    }

    public static void stop(Context context) {
        if (ViewUtils.isServiceRunning(MyAppService.class, context)) {
            Intent starter = new Intent(context, MyAppService.class);
            context.stopService(starter);
        }
    }

    @Override
    public void onCreate() {
        Logger.log("App service started");
        //RMManager.on().init(getApplicationContext()).startMesh();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        //RMManager.on().stopMesh();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        //InRangeHelper.clearLocalUser();
        onDestroy();
        super.onTaskRemoved(rootIntent);
    }
}