package com.w3engineers.theme;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;
import androidx.core.app.NotificationCompat;


import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;
import com.w3engineers.theme.ludosix.BuildConfig;
import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.StartApp;
import timber.log.Timber;


/*
 * ****************************************************************************
 * * Copyright © 2018 W3 Engineers Ltd., All rights reserved.
 * *
 * * Created by:
 * * Name : Anjan Debnath
 * * Date : 10/25/17
 * * Email : anjan@w3engineers.com
 * *
 * * Purpose: Base Application class
 * *
 * * Last Edited by : SUDIPTA KUMAR PAIK on 03/08/18.
 * * History:
 * * 1:
 * * 2:
 * *
 * * Last Reviewed by : SUDIPTA KUMAR PAIK on 03/08/18.
 * ****************************************************************************
 */



public class LudoSixApp extends MultiDexApplication {
    private static Context sContext;
    private static boolean sIsAppRunning = false;

    public static Context getContext() {
        return sContext;
    }

    public static boolean getIsAppRunning() {
        return sIsAppRunning;
    }

    public static void setIsAppRunning(boolean isAppRunning) {
        sIsAppRunning = isAppRunning;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        sContext = getApplicationContext();
        new StartApp().init(sContext);

        createNotificationChannel();


        // Initialize the Audience Network SDK
        AudienceNetworkAds.initialize(this);

        if (BuildConfig.DEBUG) {
            AdSettings.setTestMode(true);
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(newBase);
        MultiDex.install(this);
    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            Uri soundUri = Uri.parse("android.resource://" + getApplicationContext().getPackageName() + "/" + R.raw.notification_sound);

            String channelId = getString(R.string.channel_id);
            int importance = NotificationManager.IMPORTANCE_HIGH;

            // Creating an Audio Attribute
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .build();

            NotificationChannel channel = new NotificationChannel(channelId, name, importance);
            channel.setDescription(description);
            channel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);
            channel.enableLights(true);
            channel.enableVibration(true);
            channel.setSound(soundUri, audioAttributes);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }

            Timber.i("Notification channel created.");
        }
    }
}