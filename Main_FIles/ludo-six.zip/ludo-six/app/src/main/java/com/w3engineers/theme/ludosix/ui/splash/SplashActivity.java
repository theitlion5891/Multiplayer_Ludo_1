package com.w3engineers.theme.ludosix.ui.splash;

import android.animation.Animator;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

import java.util.ArrayList;
import java.util.List;

import com.w3engineers.theme.LudoSixApp;
import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.databinding.ActivitySplashBinding;
import com.w3engineers.theme.ludosix.ui.app_tutorial.TutorialActivity;
import com.w3engineers.theme.ludosix.ui.base.BaseActivity;
import com.w3engineers.theme.ludosix.ui.connectivity_selection.ConnectivitySelectionActivity;
import com.w3engineers.theme.ludosix.ui.game_selection.GameSelectionActivity;
import com.w3engineers.theme.ludosix.ui.home.HomeActivity;
import com.w3engineers.theme.ludosix.ui.signup.SignUpActivity;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/7/2018 at 3:33 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: This class represents splash screen containing app logo and text.
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 11/7/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 11/7/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class SplashActivity extends BaseActivity<SplashMvpView, SplashPresenter> implements SplashMvpView {

    private ActivitySplashBinding activitySplashBinding;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_splash;
    }

    @Override
    protected void startUI() {
        LudoSixApp.setIsAppRunning(true);
        activitySplashBinding = (ActivitySplashBinding) getViewDataBinding();
        createAppShortcut();

        // Splash animations
        Animation downTop = AnimationUtils.loadAnimation(this, R.anim.downtop);
        activitySplashBinding.activitySplashAppLogoIv.setAnimation(downTop);

        YoYo.with(Techniques.ZoomIn)
                .duration(2000)
                .repeat(0)
                .withListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(Animator animator) {

                    }

                    @Override
                    public void onAnimationEnd(Animator animator) {
                        goToNextPage(); // Navigating to next page on animation end
                    }

                    @Override
                    public void onAnimationCancel(Animator animator) {

                    }

                    @Override
                    public void onAnimationRepeat(Animator animator) {

                    }
                })
                .playOn(activitySplashBinding.activitySplashAppLogoIv);
    }

    @Override
    protected void stopUI() {
    }

    @Override
    protected SplashPresenter initPresenter() {
        return new SplashPresenter();
    }

    /**
     * This method navigates user to either {@link SignUpActivity} or {@link HomeActivity} based on user info
     */
    private void goToNextPage() {

        if (GameDataHelper.getUserInfo() != null) {
            ConnectivitySelectionActivity.runActivity(this);

        } else {

            if (!GameDataHelper.getIsTutorialShown()) {
                GameDataHelper.setIsTutorialShown(true);
                startActivity(new Intent(this, TutorialActivity.class));

            } else {
                SignUpActivity.runActivity(this);
            }
        }

        overridePendingTransition(R.anim.right_to_left, R.anim.left_to_right);
        finish();
    }

    /***
     * Creates app shortcut to ludo/snakes game home if user has signed up
     */
    private void createAppShortcut() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1 && GameDataHelper.getUserInfo() != null) {

            ShortcutManager shortcutManager = getSystemService(ShortcutManager.class);
            Intent intent = new Intent(this, HomeActivity.class);
            intent.setAction(Intent.ACTION_VIEW);

            intent.putExtra(HomeActivity.EXTRA_NETWORK_NAME, getString(R.string.ludo));
            ShortcutInfo ludoShortcut = new ShortcutInfo.Builder(this, "ludo_shortcut")
                    .setShortLabel(getString(R.string.ludo))
                    .setLongLabel("Play Ludo")
                    .setIcon(Icon.createWithResource(this, R.drawable.ic_shortcut_ludo))
                    .setIntent(intent)
                    .setRank(1)
                    .build();

            intent.putExtra(HomeActivity.EXTRA_NETWORK_NAME, getString(R.string.snakes));
            ShortcutInfo snakesShortcut = new ShortcutInfo.Builder(this, "snakes_shortcut")
                    .setShortLabel(getString(R.string.snakes))
                    .setLongLabel("Play Snakes")
                    .setIcon(Icon.createWithResource(this, R.drawable.ic_shortcut_snakes))
                    .setIntent(intent)
                    .setRank(0)
                    .build();

            List<ShortcutInfo> shortcutInfoList = new ArrayList<>();
            shortcutInfoList.add(ludoShortcut);
            shortcutInfoList.add(snakesShortcut);

            if (shortcutManager != null) {
                shortcutManager.setDynamicShortcuts(shortcutInfoList);
            }
        }
    }
}