package com.w3engineers.theme.ludosix.ui.ludo_game.game.config;

import java.util.ArrayList;

import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.GameMainActivity;

/**
 * GameConfig class
 * <p>
 * This class describes a user-specified configuration for playing a game. It
 * includes information about the number and type of players in the game and
 * other related meta-data.
 * <p>
 * A game initializes this class with some information and additional data is
 * provided by the user or loaded from a previously-saved configuration.
 *
 * @author Andrew Nuxoll
 * @author Steven R. Vegdahl
 * @version July 2013
 * @see GameMainActivity
 */
public class GameConfig {

    /**
     * a list of all valid player types that the user chooses
     */
    private GamePlayerType[] availTypes;

    /**
     * a list of the names of each player
     */
//    private ArrayList<String> selNames = new ArrayList<>();

    private ArrayList<Player> gamePlayers = new ArrayList<>();

    /**
     * a list of the type of each player. Each type in the list is associated
     * with the player whose name is at the same index in selNames. Thus, this
     * ArrayList and selNames must always be the same length. This is managed
     * automatically via the {@link #addPlayer}
     * methods.
     */
    private ArrayList<GamePlayerType> selTypes = new ArrayList<GamePlayerType>();

    /**
     * The player type selected in the remote player tab.
     */
    private GamePlayerType remoteSelType;

    /**
     * if set to true, indicates the game will be run on the local computer
     * rather than connecting to a remote server
     */
    private boolean isLocal;

    /**
     * if the player is connecting to a game running on another device, this
     * string is used to store the player's name
     */
    private String remoteName;

    /**
     * if the player is connecting to a game running on a another device, this
     * string contains the IP address of that device
     */
    private String ipCode;

    /**
     * the port number for connecting to another device over the network
     */
    private int portNum;

    /**
     * this specifies the minimum number of players required for a legal game.
     * For example, tic-tac-toe would have a minimum (and maximum, see below) of
     * two players.
     */
    private int minPlayers;

    /**
     * this specifies the maximum number of players that the game can handle
     */
    private int maxPlayers;

    /**
     * This is the name of the game. This value is used to identify the game
     * to the user.
     */
    private String gameName;

    /**
     * if this boolean is set to false, then this configuration can not be
     * modified by the user and the configuration activity will be skipped
     * (taking the players straight to the game). This can be useful when
     * debugging.
     */
    private boolean userModifiable;

    /**
     * to create an instance of this class initial values for some instance
     * variables must be supplied. The constructor makes a cursory effort to
     * catch and fix bad input but, ultimately, the caller is responsible for
     * creating a proper game definition. In particular, you must call addPlayer
     * sufficient times to make sure that the minimum number of players is met.
     * <p>
     * This is the version of the constructor that is expected to be called
     * when the game activity starts. It therefore automatically adds a "Network
     * Player" player-type option, which always becomes the last element in the
     * available-player list.
     * <p>
     * This constructor leave the list of local players empty, and sets the
     * remote player to have a type that corresponds to the first player in
     * the available-player list. These defaults can (and probably should) be
     * changed by calling 'addPlayer' and 'setRemoteData'.
     *
     * @param availTypes the list of available player types (excluding the network player, which
     *                   is added by the constructor
     * @param minPlayers the minimum number of players allowed in this game
     * @param maxPlayers the maximum number of players allowed in this game
     * @param gameName   the name of the game
     * @param portNum    the port number used by this game for connecting over the network
     */
    public GameConfig(ArrayList<GamePlayerType> availTypes, int minPlayers,
                      int maxPlayers, String gameName, int portNum) {

        // create an array to hold the available player types, including
        // the "Network Player" that will be added
        int arrayLength = availTypes.size() + 1;
        GamePlayerType[] availArray = new GamePlayerType[arrayLength];

        // add the player types passed in to the constructor
        availTypes.toArray(availArray);

        // add the network player
//        availArray[arrayLength - 1] = new GamePlayerType("Network Player") {
//            public GamePlayer createPlayer(String name) {
//                int portNum = getPortNum();
//                return new ProxyPlayer(portNum);
//            }
//        };

        // perform the initialization of the object
        initGameConfig(availArray, minPlayers, maxPlayers, gameName, portNum);
    }// constructor

    /**
     * makes a copy of a config, but without the player information
     *
     * @return the copy of the config
     */
    public GameConfig copyWithoutPlayers() {
        return new GameConfig(availTypes, minPlayers, maxPlayers, gameName, portNum);
    }// copyWithoutPlayers

    /**
     * private version of the constructor, used to support the 'copyWithoutPlayers'
     * method
     *
     * @param availTypes the list of available player types (excluding the network player, which
     *                   is added by the constructor
     * @param minPlayers the minimum number of players allowed in this game
     * @param maxPlayers the maximum number of players allowed in this game
     * @param gameName   the name of the game
     * @param portNum    the port number used by this game for connecting over the network
     */
    private GameConfig(GamePlayerType[] availTypes, int minPlayers,
                       int maxPlayers, String gameName, int portNum) {

        // perform the initialization of the object
        initGameConfig(availTypes, minPlayers, maxPlayers, gameName, portNum);
    }

    private void initGameConfig(GamePlayerType[] availTypes, int minPlayers,
                                int maxPlayers, String gameName, int portNum) {

        // initialize the instance variables from the parameters
        this.availTypes = availTypes;
        this.minPlayers = minPlayers;
        this.maxPlayers = maxPlayers;
        this.gameName = gameName;
        this.portNum = portNum;

        // default to a local game
        this.isLocal = true;

        // set the defaults for remote-player data:
        // - name: "Guest"
        // - IP code: empty string
        // - player type: the first one in the available-player list
        setRemoteData("Guest", "", 0);

        // by default, allow the user to modify the configuration
        this.userModifiable = true;

    }// setRemoteData

    /**
     * set the remove-player data
     *
     * @param playerName the remote player's name
     * @param ipCode     the IP code used by the remote player
     * @param menuIndex  the index in the available-player array that denotes this
     *                   player's type
     */
    public void setRemoteData(String playerName, String ipCode, int menuIndex) {
        this.ipCode = ipCode;
        this.remoteName = playerName;
        this.remoteSelType = availTypes[menuIndex];
    }// setRemoteData

    /**
     * helper-method to convert a menu-item string to a GamePlayerType object in the
     * available player list.
     *
     * @param menuString the string in the menu that corrsponds to the given player type
     * @return the GamePlayerType object that corresponds to that string, or null
     * if no such GamePlayerType object exists
     */
    private GamePlayerType findPlayerType(String menuString) {
        // search/match the available-types array, returning the
        // corresponding GamePlayerType object
        for (GamePlayerType gpt : availTypes) {
            if (menuString.equals(gpt.getTypeName())) {
                return gpt;
            }
        }

        // if we get here, there was no match, so return null
        return null;
    }// findPlayerTypes


    /**
     * @return the available player types
     */
    public GamePlayerType[] getAvailTypes() {
        return availTypes;
    }// getAvailTypes

    /**
     * addPlayer
     * <p>
     * adds a new player to the configuration
     *
     * @param player    the player's name
     * @param typeIndex valid index of the player's type in availTypes
     */
    public void addPlayer(Player player, int typeIndex) {
        // adjust illegal input
//        if (name == null) {
//            // treat null name as empty string
//            name = "";
//        }

        // treat bad index as having value 0
        if (typeIndex < 0 || typeIndex >= availTypes.length) {
            typeIndex = 0;
        }

        // don't go over the maximum
        if (gamePlayers.size() >= this.maxPlayers)
            return;

        // append the new values
        gamePlayers.add(player);
        selTypes.add(this.availTypes[typeIndex]);

    }// addPlayer

    /**
     * get the name of the player at a given index
     *
     * @param index of the player whose name is wanted
     * @return the player's name or null if index is invalid
     */
    public Player getPlayerInfo(int index) {
        // if we're local, catch and ignore an invalid index;
        // otherwise, return the appropriate player's name
        if ((index < 0) || (index >= gamePlayers.size())) {
            return null;
        } else {
            return this.gamePlayers.get(index);
        }

    }// getPlayerInfo

    /**
     * @return an array of GamePlayerType objects that correspond to whether
     * a local or remote game was selected
     */
    public GamePlayerType[] getSelTypes() {
        // local game: fill an array with copies of the objects in this.selTypes
        GamePlayerType[] retVal = new GamePlayerType[selTypes.size()];
        int index = 0;
        for (GamePlayerType gpt : this.selTypes) {
            retVal[index] = (GamePlayerType) gpt.clone();
            ++index;
        }
        return retVal;

    }// getSelTypes

    /**
     * get the type of the player at a given index
     *
     * @param index of the player whose type is wanted
     * @return the player's name or null if index is invalid
     */
    public GamePlayerType getSelType(int index) {
        // local game: catch and ignore invalid index;
        // if OK, then return the appropriate object
        if ((index < 0) || (index >= gamePlayers.size())) {
            return null;
        } else {
            return this.selTypes.get(index);
        }
    }// getSelType

    /**
     * @return whether the current configuration denotes a local game
     */
    public boolean isLocal() {
        return isLocal;
    }// isLocal

    /**
     * sets the attribute that tells whether the current configuration denotes
     * a local game
     *
     * @param isLocal whether the game is to be set to "local game"
     */
    public void setLocal(boolean isLocal) {
        this.isLocal = isLocal;
    }// setLocal

    /**
     * @return the name of the remote player
     */
    public String getRemoteName() {
        return remoteName;
    }// getRemoteName

    /**
     * @return the type of the remote player
     */
    public GamePlayerType getRemoteSelType() {
        return remoteSelType;
    }// getRemotePlayerType

    /**
     * sets the remote player name
     *
     * @param remoteName the name
     */
    public void setRemoteName(String remoteName) {
        this.remoteName = remoteName;
    }// setRemoteName

    /**
     * sets the remote player type
     *
     * @param idx index in the list of available types that
     *            corresponds to the player type to which the
     *            remote player is to be set
     */
    public void setRemoteSelType(int idx) {
        // check invalid indices; then set type
        if (idx < 0 || idx >= availTypes.length) return;
        remoteSelType = this.availTypes[idx];
    }// setRemoteSelType

    /**
     * @return the IP code
     */
    public String getIpCode() {
        return ipCode;
    }// getIpCode

    /**
     * sets the config's IP code
     *
     * @param ipCode the code to set
     */
    public void setIpCode(String ipCode) {
        this.ipCode = ipCode;
    }// setIpCode

    /**
     * @return the minimum number of players allowed in the game
     */
    public int getMinPlayers() {
        return minPlayers;
    }// getMinPlayers

    /**
     * @return the maximum number of players allowed in the game
     */
    public int getMaxPlayers() {
        return maxPlayers;
    }

    /**
     * @return the current number of players specified in the game, corresponding
     * to whether the configuration is for a local or remote game
     */
    public int getNumPlayers() {
        return gamePlayers.size();
    }// getNumPlayers

    /**
     * @return the current number of player types
     */
    public int getNumTypes() {
        return selTypes.size();
    }// getNumTypes

    /**
     * @return the game name
     */
    public String getGameName() {
        return gameName;
    }// getGameName

    /**
     * @return the whether the configuration is modifiable
     */
    public boolean isUserModifiable() {
        return userModifiable;
    }// isUserModifiable

    /**
     * sets whether the configuration is modifiable
     *
     * @param userModifiable whether the configuration is to be made modifiable
     */
    public void setUserModifiable(boolean userModifiable) {
        this.userModifiable = userModifiable;
    }// setUserModifiable

}// class GameConfig

