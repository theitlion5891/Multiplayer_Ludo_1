package com.w3engineers.theme.ludosix.data.local.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.w3engineers.theme.util.lib.GSonHelper;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/13/2018 at 3:38 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Parcelable model class for player
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 12/5/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 12/5/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class Player implements Parcelable {

    public enum State {NOT_IN_GAME, PENDING, IN_GAME}

    public interface Type {
        int HUMAN_LOCAL = 0;
        int BOT = 1;
        int HUMAN_REMOTE = 2;
        int PROXY_PLAYER = 3;
    }

    private State state = State.NOT_IN_GAME;
    private String endPointId;
    private String userId;

    private String name;
    private String imagePath;
    private int playerType;

    private int playerPosition;
    private int playerBasePosition;
    private String playerScore = "";
    private String role;

    private String requestStatus;

    private int playerColor;
    private boolean hasAcknowledged = false;

    public Player(){

    }

    public Player(String userId, String endPointId, String name, String imagePath, int playerType) {
        this.userId = userId;
        this.endPointId = endPointId;
        this.name = name;
        this.imagePath = imagePath;
        this.playerType = playerType;
    }

    public Player(String userId, String endPointId, String name, String imagePath, int playerType, String playerScore) {
        this.userId = userId;
        this.endPointId = endPointId;
        this.name = name;
        this.imagePath = imagePath;
        this.playerType = playerType;
        this.playerScore = playerScore;
    }

    public boolean isHasAcknowledged() {
        return hasAcknowledged;
    }

    public void setHasAcknowledged(boolean hasAcknowledged) {
        this.hasAcknowledged = hasAcknowledged;
    }

    public int getPlayerPosition() {
        return playerPosition;
    }

    public void setPlayerPosition(int playerPosition) {
        this.playerPosition = playerPosition;
    }

    public int getPlayerBasePosition() {
        return playerBasePosition;
    }

    public void setPlayerBasePosition(int playerBasePosition) {
        this.playerBasePosition = playerBasePosition;
    }

    public int getPlayerColor() {
        return playerColor;
    }

    public void setPlayerColor(int playerColor) {
        this.playerColor = playerColor;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getEndPointId() {
        return endPointId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setEndPointId(String endPointId) {
        this.endPointId = endPointId;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public int getPlayerType() {
        return playerType;
    }

    public void setPlayerType(int playerType) {
        this.playerType = playerType;
    }

    public ScoreBoard getPlayerScore() {
        return GSonHelper.fromJson(playerScore, ScoreBoard.class);
    }

    public String getPlayerScoreJson() {
        return playerScore;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    public void setPlayerScore(String playerScore) {
        this.playerScore = playerScore;
    }

    protected Player(Parcel in) {
        endPointId = in.readString();
        userId = in.readString();
        name = in.readString();
        imagePath = in.readString();
        playerType = in.readInt();
        playerPosition = in.readInt();
        playerBasePosition = in.readInt();
        playerScore = in.readString();
        playerColor = in.readInt();
        hasAcknowledged = in.readByte() != 0;
        role = in.readString();
        requestStatus = in.readString();
    }

    public static final Creator<Player> CREATOR = new Creator<Player>() {
        @Override
        public Player createFromParcel(Parcel in) {
            return new Player(in);
        }

        @Override
        public Player[] newArray(int size) {
            return new Player[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(endPointId);
        parcel.writeString(userId);
        parcel.writeString(name);
        parcel.writeString(imagePath);
        parcel.writeInt(playerType);
        parcel.writeInt(playerPosition);
        parcel.writeInt(playerBasePosition);
        parcel.writeString(playerScore);
        parcel.writeInt(playerColor);
        parcel.writeByte((byte) (hasAcknowledged ? 1 : 0));
        parcel.writeString(role);
        parcel.writeString(requestStatus);
    }
}
