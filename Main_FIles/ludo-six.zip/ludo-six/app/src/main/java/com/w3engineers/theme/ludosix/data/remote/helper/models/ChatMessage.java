package com.w3engineers.theme.ludosix.data.remote.helper.models;

/**
 * * ============================================================================
 * * Copyright (C) 2018 W3 Engineers Ltd - All Rights Reserved.
 * * Unauthorized copying of this file, via any medium is strictly prohibited
 * * Proprietary and confidential
 * * ----------------------------------------------------------------------------
 * * Created by: Sudipta K Paik on [17-Jul-2018 at 10:32 AM].
 * * Email: sudipta@w3engineers.com
 * * ----------------------------------------------------------------------------
 * * Project: Generic API.
 * * Code Responsibility: <Purpose of code>
 * * ----------------------------------------------------------------------------
 * * Edited by :
 * * --> <First Editor> on [17-Jul-2018 at 10:32 AM].
 * * --> <Second Editor> on [17-Jul-2018 at 10:32 AM].
 * * ----------------------------------------------------------------------------
 * * Reviewed by :
 * * --> <First Reviewer> on [17-Jul-2018 at 10:32 AM].
 * * --> <Second Reviewer> on [17-Jul-2018 at 10:32 AM].
 * * ============================================================================
 **/

public class ChatMessage {
}
