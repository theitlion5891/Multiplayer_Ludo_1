package com.w3engineers.theme.util.helper.internetdada;

import com.w3engineers.theme.util.lib.internet.Constants;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

/**
 * ****************************************************************************
 * * Created by : Md. Moniruzzaman Monir on 1/1/2019 at 12:55 PM.
 * * Email : moniruzzaman@w3engineers.com
 * *
 * * Purpose:
 * *
 * * Last edited by : Rezwanur on 04/07/19.
 * *
 * * Last Reviewed by : Rezwanur on 04/07/19.
 * ****************************************************************************
 */
public interface GetDataService {
 /*   @GET(Constants.Urls.CONFIG_GET_CATEGORY)
    Call<CategoryEntity> getAllCategory(@Header("Authorization") String authToken,
                                        @Header("Content-Type") String userAddress);*/


/*    @GET(Constants.Urls.SUBSCRIBER_GET_PROFILE)
    Call<ResponseBody> getProfileInfo(@Header("Content-Type") String contentType,
                                      @Header("Authorization") String authToken);*/

/*    @FormUrlEncoded
    @POST(Constants.Urls.CUSTOMER_GET_TICKET)
    Call<TimeLineModel> getTicketTimeLine(@Header("Authorization") String authToken,
                                          @Field("customer_id") long customerId);*/


}
