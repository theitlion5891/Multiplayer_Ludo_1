package com.w3engineers.theme.ludosix.data.remote.s3api.helper;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.Map;

public class HttpRequester {
	private HttpRequester() {}
	private static final Object staticLock = new Object();
	
	public static BaseResponse post(final String url, final Map<String, String> map, String authTokenId) throws IOException {
		if (url == null || url.isEmpty()) throw new IllegalArgumentException();
		
		String query = null;
		int responseCode = -1;
		synchronized (staticLock) {
			HttpURLConnection http = null;

			try {
				for (int loopCount = 0; loopCount < 2; loopCount++) {

					boolean isMapped = map != null && !map.isEmpty();

					if (isMapped) {
						query = buildQuery(map);
					}

					http = (HttpURLConnection) new URL(url).openConnection();
					/**
					 * This is changed from 30 to 90
					 * sec because on server side
					 * for large contact always get
					 * timeout exception
					 */
					http.setReadTimeout(300000);
					http.setConnectTimeout(300000);


					if (isMapped) http.setDoInput(true);

					if (isMapped) http.setDoOutput(true);

					http.setRequestMethod("POST");


					if (isMapped)
						http.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

					if (isMapped)
						http.setRequestProperty("Authorization", "Token " + authTokenId);

					if (isMapped) http.setFixedLengthStreamingMode(query.getBytes().length);
					if (isMapped) http.setUseCaches(false);

					if (isMapped) {
						PrintWriter pWriter = new PrintWriter(http.getOutputStream());
						pWriter.print(query);
						pWriter.flush();
						pWriter.close();
					}
					//Log.e("TKB"," Query: "+query);
					query = null;

					responseCode = http.getResponseCode();

					Log.e("TKB Server", "ResCode: "+responseCode+", Server Url:"+url+",  Times:"+loopCount);
					if (responseCode == HttpURLConnection.HTTP_OK) {
						InputStream is = http.getInputStream();
						query = parseInputStream(is);
						break;
					}else if (Arrays.asList(500, 503, 504, 404).contains(responseCode)) {
						continue;
					}else {
						break;
					}
				}
			} catch (Exception e){
				e.printStackTrace();
			}

			finally {
				if (http != null) {
                    http.disconnect();
                }

			}
		}


		BaseResponse baseResponse = new BaseResponse();
		baseResponse.responseCode = responseCode;
		if(responseCode == HttpURLConnection.HTTP_OK) {
			//This is due to review it server response code placement formatting support
			query = "200::" + query;
		}
		baseResponse.responseMessage = query;
		return baseResponse;
	}
	
	
	private static String buildQuery(final Map<String, String> queryPair) throws UnsupportedEncodingException {
	    StringBuilder queryBuilder = new StringBuilder();
		
	    if (queryPair != null) {
	    	
	    	boolean first = true;
	    	
		    for (String key : queryPair.keySet()) {
		    	
		        if (!first) {
		        	queryBuilder.append("&");
	            }
				System.out.println("[Azim-querypair]::"+queryPair.get(key)+"::"+key);

		        queryBuilder.append(URLEncoder.encode(key, "UTF-8")).append("=").append(URLEncoder.encode(queryPair.get(key), "UTF-8"));
		        
		        first = false;
		    }
	    }	    
	    
	    return queryBuilder.toString();
	}
	
	private static String parseInputStream(final InputStream is) throws IOException {
        String str;
        StringBuilder result = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
          
       	while ((str = br.readLine()) != null)
        	result.append(str);        

       	return result.toString();
	}
}
