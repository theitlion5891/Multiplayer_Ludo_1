package com.w3engineers.theme.util.helper;

import android.app.Activity;
import android.os.Build;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.FragmentTransaction;
import androidx.appcompat.app.AppCompatActivity;

import com.w3engineers.theme.ludosix.ui.base.BaseFragment;


/*
*  ****************************************************************************
*  * Created by : Md. Azizul Islam on 12/13/2017 at 6:33 PM.
*  * Email : azizul@w3engineers.com
*  * 
*  * Last edited by : Md. Azizul Islam on 12/13/2017.
*  * 
*  * Last Reviewed by : <Reviewer Name> on <mm/dd/yy>  
*  ****************************************************************************
*/
public class FragmentUtil {
    private FragmentUtil() {
    }

    private static <T extends BaseFragment> T newFragment(Class<T> tClass) {
        try {
            return tClass.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <T extends BaseFragment> T getFragment(BaseFragment parentFragment, Class<T> tClass) {
        T tFragment = (T) parentFragment.getChildFragmentManager().findFragmentByTag(tClass.getName());

        if (tFragment == null) {
            tFragment = newFragment(tClass);
        }

        return tFragment;
    }

    public static <T extends BaseFragment> void commitChildFragment(final BaseFragment parentFragment, final Class<T> tClass, final int parentResourceId) {
        commitChildFragment(parentFragment, tClass, parentResourceId, 0, 0);
    }

    public void commitFragment(int parentId, BaseFragment baseFragment) {
        AppCompatActivity activity = null;

        if (baseFragment != null) {
            activity = (AppCompatActivity) baseFragment.getActivity();
        }
        activity.getSupportFragmentManager()
                .beginTransaction()
                .replace(parentId, baseFragment, baseFragment.getClass().getName())
                .commit();
    }

    public static <T extends BaseFragment> void commitChildFragment(final BaseFragment parentFragment, final Class<T> tClass, final int parentResourceId, final int enter, final int exit) {

        final Runnable commitRunnable = new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
            @Override
            public void run() {

                Activity activity = null;

                if (parentFragment != null) {
                    activity = parentFragment.getActivity();
                }

                if (activity != null && !activity.isDestroyed()) {

                    BaseFragment currentChildFragment = getFragment(parentFragment, tClass);

                    FragmentTransaction transaction = parentFragment.getChildFragmentManager().beginTransaction();

                    transaction.setCustomAnimations(enter, exit);


                    transaction.replace(parentResourceId, currentChildFragment, tClass.getName())
                            .commitAllowingStateLoss();
                }
            }
        };

        HandlerUtil.postForeground(commitRunnable);
    }
}
