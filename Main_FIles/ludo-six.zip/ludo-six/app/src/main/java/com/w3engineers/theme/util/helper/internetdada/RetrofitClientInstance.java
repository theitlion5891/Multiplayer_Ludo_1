package com.w3engineers.theme.util.helper.internetdada;

/*
 *  ****************************************************************************
 *  * Created by : Md. Moniruzzaman Monir on 1/1/2019 at 1:14 PM.
 *  * Email : moniruzzaman@w3engineers.com
 *  *
 *  * Purpose:
 *  *
 *  * Last edited by : Md. Moniruzzaman Monir on 1/1/2019.
 *  *
 *  * Last Reviewed by : <Reviewer Name> on <mm/dd/yy>
 *  ****************************************************************************
 */

import android.util.Log;

import com.w3engineers.theme.ludosix.BuildConfig;
import com.w3engineers.theme.util.lib.internet.Constants;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import okhttp3.logging.HttpLoggingInterceptor.Level;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClientInstance {
    private static Retrofit retrofit;

    /**
     * To do basic authentication to hit server
     */

/*    static OkHttpClient okHttpClient = new OkHttpClient.Builder()
            .addInterceptor(new BasicAuthInterceptor("w3e", "w3eadmin")) // This is used to add ApplicationInterceptor.
            .build();*/

    /**
     * To check internet connectivity
     *
     * @return
     */
/*    static OkHttpClient client = new OkHttpClient.Builder()
            .addInterceptor(new ConnectivityInterceptor())
            .build();*/
    public static OkHttpClient.Builder getClient() {

        OkHttpClient.Builder client = new OkHttpClient.Builder();

        // OkHttpClient client = new OkHttpClient.Builder().addInterceptor(interceptor).build();

        if (BuildConfig.DEBUG) {
            //HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
            HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
                @Override
                public void log(String message) {
                    //  Timber.tag("OkHttp").d(message);
                    Log.e("OkHttp", message);
                }
            });
            interceptor.setLevel(Level.BODY);
            client.addInterceptor(interceptor);
        }

        return client;
    }

/*   static OkHttpClient okHttpClient = new OkHttpClient.Builder()
            .addInterceptor(new Interceptor() {
                @Override
                public okhttp3.Response intercept(Chain chain) throws IOException {
                    Request request = chain.request();
                    okhttp3.Response response = chain.proceed(request);

                    // todo deal with the issues the way you need to
                    if (response.code() == 500) {

                        return response;
                    }

                    return response;
                }
            })
            .build();*/

/*    public static Retrofit getRetrofitInstance() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.Remote.BASE_URL)
                    // .client(okHttpClient)
                    // .client(client)
                    .client(getClient().build())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }*/
}
