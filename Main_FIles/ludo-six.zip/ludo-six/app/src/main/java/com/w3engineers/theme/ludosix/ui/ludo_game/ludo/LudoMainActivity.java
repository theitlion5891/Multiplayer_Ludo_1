package com.w3engineers.theme.ludosix.ui.ludo_game.ludo;

import java.util.ArrayList;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.keys.PreferenceKey;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.GameMainActivity;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.GamePlayer;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.LocalGame;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.RemoteGame;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.config.GameConfig;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.config.GamePlayerType;
import com.w3engineers.theme.util.helper.SharedPref;
import com.w3engineers.theme.util.lib.internet.ConnectivityInternetProvider;
import com.w3engineers.theme.util.lib.nearby.ConnectivityProvider;

/**
 * LudoMainActivity
 * It is the default start up screen
 */
public class LudoMainActivity extends GameMainActivity {

    // the port number that this game will use when playing over the network
   // private static final int PORT_NUMBER = 2278;
    private static final int PORT_NUMBER = 3000;
    public static final String EXTRA_TOTAL_PLAYERS = "EXTRA_TOTAL_PLAYERS";

    /**
     * Create the default configuration for this game:
     * - one human player vs. one computer player
     * - minimum of 1 player, maximum of 4
     *
     * @return the new configuration object, representing the default configuration
     */
    @Override
    public GameConfig createDefaultConfig() {
        ArrayList<Player> playerList = getIntent().getParcelableArrayListExtra(EXTRA_TOTAL_PLAYERS);
        ArrayList<GamePlayerType> playerTypes = new ArrayList<>(); // Define the allowed player types

        // Ludo has three player types:  local human, remote human and computer
        playerTypes.add(new GamePlayerType("Local Human") {
            public GamePlayer createPlayer(Player player) {
                return new HumanPlayer(player);
            }
        });

        playerTypes.add(new GamePlayerType("Smart Computer") {
            public GamePlayer createPlayer(Player player) {
                return new ComputerSmartPlayer(player);
            }
        });

        playerTypes.add(new GamePlayerType("Remote Human") {
            public GamePlayer createPlayer(Player player) {
                return new RemoteHumanPlayer(player);
            }
        });

        playerTypes.add(new GamePlayerType("Proxy Player") {
            public GamePlayer createPlayer(Player player) {
                return new ProxyPlayer(player);
            }
        });

        // Create a game configuration class for Ludo:
        GameConfig defaultConfig = new GameConfig(playerTypes, 2, 4, getString(R.string.ludo), PORT_NUMBER);
        defaultConfig.setUserModifiable(false);
        defaultConfig.setLocal(getGameType(playerList)); // Setting game type based on player role

        for (int i = 0; i < playerList.size(); i++) {
            Player player = playerList.get(i);
            defaultConfig.addPlayer(player, player.getPlayerType()); // Adding players and their types
        }

        return defaultConfig;
    }

    private boolean getGameType(ArrayList<Player> playerList) {
        boolean isLocal = false;

        if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
            if (ConnectivityProvider.getConnectivity().getCurrentRole() == ConnectivityProvider.ConnectionRole.CLIENT) {
                for (Player player : playerList) {
                    if (player.getPlayerType() == Player.Type.BOT) {
                        isLocal = true;
                    }
                }
            } else {
                isLocal = true;
            }
        }else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
            if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.CLIENT) {
                for (Player player : playerList) {
                    if (player.getPlayerType() == Player.Type.BOT) {
                        isLocal = true;
                    }
                }

            } else {
                isLocal = true;
            }
        }


        return isLocal;
    }

    /**
     * create a local game
     *
     * @return the local game, a Ludo game
     */
    @Override
    public LocalGame createLocalGame() {

        ArrayList<Player> playerList = getIntent().getParcelableArrayListExtra(EXTRA_TOTAL_PLAYERS);
        return new LudoLocalGame(playerList);
    }

    /**
     * Creates a remote game
     *
     * @return the created remote game
     */
    @Override
    public RemoteGame createRemoteGame() {

        ArrayList<Player> playerList = getIntent().getParcelableArrayListExtra(EXTRA_TOTAL_PLAYERS);
        return new LudoRemoteGame(playerList);
    }
}




