package com.w3engineers.theme.ludosix.ui.game_selection;

import com.w3engineers.theme.ludosix.ui.base.MvpView;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 01/03/2018 at 12:03 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: View class
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 01/03/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 01/03/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public interface GameSelectionMvpView extends MvpView {
}
