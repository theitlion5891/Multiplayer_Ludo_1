package com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg;

public class HostDisconnectedInfo extends GameInfo {
    // Info flag for host disconnect event
}
