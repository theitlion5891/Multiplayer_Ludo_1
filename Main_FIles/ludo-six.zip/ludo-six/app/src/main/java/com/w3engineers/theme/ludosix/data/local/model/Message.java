package com.w3engineers.theme.ludosix.data.local.model;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 2/14/2019 at 6:44 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Chat message model
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 2/14/2019.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 2/14/2019.
 * Copyright (c) 2019, W3 Engineers Ltd. All rights reserved.
 */
public class Message {

    public enum Type {ICON, TEXT}

    private String playerName;
    private String chatText;
    private int chatIconId;
    private Type resType;

    public Message(String playerName, int chatIconId, Type resType) {
        this.playerName = playerName;
        this.chatIconId = chatIconId;
        this.resType = resType;
    }

    public Message(String playerName, String chatText, Type resType) {
        this.playerName = playerName;
        this.chatText = chatText;
        this.resType = resType;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getChatText() {
        return chatText;
    }

    public void setChatText(String chatText) {
        this.chatText = chatText;
    }

    public int getChatIconId() {
        return chatIconId;
    }

    public void setChatIconId(int chatIconId) {
        this.chatIconId = chatIconId;
    }

    public Type getResType() {
        return resType;
    }

    public void setResType(Type resType) {
        this.resType = resType;
    }

}
