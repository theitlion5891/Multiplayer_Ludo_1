package com.w3engineers.theme.util.lib.internet.enumkeys;

public enum InternetGameModeType {
    TWO_PLAYERS,
    THREE_PLAYERS,
    FOUR_PLAYERS
}
