package com.w3engineers.theme.util.lib.internet.model;

public class ImageFileNameModel {
    String imageFile;
    String  receiver;

    public String getImageFile() {
        return imageFile;
    }

    public void setImageFile(String imageFileName) {
        this.imageFile = imageFileName;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }
}
