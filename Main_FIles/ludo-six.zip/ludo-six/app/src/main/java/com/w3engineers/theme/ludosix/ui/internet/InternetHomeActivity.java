package com.w3engineers.theme.ludosix.ui.internet;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.databinding.DataBindingUtil;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.data.helper.MusicManager;
import com.w3engineers.theme.ludosix.data.helper.keys.GameMode;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.data.local.model.ScoreBoard;
import com.w3engineers.theme.ludosix.data.local.model.UserInfo;
import com.w3engineers.theme.ludosix.databinding.ActivityInternetHomeBinding;
import com.w3engineers.theme.ludosix.databinding.LayoutScoreBoardDialogBinding;
import com.w3engineers.theme.ludosix.ui.app_tutorial.TutorialActivity;
import com.w3engineers.theme.ludosix.ui.base.BaseActivity;
import com.w3engineers.theme.ludosix.ui.edit_profile.EditProfileActivity;
import com.w3engineers.theme.ludosix.ui.game_info.GameInfoActivity;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.GameMainActivity;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.LudoMainActivity;
import com.w3engineers.theme.ludosix.ui.snakes_game.snakes.SnakesMainActivity;
import com.w3engineers.theme.util.helper.AdHelper;
import com.w3engineers.theme.util.helper.FacebookAdsHelper;
import com.w3engineers.theme.util.helper.Glider;
import com.w3engineers.theme.util.helper.PermissionUtil;
import com.w3engineers.theme.util.helper.ProgressDialogHelper;
import com.w3engineers.theme.util.helper.Toaster;
import com.w3engineers.theme.util.lib.internet.ConnectivityInternetProvider;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetGameModeType;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetInvitationType;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class InternetHomeActivity extends BaseActivity<InternetHomeMvpView, InternetHomePresenter> implements InternetHomeMvpView, InternetPeerListRecyclerAdapter.ItemClickListener {

    private static final int PERMISSION_REQUEST_CODE = 101;
    public static final String EXTRA_NETWORK_NAME = "EXTRA_NETWORK_NAME";

    public static Player mHostPlayer;
    private ActivityInternetHomeBinding mBinding;
    private InternetPeerListRecyclerAdapter mAdapter;
    private ProgressDialogHelper mProgressHelper;

    private List<Player> mOnlinebyPlayers;
    private Map<String, Player> mOnlinePlayerMap;

    private Map<String, Player> mInGamePlayersMap;
    private ArrayList<Player> mGamePlayersList;
    private Dialog mSoundSettingsDialog;

    private String mNetworkName;
    private Player mSelfPlayer;
    private int mReadyToPlayAckCount = 0;
    private boolean mIsGameAlreadyStarted = false;
    private Dialog mInvitationDialog;

    /**
     * The default selected game mode is THREE_PLAYERS mode
     */
    private InternetGameModeType selectedGameMode = InternetGameModeType.THREE_PLAYERS;

    /**
     * This is the maximum response time in milis to respond to an invitation.
     * After expiring this time period invitation will automatically be declined
     */
    private static final long INVITATION_RESPONSE_TIMEOUT = 20 * 1000; // 20 sec

    private static final long INVITATION_SENT_TIMEOUT = 30 * 1000; // 30 sec
    private static final long READY_ACK_WAITING_TIME = 30 * 1000; // 15 sec

    private boolean mCanInvitePlayer = true;
    private InvitationTimeOutRunnable mInvitationTimeOutRunnable;
    private Handler mHandler = new Handler();

    private static final String[] REQUIRED_PERMISSIONS =
            new String[]{
                    Manifest.permission.BLUETOOTH,
                    Manifest.permission.BLUETOOTH_ADMIN,
                    Manifest.permission.ACCESS_WIFI_STATE,
                    Manifest.permission.CHANGE_WIFI_STATE,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE

            };

    /**
     * Start Activity (Pass value as a 2nd Parameter)
     * Date: 2018-02-07
     * Added By: Sudipta K Paik
     *
     * @param context
     **/
    public static void runActivity(Context context, String networkName) {
        Intent intent = new Intent(context, InternetHomeActivity.class);
        intent.putExtra(EXTRA_NETWORK_NAME, networkName);
        runCurrentActivity(context, intent);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_internet_home;
    }

    private void init() {
        mOnlinebyPlayers = new ArrayList<>();
        mOnlinePlayerMap = new HashMap<>();
        mInGamePlayersMap = new HashMap<>();
        mGamePlayersList = new ArrayList<>();

        mNetworkName = getIntent().getStringExtra(EXTRA_NETWORK_NAME);
        ConnectivityInternetProvider.getConnectivity().setNetworkName(mNetworkName);

        if (mNetworkName.equals(getString(R.string.snakes))) {
            mBinding.activityHomeParentView.setBackgroundResource(R.drawable.image_snakes_home_background);

        } else {
            mBinding.activityHomeParentView.setBackgroundResource(R.drawable.image_background_home);
        }

        if (PermissionUtil.init(this).request(PERMISSION_REQUEST_CODE, REQUIRED_PERMISSIONS)) {
            presenter.startFindingOnlinePlayer(this, ConnectivityInternetProvider.ConnectionRole.CLIENT);
        }

        mProgressHelper = new ProgressDialogHelper(this);
        mAdapter = new InternetPeerListRecyclerAdapter(mOnlinebyPlayers, this);
        mBinding.activityHomeNearbyPeersRv.setAdapter(mAdapter);
        MusicManager.getInstance().play();

        new AdHelper().interstitialAd(getBaseContext(), null);
    }

    @Override
    protected void startUI() {

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = (ActivityInternetHomeBinding) getViewDataBinding();
        init();


        FacebookAdsHelper.bannerAds(this, (LinearLayout) mBinding.addLayout);

        setClickListener(mBinding.activityHomeSettingsBtn, mBinding.activityHomeShareBtn, mBinding.activityHomeStartBtn,
                mBinding.activityHomeUserImageCiv, mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconCrossButtonIv,
                mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconCrossButtonIv, mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconCrossButtonIv,
                mBinding.activityHomeInviteBtn, mBinding.activityHomeCrossBtn, mBinding.activityHomeGameHomeBtn);


        // Setting default icon for three player mode
        mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_no_player);
        mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setAlpha(0.2f);

        // Click listener for music button
        mBinding.activityHomeMusicBtn.setOnClickListener(view -> showMusicSettingsDialog());

        // Check change listener for game mode radio buttons
        mBinding.activityHomeGameModeRg.setOnCheckedChangeListener((group, checkedId) -> {

            RadioButton checkedRadioButton = group.findViewById(checkedId);
            boolean isChecked = checkedRadioButton.isChecked();

            if (isChecked) {
                switch (checkedRadioButton.getId()) {

                    case R.id.activity_home_game_mode_two_player_rb:
                        mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_no_player);
                        mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setAlpha(0.2f);

                        mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_no_player);
                        mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setAlpha(0.2f);
                        selectedGameMode = InternetGameModeType.TWO_PLAYERS;
                        break;

                    case R.id.activity_home_game_mode_three_player_rb:
                        mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_bot);
                        mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setAlpha(1f);

                        mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_no_player);
                        mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setAlpha(0.2f);
                        selectedGameMode = InternetGameModeType.THREE_PLAYERS;
                        break;

                    case R.id.activity_home_game_mode_four_player_rb:
                        mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_bot);
                        mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setAlpha(1f);

                        mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_bot);
                        mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setAlpha(1f);
                        selectedGameMode = InternetGameModeType.FOUR_PLAYERS;
                        break;
                }

                if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.HOST) {
                    broadCastGameModePacket();
                }
            }
        });

        mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setOnClickListener(view -> {
            Player player = (Player) mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.getTag();

            if (player != null) {
                showScoreBoardDialog(false, player.getPlayerScore(), new UserInfo(player.getUserId(), player.getName(), player.getImagePath()));
            }
        });

        mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setOnClickListener(view -> {
            Player player = (Player) mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.getTag();

            if (player != null) {
                showScoreBoardDialog(false, player.getPlayerScore(), new UserInfo(player.getUserId(), player.getName(), player.getImagePath()));
            }
        });

        mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setOnClickListener(view -> {
            Player player = (Player) mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.getTag();

            if (player != null) {
                showScoreBoardDialog(false, player.getPlayerScore(), new UserInfo(player.getUserId(), player.getName(), player.getImagePath()));
            }
        });
    }

    private void checkIfMusicMuted() {

        if (GameDataHelper.getSoundVolume() == 0 /*&& GameDataHelper.getMusicVolume() == 0*/) {
            mBinding.activityHomeMusicBtn.setImageResource(R.drawable.ic_music_disabled);
        } else {
            mBinding.activityHomeMusicBtn.setImageResource(R.drawable.ic_music);
        }
    }

    private void setGameModeChangingEnable(boolean flag) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < mBinding.activityHomeGameModeRg.getChildCount(); i++) {
                    mBinding.activityHomeGameModeRg.getChildAt(i).setEnabled(flag);
                }
            }
        });

    }

    private void setCrossButtonVisibility(View view) {
        if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.HOST) {
            view.setVisibility(View.VISIBLE);
        } else {
            view.setVisibility(View.GONE);
        }
    }

    private void updateInGamePlayersPanelUi(Player player) {

        Player player1 = (Player) mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.getTag();
        if (player1 == null) {
            if (!TextUtils.isEmpty(player.getImagePath())) {
                Glider.showCircleImage(player.getImagePath(), mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv);
            } else {
                mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_avatar);
            }

            mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setAlpha(1f);
            mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setTag(player);
            mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconCrossButtonIv.setTag(player);
            setCrossButtonVisibility(mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconCrossButtonIv);
            return;
        }

        if (selectedGameMode == InternetGameModeType.THREE_PLAYERS ||
                selectedGameMode == InternetGameModeType.FOUR_PLAYERS) {
            Player player2 = (Player) mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.getTag();
            if (player2 == null) {
                if (!TextUtils.isEmpty(player.getImagePath())) {
                    Glider.showCircleImage(player.getImagePath(), mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv);
                } else {
                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_avatar);
                }

                mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setAlpha(1f);
                mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setTag(player);
                mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconCrossButtonIv.setTag(player);
                setCrossButtonVisibility(mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconCrossButtonIv);
                return;
            }
            if (selectedGameMode == InternetGameModeType.FOUR_PLAYERS) {
                Player player3 = (Player) mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.getTag();
                if (player3 == null) {
                    if (!TextUtils.isEmpty(player.getImagePath())) {
                        Glider.showCircleImage(player.getImagePath(), mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv);
                    } else {
                        mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_avatar);
                    }

                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setAlpha(1f);
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setTag(player);
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconCrossButtonIv.setTag(player);
                    setCrossButtonVisibility(mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconCrossButtonIv);
                }
            }
        }

    }

    private void imageUpdateInGamePanel(Player player) {
        Player player1 = (Player) mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.getTag();
        if (player1 != null) {
            if (player1.getUserId().equals(player.getUserId())) {
                if (!TextUtils.isEmpty(player.getImagePath())) {
                    //   mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setTag(null);
                    Glider.showCircleImage(player.getImagePath(), mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv);
                } else {
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_avatar);
                }
            }
            return;
        }
        if (selectedGameMode == InternetGameModeType.THREE_PLAYERS ||
                selectedGameMode == InternetGameModeType.FOUR_PLAYERS) {
            Player player2 = (Player) mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.getTag();
            if (player2 != null) {
                if (player2.getUserId().equals(player.getUserId())) {
                    if (!TextUtils.isEmpty(player.getImagePath()))
                        Glider.showCircleImage(player.getImagePath(), mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv);
                    else
                        mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_avatar);
                }
                return;
            }
            if (selectedGameMode == InternetGameModeType.FOUR_PLAYERS) {
                Player player3 = (Player) mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.getTag();
                if (player3 != null) {
                    if (player3.getUserId().equals(player.getUserId())) {
                        if (!TextUtils.isEmpty(player.getImagePath()))
                            Glider.showCircleImage(player.getImagePath(), mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv);
                        else
                            mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_avatar);
                    }
                    return;
                }
            }
        }
    }

    private void removePlayerFromInGamePanelUI(Player player) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                removeFromInGameMap(player);

                Player player1 = (Player) mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.getTag();
                if (player1 != null && player1.getUserId().equals(player.getUserId())) {
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_bot);
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setAlpha(1f);
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setTag(null);
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconCrossButtonIv.setTag(null);
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconCrossButtonIv.setVisibility(View.GONE);
                    return;
                }

                Player player2 = (Player) mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.getTag();
                if (player2 != null && player2.getUserId().equals(player.getUserId())) {
                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_bot);
                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setAlpha(1f);
                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setTag(null);
                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconCrossButtonIv.setTag(null);
                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconCrossButtonIv.setVisibility(View.GONE);
                    return;
                }

                Player player3 = (Player) mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.getTag();
                if (player3 != null && player3.getUserId().equals(player.getUserId())) {
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_bot);
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setAlpha(1f);
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setTag(null);
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconCrossButtonIv.setTag(null);
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconCrossButtonIv.setVisibility(View.GONE);
                    return;
                }
            }
        });

    }

    private void resetInGamePanelUI() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setGameModeChangingEnable(true);

                if (selectedGameMode == InternetGameModeType.TWO_PLAYERS) {
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_bot);
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setAlpha(1f);
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconCrossButtonIv.setVisibility(View.GONE);

                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_no_player);
                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setAlpha(0.2f);
                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconCrossButtonIv.setVisibility(View.GONE);

                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_no_player);
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setAlpha(0.2f);
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconCrossButtonIv.setVisibility(View.GONE);
                } else if (selectedGameMode == InternetGameModeType.THREE_PLAYERS) {
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_bot);
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setAlpha(1f);
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconCrossButtonIv.setVisibility(View.GONE);

                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_bot);
                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setAlpha(1f);
                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconCrossButtonIv.setVisibility(View.GONE);

                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_no_player);
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setAlpha(0.2f);
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconCrossButtonIv.setVisibility(View.GONE);
                } else {
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_bot);
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setAlpha(1f);
                    mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconCrossButtonIv.setVisibility(View.GONE);

                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_bot);
                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setAlpha(1f);
                    mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconCrossButtonIv.setVisibility(View.GONE);

                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setImageResource(R.drawable.ic_bot);
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setAlpha(1f);
                    mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconCrossButtonIv.setVisibility(View.GONE);
                }

                mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.setTag(null);
                mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconCrossButtonIv.setTag(null);

                mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.setTag(null);
                mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconCrossButtonIv.setTag(null);

                mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.setTag(null);
                mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconCrossButtonIv.setTag(null);
            }
        });

    }

    private void updateGameModeUi(InternetGameModeType gameMode) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                switch (gameMode) {
                    case TWO_PLAYERS:
                        mBinding.activityHomeGameModeRg.check(R.id.activity_home_game_mode_two_player_rb);
                        break;
                    case THREE_PLAYERS:
                        mBinding.activityHomeGameModeRg.check(R.id.activity_home_game_mode_three_player_rb);
                        break;
                    case FOUR_PLAYERS:
                        mBinding.activityHomeGameModeRg.check(R.id.activity_home_game_mode_four_player_rb);
                        break;
                    default:
                        break;
                }
            }
        });
    }

    private void changePlayerStateInList(Player player, Player.State state) {
        if (mOnlinePlayerMap.containsKey(player.getUserId())) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Player playerInMap = mOnlinePlayerMap.get(player.getUserId());
                    playerInMap.setState(state);
                    mAdapter.notifyDataSetChanged();
                }
            });
        }
    }

    /**
     * BroadCast removed player info to all other peers
     *
     * @param player removed player
     */
    private void broadcastRemovePlayer(Player player) {
        List<Player> candidates = new ArrayList<>();
        for (Player p : mInGamePlayersMap.values()) {
            if (p.getState() == Player.State.IN_GAME && !p.getUserId().equals(player.getUserId())) {
                candidates.add(p);
            }
        }
        presenter.broadcastRemovePlayerFromGame(candidates, player);
    }


    /**
     * BroadCast game mode(2 players, 3 players, 4 players) change event to all the peers
     * who are in the game
     */
    private void broadCastGameModePacket() {
        List<Player> candidates = new ArrayList<>();
        for (Player p : mOnlinebyPlayers) {
            if (p.getState() == Player.State.IN_GAME) {
                candidates.add(p);
            }
        }
        presenter.broadcastGameMode(candidates, selectedGameMode);
    }


    /**
     * Send current game mode to newly added player
     *
     * @param player newly added player
     */
    private void sendSingleGameModePacket(Player player) {
        List<Player> candidates = new ArrayList<>();
        candidates.add(player);
        presenter.broadcastGameMode(candidates, selectedGameMode);
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Setting user profile image if any
        if (GameDataHelper.getUserInfo() != null) {
            Glider.show(GameDataHelper.getUserInfo().getImagePath(), mBinding.activityHomeUserImageCiv);
        } else {
            mBinding.activityHomeUserImageCiv.setImageResource(R.drawable.ic_avatar);
        }

        checkIfMusicMuted();
        MusicManager.getInstance().resumeMusic(); // Resuming music
    }

    @Override
    protected void onPause() {
        mProgressHelper.hide();
        MusicManager.getInstance().pauseMusic(); // Pausing music
        super.onPause();
    }

    @Override
    protected void stopUI() {
        MusicManager.getInstance().stopMusic();
        presenter.stopSearchingOnline();
    }

    @Override
    protected InternetHomePresenter initPresenter() {
        return new InternetHomePresenter();
    }

    /**
     * Gets currently selected game mode
     *
     * @return the selected game mode
     */
    private int getCurrentGameMode() {

        switch (mBinding.activityHomeGameModeRg.getCheckedRadioButtonId()) {
            case R.id.activity_home_game_mode_two_player_rb:
                return GameMode.TWO_PLAYER;

            case R.id.activity_home_game_mode_three_player_rb:
                return GameMode.THREE_PLAYER;

            case R.id.activity_home_game_mode_four_player_rb:
                return GameMode.FOUR_PLAYER;

            default:
                return GameMode.THREE_PLAYER;
        }
    }

    private void resetData() {
        mCanInvitePlayer = true;
        mOnlinebyPlayers.clear();
        mOnlinePlayerMap.clear();
        mInGamePlayersMap.clear();
        mSelfPlayer = null;
        mAdapter.notifyDataSetChanged();
    }

    private Runnable gameStartTimeOutRunnable = new Runnable() {
        @Override
        public void run() {
            if (!mIsGameAlreadyStarted) {

                for (Player p : mGamePlayersList) {
                    if (p.getPlayerType() == Player.Type.PROXY_PLAYER && !p.isHasAcknowledged()) {
                        p.setPlayerType(Player.Type.BOT);
                        Toaster.info(String.format("Player %s has been replaced with BOT!", p.getName()));

                        removePlayerFromInGamePanelUI(p);
                        presenter.removePlayer(p);

                        broadcastRemovePlayer(p);
                        changePlayerStateInList(p, Player.State.NOT_IN_GAME);
                    }
                }

                presenter.broadcastGameInitMessage(mGamePlayersList, InternetInvitationType.GAME_START);
                mIsGameAlreadyStarted = true;

                startGame(mGamePlayersList);
            }
        }
    };

    private class InvitationTimeOutRunnable implements Runnable {
        private Player player;

        public InvitationTimeOutRunnable(Player player) {
            this.player = player;
        }

        @Override
        public void run() {

            if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.HOST) {
                mCanInvitePlayer = true;
                changePlayerState(player, Player.State.NOT_IN_GAME);

            } else {
                presenter.declineInvitation(player);

                if (mInvitationDialog != null && mInvitationDialog.isShowing()) {
                    mInvitationDialog.dismiss();
                }
            }
        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.activity_home_start_btn:

                mHostPlayer = null;
                mGamePlayersList.clear();
                mGamePlayersList.addAll(getGamePlayers());

                if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.HOST) {

                    if (checkIfNotInAnyGame()) {
                        startGame(mGamePlayersList);

                    } else {
                        mProgressHelper.show("Starting game...");
                        // If host then broadcasting final game players list and READY_TO_PLAY message
                        // to proxy game players and waiting for READY_TO_PLAY_ACK
                        mReadyToPlayAckCount = 0;
                        mIsGameAlreadyStarted = false;
                        presenter.broadcastGameInitMessage(mGamePlayersList, InternetInvitationType.READY_TO_PLAY); // working

                        removeDummyPlayersFromGameList();
                        mHandler.postDelayed(gameStartTimeOutRunnable, READY_ACK_WAITING_TIME);
                    }

                } else {
                    if (mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.getTag() != null
                            || mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.getTag() != null
                            || mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.getTag() != null) {
                        Toaster.info("Only host can start game!");

                    } else {
                        startGame(mGamePlayersList);
                    }
                }

                break;

            case R.id.activity_home_share_btn:
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");

                shareIntent.putExtra(Intent.EXTRA_TEXT, "Playing LUDO SIX : https://play.google.com/store/apps/details?id=com.w3engineers.core.yumi");
                startActivity(Intent.createChooser(shareIntent, "Share app link using"));

                break;

            case R.id.activity_home_invite_btn:
                if (checkIfNotInAnyGame()) {

                    mBinding.activityHomeInviteBtn.setVisibility(View.GONE);
                    mBinding.activityHomeWaitingLav.setVisibility(View.VISIBLE);
                    mBinding.activityHomeWaitingText.setVisibility(View.VISIBLE);
                    mBinding.activityHomeChildCl.setVisibility(View.VISIBLE);

                    mBinding.addLayout.setVisibility(View.GONE);

                    new FacebookAdsHelper().interstitialAds(getBaseContext(), null);

                    resetData();

                    presenter.stopSearchingOnline();

                    presenter.startFindingOnlinePlayer(this, ConnectivityInternetProvider.ConnectionRole.HOST);

                } else {
                    Toaster.info("You cannot invite while already on a game!");
                }

                break;

            case R.id.activity_home_cross_btn:

                mBinding.activityHomeInviteBtn.setVisibility(View.VISIBLE);
                mBinding.activityHomeChildCl.setVisibility(View.GONE);

                mBinding.addLayout.setVisibility(View.VISIBLE);

                FacebookAdsHelper.bannerAds(this, (LinearLayout) mBinding.addLayout);

                mProgressHelper.show("Switching to client mode...");

                for (Player player : mInGamePlayersMap.values()) {
                    presenter.removePlayer(player);
                }

                resetData();
                resetInGamePanelUI();

                presenter.stopSearchingOnline();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        presenter.startFindingOnlinePlayer(InternetHomeActivity.this, ConnectivityInternetProvider.ConnectionRole.CLIENT);
                    }
                },2000);


                mProgressHelper.hide();
                break;

            case R.id.activity_home_settings_btn:
                showSettingsDialog();
                break;

            case R.id.activity_home_game_home_btn:
                finish();
                break;

            case R.id.activity_home_user_image_civ:
                showScoreBoardDialog(true, GameDataHelper.getScoreBoard(), GameDataHelper.getUserInfo()); // Showing score board dialog
                break;

            case R.id.layout_player_icon_cross_button_iv:
                Player player = (Player) view.getTag();

                if (player != null) {
                    removePlayerFromInGamePanelUI(player);
                    presenter.removePlayer(player);

                    broadcastRemovePlayer(player);
                    changePlayerStateInList(player, Player.State.NOT_IN_GAME);
                }
                break;
        }
    }

    private void startGame(ArrayList<Player> playerList) {
        if (mNetworkName.equals(getString(R.string.ludo))) {
            Intent intent = new Intent(this, LudoMainActivity.class);
            intent.putParcelableArrayListExtra(LudoMainActivity.EXTRA_TOTAL_PLAYERS, playerList); // Sending player list to game
            startActivity(intent);
        } else {
            Intent intent = new Intent(this, SnakesMainActivity.class);
            intent.putParcelableArrayListExtra(LudoMainActivity.EXTRA_TOTAL_PLAYERS, playerList);
            startActivity(intent);
        }
    }

    /**
     * remove player object from ingame players map
     *
     * @param player
     */
    private void removeFromInGameMap(Player player) {
        if (mInGamePlayersMap.containsKey(player.getUserId())) {
            mInGamePlayersMap.remove(player.getUserId());

            if (mInGamePlayersMap.size() == 0) {
                setGameModeChangingEnable(true);
            }
        }
    }


    /**
     * List item click listener
     *
     * @param view   is the clicked item view
     * @param player is the clicked item player instance
     */
    @Override
    public void onItemClick(View view, Player player) {
        switch (view.getId()) {
            case R.id.list_item_nearby_peers_player_add_ib:
                if (!mInGamePlayersMap.containsKey(player.getUserId())) {

                    if ((getCurrentGameMode() == GameMode.TWO_PLAYER && mInGamePlayersMap.size() < 1)
                            || (getCurrentGameMode() == GameMode.THREE_PLAYER && mInGamePlayersMap.size() < 2)
                            || (getCurrentGameMode() == GameMode.FOUR_PLAYER && mInGamePlayersMap.size() < 3)) {

                        if (mCanInvitePlayer) {
                            mCanInvitePlayer = false;
                            presenter.sendInvitation(player);
                            changePlayerState(player, Player.State.PENDING);

                            mInvitationTimeOutRunnable = new InvitationTimeOutRunnable(player);
                            mHandler.postDelayed(mInvitationTimeOutRunnable, INVITATION_SENT_TIMEOUT);
                        } else {
                            Toaster.error("Cannot invite player again until response!");
                        }

                    } else {
                        Toaster.error("Max player add limit reached!");
                    }

                } else {
                    Toaster.info("This player is already in game!");
                }

                break;
        }
    }

    private void changePlayerState(Player player, Player.State state) {
        if (mOnlinePlayerMap.containsKey(player.getUserId())) {

            Player playerInMap = mOnlinePlayerMap.get(player.getUserId());
            playerInMap.setState(state);
            mAdapter.notifyDataSetChanged();
        }
    }

    /**
     * Shows music settings dialog
     */
    private void showMusicSettingsDialog() {

        mSoundSettingsDialog = new Dialog(InternetHomeActivity.this);
        mSoundSettingsDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mSoundSettingsDialog.setCancelable(true);
        mSoundSettingsDialog.setContentView(R.layout.layout_music_settings);

        // Making background transparent
        if (mSoundSettingsDialog.getWindow() != null) {
            mSoundSettingsDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            mSoundSettingsDialog.getWindow().setGravity(Gravity.TOP);
        }


        SeekBar soundSeekbar = mSoundSettingsDialog.findViewById(R.id.layout_music_settings_sound_sb);
        ImageView soundImage = mSoundSettingsDialog.findViewById(R.id.layout_music_settings_sound_iv);
        int soundVolume = Math.round(GameDataHelper.getSoundVolume() * 100);

        soundSeekbar.setProgress(soundVolume);

        if (soundVolume == 0) {
            soundImage.setImageResource(R.drawable.ic_home_music_disabled);
        }

        int yellowColor = getResources().getColor(R.color.yellow_seekbar);

        soundSeekbar.getProgressDrawable().setColorFilter(yellowColor, PorterDuff.Mode.SRC_IN);
        soundSeekbar.getThumb().setColorFilter(yellowColor, PorterDuff.Mode.SRC_IN);

        soundImage.setOnClickListener(view -> {
            MusicManager.getInstance().setMusicVolume(0f); // Muting music
            GameDataHelper.setSoundVolume(0);
            checkIfMusicMuted();

            soundImage.setImageResource(R.drawable.ic_home_music_disabled);
            soundSeekbar.setProgress(0);
        });

        soundSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                float volume = (float) progress / 100;
                GameDataHelper.setSoundVolume(volume);
                MusicManager.getInstance().setMusicVolume(volume); // Setting music volume
                checkIfMusicMuted();

                if (progress == 0) {
                    soundImage.setImageResource(R.drawable.ic_home_music_disabled);

                } else {
                    soundImage.setImageResource(R.drawable.ic_home_music);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                mHandler.removeCallbacks(settingsDialogDismissRunnable);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mHandler.postDelayed(settingsDialogDismissRunnable, GameMainActivity.DIALOG_DISMISS_TIMEOUT);
            }
        });

        mSoundSettingsDialog.setOnCancelListener(dialogInterface -> {
            mHandler.removeCallbacks(settingsDialogDismissRunnable);
        });

        mSoundSettingsDialog.show();
        mHandler.postDelayed(settingsDialogDismissRunnable, GameMainActivity.DIALOG_DISMISS_TIMEOUT);

    }

    Runnable settingsDialogDismissRunnable = new Runnable() {
        @Override
        public void run() {
            if (mSoundSettingsDialog != null && mSoundSettingsDialog.isShowing()) {
                mSoundSettingsDialog.dismiss();
            }
        }
    };


    /**
     * Shows custom dialog with two buttons
     *
     * @param player is the message passed to the dialog
     */
    public void showInviteDialog(Player player) {

        mInvitationDialog = new Dialog(InternetHomeActivity.this);
        mInvitationDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mInvitationDialog.setCancelable(true);
        mInvitationDialog.setContentView(R.layout.layout_invite_dialog);

        // Making background transparent
        if (mInvitationDialog.getWindow() != null)
            mInvitationDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView text = mInvitationDialog.findViewById(R.id.layout_invite_dialog_text_body_tv);
        text.setText(getString(R.string.invitation_text, player.getName()));

        mInvitationDialog.findViewById(R.id.layout_invite_dialog_positive_button).setOnClickListener(v -> {
            if (mInvitationTimeOutRunnable != null) {
                mHandler.removeCallbacks(mInvitationTimeOutRunnable);
            }

            player.setState(Player.State.IN_GAME);
            presenter.acceptInvitation(player);
            updateInGamePlayersPanelUi(player);

            mInvitationDialog.dismiss();
            mAdapter.notifyDataSetChanged();
            setGameModeChangingEnable(false);
        });

        mInvitationDialog.findViewById(R.id.layout_invite_dialog_negative_button).setOnClickListener(v -> {
            if (mInvitationTimeOutRunnable != null) {
                mHandler.removeCallbacks(mInvitationTimeOutRunnable);
            }

            presenter.declineInvitation(player);
            mInvitationDialog.dismiss();

        });

        mInvitationDialog.setOnCancelListener(dialogInterface -> {
            if (mInvitationTimeOutRunnable != null) {
                mHandler.removeCallbacks(mInvitationTimeOutRunnable);
            }

            presenter.declineInvitation(player);

        });

        mInvitationDialog.show();
        mInvitationTimeOutRunnable = new InvitationTimeOutRunnable(player);
        mHandler.postDelayed(mInvitationTimeOutRunnable, INVITATION_RESPONSE_TIMEOUT);
    }

    /**
     * Shows score board dialog
     */
    public void showScoreBoardDialog(boolean isSelfScore, ScoreBoard scoreBoard, UserInfo userInfo) {

        LayoutScoreBoardDialogBinding binding = DataBindingUtil.inflate(LayoutInflater.from(this),
                R.layout.layout_score_board_dialog, null, false);

        binding.setData(scoreBoard); // Setting score board data using data binding
        binding.setProfile(userInfo); // Setting user profile data using data binding

        Dialog dialog = new Dialog(InternetHomeActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(binding.getRoot());

        // Making background transparent
        if (dialog.getWindow() != null)
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        // If viewing self profile then showing profile edit option
        if (isSelfScore) {
            dialog.findViewById(R.id.layout_score_board_edit_profile_iv).setVisibility(View.VISIBLE);
        }

        dialog.findViewById(R.id.layout_score_board_edit_profile_iv).setOnClickListener(view -> {
            EditProfileActivity.runActivity(InternetHomeActivity.this);
            dialog.dismiss();
        });

        dialog.findViewById(R.id.layout_score_board_close_btn).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    /**
     * Shows settings dialog
     */
    public void showSettingsDialog() {

        Dialog dialog = new Dialog(InternetHomeActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.layout_settings_dialog);

        // Making background transparent
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        TextView profileTv = dialog.findViewById(R.id.layout_settings_profile_text);
        TextView tutorialTv = dialog.findViewById(R.id.layout_settings_tutorial_text);
        TextView termsTv = dialog.findViewById(R.id.layout_settings_terms_text);
        TextView aboutTv = dialog.findViewById(R.id.layout_settings_about_text);

        profileTv.setCompoundDrawablesWithIntrinsicBounds(AppCompatResources.getDrawable(this, R.drawable.ic_edit), null, null, null);
        tutorialTv.setCompoundDrawablesWithIntrinsicBounds(AppCompatResources.getDrawable(this, R.drawable.ic_rules), null, null, null);
        termsTv.setCompoundDrawablesWithIntrinsicBounds(AppCompatResources.getDrawable(this, R.drawable.ic_terms), null, null, null);
        aboutTv.setCompoundDrawablesWithIntrinsicBounds(AppCompatResources.getDrawable(this, R.drawable.ic_about), null, null, null);

        profileTv.setOnClickListener(view -> {
            dialog.dismiss();
            showScoreBoardDialog(true, GameDataHelper.getScoreBoard(), GameDataHelper.getUserInfo()); // Showing score board dialog
        });

        tutorialTv.setOnClickListener(view -> {
            dialog.dismiss();
            startActivity(new Intent(this, TutorialActivity.class));
        });

        termsTv.setOnClickListener(view -> GameInfoActivity.runActivity(this, GameInfoActivity.InfoType.TERMS));
        aboutTv.setOnClickListener(view -> GameInfoActivity.runActivity(this, GameInfoActivity.InfoType.ABOUT));

        dialog.findViewById(R.id.layout_settings_close_btn).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    /**
     * new player connection is established
     * add to nearby connected device map and update ui accordingly
     *
     * @param player
     */
    private void addPlayerToListAndUpdateUI(Player player) {
        if (!mOnlinePlayerMap.containsKey(player.getUserId())) {
            mOnlinePlayerMap.put(player.getUserId(), player);
            mOnlinebyPlayers.add(player);

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mAdapter.notifyDataSetChanged();
                    checkIfNoPlayersAvailable();
                }
            });

        }
    }

    private void checkIfNoPlayersAvailable() {
        Log.e("current role before", " : " + ConnectivityInternetProvider.getConnectivity().getCurrentRole());
        Log.e("current role after", " : " + ConnectivityInternetProvider.ConnectionRole.HOST);

        if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.HOST) {
            if (mOnlinebyPlayers.size() == 0) {
                mBinding.activityHomeWaitingLav.setVisibility(View.VISIBLE);
                mBinding.activityHomeWaitingText.setVisibility(View.VISIBLE);

            } else {
                mBinding.activityHomeWaitingLav.setVisibility(View.GONE);
                mBinding.activityHomeWaitingText.setVisibility(View.GONE);
            }
        }
    }

    /**
     * A player got disconnected
     * remove from list and map
     * update ui accordingly
     *
     * @param player
     */
    private void removePlayerFromList(Player player) {
        if (mOnlinePlayerMap.remove(player.getUserId()) != null) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    for (int i = 0; i < mOnlinebyPlayers.size(); i++) {

                        Player p = mOnlinebyPlayers.get(i);
                        if (p.getUserId().equals(player.getUserId())) {

                            mOnlinebyPlayers.remove(i);
                            mAdapter.notifyDataSetChanged();
                            checkIfNoPlayersAvailable();
                            break;
                        }
                    }
                }
            });
        }
    }

    @Override
    public void onInternetDeviceConnected(Player player) {
        addPlayerToListAndUpdateUI(player);
    }

    @Override
    public void onInternetDeviceDisconnected(Player player) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                checkIfGamePlayerDisconnected(player);

              //  if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.HOST) {
                    removePlayerFromList(player);

                  //  broadCastPlayerDisconnectedEventToOthers(player);
                    removePlayerFromInGamePanelUI(player);

                    // Check if all game players are disconnected
                    if (checkIfNotInAnyGame()) {
                        // Enable game mode change privilege
                        setGameModeChangingEnable(true);
                    }

               /* } else {
                    resetData();
                    resetInGamePanelUI();
                }*/
            }
        });


     //   checkIfGamePlayerDisconnected(player);

 /*       if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.HOST) {
            removePlayerFromList(player);
            removePlayerFromInGamePanelUI(player);
            if (checkIfNotInAnyGame()) {
                setGameModeChangingEnable(true);
            }
        } else {
            resetData();
            resetInGamePanelUI();
        }*/

/*        removePlayerFromList(player);
        removePlayerFromInGamePanelUI(player);
        if (checkIfNotInAnyGame()) {
            setGameModeChangingEnable(true);
        }*/
    }

    private boolean checkIfNotInAnyGame() {
        return mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.getTag() == null
                && mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.getTag() == null
                && mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.getTag() == null;
    }

    private void checkIfGamePlayerDisconnected(Player player) {
        for (Player gamePlayer : getGamePlayers()) {

            if (gamePlayer.getUserId().equals(player.getUserId())) {
                EventBus.getDefault().post(gamePlayer); // Sending game player disconnect event to game main activity
            }
        }
    }

    /**
     * Broadcast player disconnected event to other peers
     * Only Player with HOST role{@link ConnectivityInternetProvider.ConnectionRole} will call this method
     *
     * @param player disconnected player
     */
    private void broadCastPlayerDisconnectedEventToOthers(Player player) {
        List<Player> candidates = new ArrayList<>();
        for (Player p : mOnlinebyPlayers) {
            if (p.getState() == Player.State.IN_GAME) {
                candidates.add(p);
            }
        }
        presenter.broadCastPlayerDisconnectedEvent(candidates, player);
    }

    @Override
    public void onInvitationReceived(Player requestedByPlayer, Player selfPlayer) {
        Player player1 = (Player) mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.getTag();
        if (player1 == null) {
            if (mSelfPlayer == null) {
                mSelfPlayer = selfPlayer;
            }

            if (mOnlinePlayerMap.containsKey(requestedByPlayer.getUserId())) {
                Player playerInMap = mOnlinePlayerMap.get(requestedByPlayer.getUserId());
                if (playerInMap.getState() == Player.State.NOT_IN_GAME) {
                    playerInMap.setState(Player.State.PENDING);
                }

                requestedByPlayer.setImagePath(playerInMap.getImagePath());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showInviteDialog(requestedByPlayer);
                    }
                });
            }
        } else {
            requestedByPlayer.setRequestStatus("1");
            presenter.declineInvitation(requestedByPlayer);
        }
    }

    /**
     * Broadcast new player accepted or joined event to all other
     * IN_GAME{@link Player.State} players
     *
     * @param player
     */
    private void sendUpdateAcceptToAllOtherConnectedPlayers(Player player) {
        List<Player> candidates = new ArrayList<>();
        for (Player p : mOnlinebyPlayers) {
            if (!player.getUserId().equals(p.getUserId()) && p.getState() == Player.State.IN_GAME)
                candidates.add(p);
        }
        if (candidates.size() > 0)
            presenter.sendUpdateAccept(candidates, player);
    }

    /**
     * callback method called with player{@link Player} object
     * accepted the invitation
     *
     * @param acceptedByPlayer accepted the invitation
     */
    @Override
    public void onInvitationAcceptByPeer(Player acceptedByPlayer, Player selfPlayer) {
        mCanInvitePlayer = true;
        if (mInvitationTimeOutRunnable != null) {
            mHandler.removeCallbacks(mInvitationTimeOutRunnable);
        }

        if (mSelfPlayer == null)
            mSelfPlayer = selfPlayer;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toaster.success(getString(R.string.invitation_accepted_text, acceptedByPlayer.getName()));

                if (mOnlinePlayerMap.containsKey(acceptedByPlayer.getUserId())) {
                    Player playerInMap = mOnlinePlayerMap.get(acceptedByPlayer.getUserId());
                    if (playerInMap.getState() != Player.State.IN_GAME) {
                        playerInMap.setState(Player.State.IN_GAME);
                        mInGamePlayersMap.put(playerInMap.getUserId(), playerInMap);
                    }

                    mAdapter.notifyDataSetChanged();
                    acceptedByPlayer.setImagePath(playerInMap.getImagePath());
                }

                setGameModeChangingEnable(false);
                sendSingleGameModePacket(acceptedByPlayer); //done
                updateInGamePlayersPanelUi(acceptedByPlayer);

                broadcastNewPlayerInfoToAll(acceptedByPlayer); //inside this have image sending process
                sendPlayersInfoToNewPlayer(acceptedByPlayer); // working
            }
        });
    }


    /**
     * broadCast newly added player info(image) to all other players
     *
     * @param player
     */
    private void broadcastNewPlayerInfoToAll(Player player) {
        sendUpdateAcceptToAllOtherConnectedPlayers(player);
        sendImageUpdateToAll(player); // TODO: Need to achieve image sending process
    }

    /**
     * Send current InGame Players list and images to newly Connected player
     *
     * @param player to send data
     */
    private void sendPlayersInfoToNewPlayer(Player player) {
        List<Player> inGamePlayers = new ArrayList<>();

        Player player1 = (Player) mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.getTag();
        Player player2 = (Player) mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.getTag();
        Player player3 = (Player) mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.getTag();

        if (player1 != null && !player1.getUserId().equals(player.getUserId())) {
            inGamePlayers.add(player1);
        }

        if (player2 != null && !player2.getUserId().equals(player.getUserId())) {
            inGamePlayers.add(player2);
        }

        if (player3 != null && !player3.getUserId().equals(player.getUserId())) {
            inGamePlayers.add(player3);
        }

        presenter.sendPayersInfoToNewPlayer(inGamePlayers, player); //done
        presenter.sendInGamePlayerImagesToNewPlayer(inGamePlayers, player); // This is image sending process
    }

    @Override
    public void onInvitationRejectByPeer(Player player) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mInvitationTimeOutRunnable != null) {
                    mHandler.removeCallbacks(mInvitationTimeOutRunnable);
                }
                changePlayerState(player, Player.State.NOT_IN_GAME);
                mCanInvitePlayer = true;
                if (player.getRequestStatus() != null && player.getRequestStatus().equalsIgnoreCase("1")) {
                    Toaster.error(getString(R.string.invitation_decline_text2, player.getName()));
                } else {
                    Toaster.error(getString(R.string.invitation_decline_text, player.getName()));
                }
            }
        });
    }


    /**
     * callback method called when new player is accepted by the host and
     * host sent a broadcast about that
     * This method is invoked in the client side
     *
     * @param player
     */
    @Override
    public void onNewPeerAccepted(Player player) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toaster.error("New player named " + player.getName() + " accepted by host!");
                if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.CLIENT) {
                    player.setState(Player.State.IN_GAME);
                    mOnlinePlayerMap.put(player.getUserId(), player);
                    mOnlinebyPlayers.add(player);
                }
                mAdapter.notifyDataSetChanged();
                updateInGamePlayersPanelUi(player);
            }
        });

    }


    @Override
    public void onProfilePicReceived(Player player, String imagePath) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mOnlinePlayerMap.containsKey(player.getUserId())) {
                    mOnlinePlayerMap.get(player.getUserId()).setImagePath(imagePath);
                    mAdapter.notifyDataSetChanged();
                    imageUpdateInGamePanel(mOnlinePlayerMap.get(player.getUserId()));
                }
            }
        });
    }


    /**
     * callBack method invoked when other player info received
     * this call is in the client side
     *
     * @param players
     */
    @Override
    public void onInternetPlayerInfoReceived(List<Player> players) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                for (Player p : players) {
                    p.setState(Player.State.IN_GAME);
                    //  if (!mOnlinePlayerMap.containsKey(p.getUserId())) {
                    mOnlinePlayerMap.put(p.getUserId(), p);
                    mOnlinebyPlayers.add(p);

                    updateInGamePlayersPanelUi(p);
                    // }
                }
                mAdapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onGameModeDataChanged(InternetGameModeType gameMode) {
        updateGameModeUi(gameMode);
    }

    @Override
    public void onOtherPlayerDisconnected(Player player) {
        if (mOnlinePlayerMap.containsKey(player.getUserId())) {
            mOnlinePlayerMap.remove(player.getUserId());
            for (Player p : mOnlinebyPlayers) {
                if (p.getUserId().equals(player.getUserId())) {
                    mOnlinebyPlayers.remove(p);
                    break;
                }
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mAdapter.notifyDataSetChanged();
                    removePlayerFromInGamePanelUI(player);
                }
            });
        }
    }

    /**
     * This is others player remove callback from host
     * @param player
     */
    @Override
    public void onPlayerRemovedByHost(Player player) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                removePlayerFromInGamePanelUI(player);

                if (mOnlinePlayerMap.containsKey(player.getUserId())) {
                    Player playerInMap = mOnlinePlayerMap.get(player.getUserId());
                    playerInMap.setState(Player.State.NOT_IN_GAME);
                    mAdapter.notifyDataSetChanged();
                }
            }
        });

    }



    @Override
    public void onReadyToPlayMessage(List<Player> players) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mProgressHelper.show("Starting game...");
                mGamePlayersList.clear();

                for (Player player : players) {
                    for (Player gamePlayer : getGamePlayers()) {

                        if (player.getUserId().equals(gamePlayer.getUserId())) {

                            player.setImagePath(gamePlayer.getImagePath());
                            player.setPlayerBasePosition(player.getPlayerPosition());

                            if (gamePlayer.getUserId().equals(mSelfPlayer.getUserId())) {
                                mSelfPlayer = player;
                                player.setPlayerType(Player.Type.HUMAN_REMOTE); // Making self remote human player

                            } else {
                                if (player.getPlayerType() == Player.Type.HUMAN_LOCAL) {
                                    mHostPlayer = player; // Setting host player
                                }

                                player.setPlayerType(Player.Type.PROXY_PLAYER); // Making all other players proxy
                            }

                            mGamePlayersList.add(player);
                        }
                    }
                }


                if (mGamePlayersList.size() > 1) {

                    reorderPlayerList();
                    presenter.sendReadyToPlayAck(mSelfPlayer); // Sending ack with self info
                }
            }
        });

    }

    private void reorderPlayerList() {

        if (getCurrentGameMode() == GameMode.FOUR_PLAYER) {
            Player player1 = mGamePlayersList.get(2);
            Player player2 = mGamePlayersList.get(3);

            mGamePlayersList.set(2, player2);
            mGamePlayersList.set(3, player1);
        }

        int myPosition = mSelfPlayer.getPlayerPosition();

        if (myPosition == 0) {
            myPosition += 2;
        }

        Collections.rotate(mGamePlayersList, myPosition);

        for (int i = 0; i < mGamePlayersList.size(); i++) {
            Player player = mGamePlayersList.get(i);

            if (getCurrentGameMode() == GameMode.TWO_PLAYER) {

                if (player.getPlayerBasePosition() == 0) {
                    player.setPlayerPosition(2);

                } else if (player.getPlayerBasePosition() == 2) {
                    player.setPlayerPosition(0);
                }

            } else {
                player.setPlayerPosition(i);
            }
        }

        removeDummyPlayersFromGameList();
    }

    private void removeDummyPlayersFromGameList() {

        if (getCurrentGameMode() != GameMode.FOUR_PLAYER) {
            Iterator<Player> iterator = mGamePlayersList.iterator();

            while (iterator.hasNext()) {
                Player player = iterator.next();

                if (player.getUserId().contains("dummy")) {
                    iterator.remove();
                }
            }
        }
    }

    @Override
    public void onGameStartedByHost() {
        mProgressHelper.hide();

        if (mGamePlayersList.size() > 1) {
            startGame(mGamePlayersList);
        }
    }

    @Override
    public void onReadyToPlayAckMessage(Player player) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mReadyToPlayAckCount++;

                for (int i = 0; i < mGamePlayersList.size(); i++) {
                    Player p = mGamePlayersList.get(i);

                    if (p.getPlayerType() == Player.Type.PROXY_PLAYER && p.getUserId().equals(player.getUserId())) {
                        p.setHasAcknowledged(true);
                        mGamePlayersList.set(i, p);
                    }
                }

                if (mReadyToPlayAckCount == presenter.getProxyPlayerEndpoints(mGamePlayersList).size()) {
                    // Got READY_TO_PLAY_ACK from all proxy player, so host can start the game now
                    mProgressHelper.hide();

                    if (mGamePlayersList.size() > 1 && !mIsGameAlreadyStarted) {
                        presenter.broadcastGameInitMessage(mGamePlayersList, InternetInvitationType.GAME_START);

                        mIsGameAlreadyStarted = true;
                        mHandler.removeCallbacks(gameStartTimeOutRunnable);
                        startGame(mGamePlayersList);
                    }
                }
            }
        });

    }

    @Override
    public void onRemoved() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mProgressHelper.hide();
                Toaster.info("You are removed from game by the host!");

                resetInGamePanelUI();
                //  removeOthersFromMapExceptHost();
               removeGamePlayerFromMap();
            }
        });

    }



    private void removeGamePlayerFromMap() {
     /*   for (Player player : mOnlinebyPlayers) {
            mOnlinebyPlayers.clear();
            mOnlinePlayerMap.clear();
            mAdapter.notifyDataSetChanged();
        }*/

        mInGamePlayersMap.clear();
        mGamePlayersList.clear();
        setGameModeChangingEnable(true);

/*        if (mInGamePlayersMap.containsKey(player.getUserId())) {
            mInGamePlayersMap.remove(player.getUserId());

            if (mInGamePlayersMap.size() == 0) {
                setGameModeChangingEnable(true);
            }
        }*/
    }

    /**
     * this client is removed by the host
     * so remove all other connected players from local list and update
     */
    private void removeOthersFromMapExceptHost() {
        if (ConnectivityInternetProvider.getConnectivity().getHostEndpoint() != null) {
            Player hostFound = mOnlinePlayerMap.get(ConnectivityInternetProvider.getConnectivity().getHostEndpoint().getUserId());
            hostFound.setState(Player.State.NOT_IN_GAME);
            mOnlinebyPlayers.clear();
            mOnlinePlayerMap.clear();
            mOnlinePlayerMap.put(hostFound.getUserId(), hostFound);
            mOnlinebyPlayers.add(hostFound);
            mAdapter.notifyDataSetChanged();
        }
    }

    private void sendImageUpdateToAll(Player player) {
        List<Player> candidates = new ArrayList<>();
        for (Player p : mOnlinebyPlayers) {
            if (!player.getUserId().equals(p.getUserId()) && p.getState() == Player.State.IN_GAME)
                candidates.add(p);
        }
        if (candidates.size() > 0)
            presenter.sendImageUpdateToPlayers(candidates, player);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            for (int i = 0; i < grantResults.length; i++) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    Toaster.error("Need all permission granted!");
                    return;
                }
            }
            presenter.startFindingOnlinePlayer(this, ConnectivityInternetProvider.ConnectionRole.CLIENT);
        }
    }

    private ArrayList<Player> getGamePlayers() {
        Player player1 = (Player) mBinding.layoutJoinedPlayerIcon1.layoutPlayerIconUserImageCiv.getTag();
        Player player2 = (Player) mBinding.layoutJoinedPlayerIcon2.layoutPlayerIconUserImageCiv.getTag();
        Player player3 = (Player) mBinding.layoutJoinedPlayerIcon3.layoutPlayerIconUserImageCiv.getTag();

        return presenter.getGamePlayers(player1, player2, player3, getCurrentGameMode(), checkIfNotInAnyGame(), mSelfPlayer);
    }
}
