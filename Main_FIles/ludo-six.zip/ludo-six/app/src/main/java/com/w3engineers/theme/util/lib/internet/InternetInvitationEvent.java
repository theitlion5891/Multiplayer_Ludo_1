package com.w3engineers.theme.util.lib.internet;



import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.util.lib.nearby.InvitationPacketType;

import java.util.List;

public class InternetInvitationEvent {
    private InvitationPacketType type;
    private Player endPoint;
    private List<Player> endPoints;

    public InternetInvitationEvent(InvitationPacketType type) {
        this.type = type;
    }

    public InternetInvitationEvent(InvitationPacketType type, Player endPoint) {
        this.type = type;
        this.endPoint = endPoint;
    }

    public InternetInvitationEvent(InvitationPacketType type, List<Player> endPointList) {
        this.type = type;
        this.endPoints = endPointList;
    }

    public InternetInvitationEvent(InvitationPacketType type, List<Player> endPointList, Player endPoint) {
        this.type = type;
        this.endPoints = endPointList;
        this.endPoint = endPoint;
    }

    public InvitationPacketType getType() {
        return type;
    }

    public void setType(InvitationPacketType type) {
        this.type = type;
    }

    public Player getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(Player endPoint) {
        this.endPoint = endPoint;
    }


    public List<Player> getEndPoints() {
        return endPoints;
    }

    public void setEndPoints(List<Player> endPoints) {
        this.endPoints = endPoints;
    }
}
