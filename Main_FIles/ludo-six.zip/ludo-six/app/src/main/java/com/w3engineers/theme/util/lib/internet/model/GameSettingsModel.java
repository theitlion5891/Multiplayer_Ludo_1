package com.w3engineers.theme.util.lib.internet.model;

import com.w3engineers.theme.util.lib.internet.enumkeys.InternetGameModeType;

public class GameSettingsModel {
    InternetGameModeType internetGameModeType;
    String receiver;

    public InternetGameModeType getInternetGameModeType() {
        return internetGameModeType;
    }

    public void setInternetGameModeType(InternetGameModeType internetGameModeType) {
        this.internetGameModeType = internetGameModeType;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }
}
