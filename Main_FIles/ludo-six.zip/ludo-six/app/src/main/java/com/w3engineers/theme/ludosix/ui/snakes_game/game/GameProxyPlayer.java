package com.w3engineers.theme.ludosix.ui.snakes_game.game;

import android.os.Handler;
import android.util.Log;

import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.actionMsg.GameOverAckAction;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.actionMsg.MyNameIsAction;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.actionMsg.ReadyAction;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg.BindGameInfo;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg.GameInfo;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg.GameOverInfo;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg.StartGameInfo;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg.TimerInfo;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.util.GameTimer;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.util.MessageBox;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.util.Tickable;

/**
 * class GameHumanPlayer
 * <p>
 * is an abstract base class for a player that is controlled by a remote human. For any
 * particular game, a subclass should be created that can display the current
 * game state and responds to user commands.
 *
 * @author Steven R. Vegdahl
 * @author Andrew Nuxoll
 * @version July 2013
 */
public abstract class GameProxyPlayer implements GamePlayer, Tickable {
    /**
     * instance variables
     */
    protected Game game; // the game
    protected int playerNum; // my player ID
    //    protected String name; // my player's name
    protected Player playerInfo; // my player's name
    protected String endpointId; // my endpointId
    protected String[] allPlayerNames; // the names of all the player
    private Handler myHandler; // my thread's handler
    private GameMainActivity myActivity; // the current activity
    private GameTimer myTimer = new GameTimer(this); // my player's timer
    private boolean gameOver; // whether the game is over

    /**
     * constructor
     *
     * @param playerInfo the name of the player
     */

    public GameProxyPlayer(Player playerInfo) {
        // set instance variables
        this.playerInfo = playerInfo;

        // mark game as not being over
        this.gameOver = false;

        // get new handler for this thread
        this.myHandler = new Handler();
    }

    /**
     * Returns this object's game timer
     *
     * @return this object's game timer.
     */
    protected final GameTimer getTimer() {
        return myTimer;
    }

    /**
     * "tick" call-back method, called when a timer message is received.
     */
    public final void tick(GameTimer timer) {
        // send the message to the player
        sendInfo(new TimerInfo(timer));
    }

    /**
     * Start's the GUI's thread, setting up handler.
     */
    public void start() {
        // Don't need to do anything since I'm already looping
        // and have a handler.
    }

    /**
     * perform any initialization that needs to be done after the player
     * knows what their game-position and opponents' names are.
     */
    protected void initAfterReady() {
        // by default, we do nothing
    }

    /**
     * Sets this player as the one attached to the GUI. Saves the
     * activity, then invokes subclass-specific method.
     */
    public final void gameSetAsGui(GameMainActivity a) {

        myActivity = a;
        setAsGui(a);

    }

    public int getPlayerNum() {
        return playerNum;
    }

    public String[] getAllPlayerNames() {
        return allPlayerNames;
    }

    /**
     * Subclass-behavior for setting this player to be the
     * one associated with the GUI. Typically, changes the
     * current screen to have a new layout, and sets up
     * listeners, animators, etc.
     *
     * @param activity the activity that is being run
     */
    public void setAsGui(GameMainActivity activity) {
        // default behavior is to do nothing
    }

    /*
     * ====================================================================
     * Abstract Methods
     *
     * Create the game specific functionality for this human player by
     * sub-classing this class and implementing the following methods.
     * --------------------------------------------------------------------
     */

    /*
     * ====================================================================
     * Public Methods
     * --------------------------------------------------------------------
     */

    /**
     * Sends game info to the player.
     *
     * @param info the information object to send
     */
    public void sendInfo(GameInfo info) {
        // wait until handler is there
        while (myHandler == null) Thread.yield();

        // post message to the handler
        Log.d("sendInfo", "about to post");
        myHandler.post(new MyRunnable(info));
        Log.d("sendInfo", "done with post");
    }

    /**
     * Callback method, called when player gets a message
     *
     * @param info the message
     */
    public abstract void receiveInfo(GameInfo info);

    /**
     * Helper-class that runs the on the GUI's main thread when
     * there is a message to the player.
     */
    private class MyRunnable implements Runnable {
        // the message to send to the player
        private GameInfo myInfo;

        // constructor
        public MyRunnable(GameInfo info) {
            myInfo = info;
        }

        // the run method, which is run in the main GUI thread
        public void run() {

            // if the game is over, just tell the activity that the game is over
            if (gameOver) {
                myActivity.setGameOver(true);
                return;
            }

            if (game == null) {
                // game has not been bound: the only thing we're looking for is
                // BindGameInfo object; ignore everything else
                if (myInfo instanceof BindGameInfo) {
                    Log.i("GameHumanPlayer", "binding game");
                    BindGameInfo bgs = (BindGameInfo) myInfo;
                    game = bgs.getGame(); // set the game
                    playerNum = bgs.getPlayerNum(); // set our player id

                    // respond to the game, telling it our name
                    game.sendAction(new MyNameIsAction(GameProxyPlayer.this, playerInfo.getEndPointId()));
                }
            } else if (allPlayerNames == null) {
                // here, the only thing we're looking for is a StartGameInfo object;
                // ignore everything else
                if (myInfo instanceof StartGameInfo) {
                    Log.i("GameHumanPlayer", "notification to start game");

                    // update our player-name array
                    allPlayerNames = ((StartGameInfo) myInfo).getPlayerNames();

                    // perform game-specific initialization
                    initAfterReady();

                    // tell the game we're ready to play the game
                    game.sendAction(new ReadyAction(GameProxyPlayer.this));
                }
            } else if (myInfo instanceof GameOverInfo) {
                // if we're being notified the game is over, finish up

                // perform the "gave over" behavior--by default, to show pop-up message
                gameIsOver(((GameOverInfo) myInfo).getMessage());

                // if our activity is non-null (which it should be), mark the activity as over
                if (myActivity != null) myActivity.setGameOver(true);

                // acknowledge to the game that the game is over
                game.sendAction(new GameOverAckAction(GameProxyPlayer.this));

                // set our instance variable, to indicate the game as over
                gameOver = true;
            } else if (myInfo instanceof TimerInfo) {
                // if we have a timer-tick, and it's our timer object,
                // directly invoke the subclass method; otherwise, pass
                // it on as a message
                if (((TimerInfo) myInfo).getTimer() == myTimer) {
                    // checking that it's from our timer
                    timerTicked();
                } else {
                    receiveInfo(myInfo);
                }
            } else {
                receiveInfo(myInfo);
            }
        }
    }

    /**
     * callback method--called when we are notified that the game is over
     *
     * @param msg the "game over" message sent by the game
     */
    protected void gameIsOver(String msg) {
        // the default behavior is to put a pop-up for the user to see that tells
        // the game's result
        MessageBox.popUpMessage(msg, myActivity);
    }

    /**
     * Tells whether this class requires a GUI to run
     *
     * @return true, since this player needs to be running as a GUI
     */
    public final boolean requiresGui() {
        return false;
    }

    /**
     * Tells whether this class supports the running in a GUI
     *
     * @return true, since this player actually needs to be running as a GUI
     */
    public final boolean supportsGui() {
        return false;
    }

    public boolean isProxy() {
        return true;
    }

    public Player getPlayerInfo() {
        return playerInfo;
    }

    /**
     * Invoked whenever the player's timer has ticked. It is expected
     * that this will be overridden in many games.
     */
    protected void timerTicked() {
        // by default, do nothing
    }

}// class GameHumanPlayer

