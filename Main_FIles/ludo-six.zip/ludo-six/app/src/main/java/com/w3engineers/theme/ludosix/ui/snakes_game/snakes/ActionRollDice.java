package com.w3engineers.theme.ludosix.ui.snakes_game.snakes;

import com.w3engineers.theme.ludosix.ui.snakes_game.game.GamePlayer;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.actionMsg.GameAction;

/**
 * ActionRollDice
 * Game action that is sent to ludo local game. it is used to indicate if the
 * player wishes to roll a dice.
 */
public class ActionRollDice extends GameAction {

    private int diceVal;

    /**
     * constructor for GameAction
     *
     * @param player the player who created the action
     */
    public ActionRollDice(GamePlayer player) {
        super(player);
    }

    public ActionRollDice(GamePlayer player, int diceVal) {
        super(player);
        this.diceVal = diceVal;
    }

    public int getDiceVal() {
        return diceVal;
    }

    public void setDiceVal(int diceVal) {
        this.diceVal = diceVal;
    }
}
