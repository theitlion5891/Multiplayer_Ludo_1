package com.w3engineers.theme.ludosix.data.local.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/23/2018 at 11:54 AM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Score board model class
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 13/02/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 13/02/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class ScoreBoard implements Parcelable {

    private int vs2PlayersWin;
    private int vs3PlayersWin;
    private int vs4PlayersWin;
    private int vs2PlayersLose;
    private int vs3PlayersLose;
    private int vs4PlayersLose;

    public ScoreBoard() {

    }

    public int getVs2PlayersWin() {
        return vs2PlayersWin;
    }

    public void setVs2PlayersWin(int vs2PlayersWin) {
        this.vs2PlayersWin = vs2PlayersWin;
    }

    public int getVs3PlayersWin() {
        return vs3PlayersWin;
    }

    public void setVs3PlayersWin(int vs3PlayersWin) {
        this.vs3PlayersWin = vs3PlayersWin;
    }

    public int getVs4PlayersWin() {
        return vs4PlayersWin;
    }

    public void setVs4PlayersWin(int vs4PlayersWin) {
        this.vs4PlayersWin = vs4PlayersWin;
    }

    public int getVs2PlayersLose() {
        return vs2PlayersLose;
    }

    public void setVs2PlayersLose(int vs2PlayersLose) {
        this.vs2PlayersLose = vs2PlayersLose;
    }

    public int getVs3PlayersLose() {
        return vs3PlayersLose;
    }

    public void setVs3PlayersLose(int vs3PlayersLose) {
        this.vs3PlayersLose = vs3PlayersLose;
    }

    public int getVs4PlayersLose() {
        return vs4PlayersLose;
    }

    public void setVs4PlayersLose(int vs4PlayersLose) {
        this.vs4PlayersLose = vs4PlayersLose;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    protected ScoreBoard(Parcel in) {
        vs2PlayersWin = in.readInt();
        vs3PlayersWin = in.readInt();
        vs4PlayersWin = in.readInt();
        vs2PlayersLose = in.readInt();
        vs3PlayersLose = in.readInt();
        vs4PlayersLose = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(vs2PlayersWin);
        parcel.writeInt(vs3PlayersWin);
        parcel.writeInt(vs4PlayersWin);
        parcel.writeInt(vs2PlayersLose);
        parcel.writeInt(vs3PlayersLose);
        parcel.writeInt(vs4PlayersLose);
    }

    public static final Creator<ScoreBoard> CREATOR = new Creator<ScoreBoard>() {
        @Override
        public ScoreBoard createFromParcel(Parcel in) {
            return new ScoreBoard(in);
        }

        @Override
        public ScoreBoard[] newArray(int size) {
            return new ScoreBoard[size];
        }
    };
}
