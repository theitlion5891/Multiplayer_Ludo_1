package com.w3engineers.theme.ludosix.data.remote.s3api.helper;

/*
 *  ****************************************************************************
 *  * Created by : Ahmed Mohmmad Ullah (Azim) on 5/3/2018 at 3:59 PM.
 *  * Email : azim@w3engineers.com
 *  *
 *  * Last edited by : Ahmed Mohmmad Ullah (Azim) on 5/3/2018.
 *  *
 *  * Last Reviewed by : <Reviewer Name> on <mm/dd/yy>
 *  ****************************************************************************
 */
public interface S3FileUploaderListener {

    void onFileUploadSuccess(String filePath);
    void onFileUploadFailed(String filePath, int reason);
    void onFileUploadProgress(String filePath, int percentage);

}
