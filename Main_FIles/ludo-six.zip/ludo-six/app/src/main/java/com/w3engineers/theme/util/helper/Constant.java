package com.w3engineers.theme.util.helper;

import android.os.Environment;

public class Constant {
    public interface Directory {
        String PARENT_DIRECTORY = Environment.getExternalStorageDirectory().toString() + "/LudoSix/";
        String PLAYER_IMAGES = "/PlayerImages/";
        String FILE_NO_MEDIA = "/.nomedia/";
        int MAXIMUM_IMAGE = 50;
    }
}
