package com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg;

public class HostDisconnectedInfo extends GameInfo {
    // Info flag for host disconnect event
}
