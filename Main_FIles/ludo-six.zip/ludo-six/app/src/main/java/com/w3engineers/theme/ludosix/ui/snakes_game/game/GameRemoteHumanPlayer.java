package com.w3engineers.theme.ludosix.ui.snakes_game.game;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.actionMsg.MyNameIsAction;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg.BindGameInfo;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg.GameInfo;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg.GameOverInfo;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg.HostDisconnectedInfo;
import com.w3engineers.theme.util.helper.ToneFactory;

public abstract class GameRemoteHumanPlayer implements GamePlayer {
    /**
     * instance variables
     */
    protected Game game; // the game
    protected int playerNum; // my player ID
    //    protected String name; // my player's name
    protected Player playerInfo; // my player's name
    private Handler myHandler; // my thread's handler
    private GameMainActivity myActivity; // the current activity
    private boolean gameOver; // whether the game is over

    /**
     * constructor
     *
     * @param playerInfo the name of the player
     */

    public GameRemoteHumanPlayer(Player playerInfo) {
        // set instance variables
        this.playerInfo = playerInfo;

        // mark game as not being over
        this.gameOver = false;

        // get new handler for this thread
        this.myHandler = new Handler();
    }

    /**
     * Returns the GUI's top object; used for flashing.
     *
     * @return the GUI's top object.
     */
    public abstract View getTopView();

    /**
     * Start's the GUI's thread, setting up handler.
     */
    public void start() {
        // Don't need to do anything since I'm already looping
        // and have a handler.
    }

    /**
     * Sets this player as the one attached to the GUI. Saves the
     * activity, then invokes subclass-specific method.
     */
    public final void gameSetAsGui(GameMainActivity a) {

        myActivity = a;
        setAsGui(a);

    }

    /*
     * ====================================================================
     * Abstract Methods
     *
     * Create the game specific functionality for this human player by
     * sub-classing this class and implementing the following methods.
     * --------------------------------------------------------------------
     */

    /*
     * ====================================================================
     * Public Methods
     * --------------------------------------------------------------------
     */

    /**
     * Sends game info to the player.
     *
     * @param info the information object to send
     */
    public void sendInfo(GameInfo info) {
        // wait until handler is there
        while (myHandler == null) Thread.yield();

        // post message to the handler
        Log.d("sendInfo", "about to post");
        myHandler.post(new MyRunnable(info));
        Log.d("sendInfo", "done with post");
    }

    /**
     * Callback method, called when player gets a message
     *
     * @param info the message
     */
    public abstract void receiveInfo(GameInfo info);

    /**
     * Helper-class that runs the on the GUI's main thread when
     * there is a message to the player.
     */
    private class MyRunnable implements Runnable {
        // the message to send to the player
        private GameInfo myInfo;

        // constructor
        public MyRunnable(GameInfo info) {
            myInfo = info;
        }

        // the run method, which is run in the main GUI thread
        public void run() {

            // if the game is over, just tell the activity that the game is over
            if (gameOver) {
                myActivity.setGameOver(true);
                return;
            }

            if (game == null) {
                // game has not been bound: the only thing we're looking for is
                // BindGameInfo object; ignore everything else
                if (myInfo instanceof BindGameInfo) {
                    Log.i("GameHumanPlayer", "binding game");
                    BindGameInfo bgs = (BindGameInfo) myInfo;
                    game = bgs.getGame(); // set the game
                    playerNum = bgs.getPlayerNum(); // set our player id

                    // respond to the game, telling it our name
                    game.sendAction(new MyNameIsAction(GameRemoteHumanPlayer.this, playerInfo.getEndPointId()));
                }
            } else if (myInfo instanceof HostDisconnectedInfo) {
                showHostDisconnectDialog();

            } else if (myInfo instanceof GameOverInfo) {
                // if we're being notified the game is over, finish up

                // perform the "gave over" behavior--by default, to show pop-up message
                gameIsOver(((GameOverInfo) myInfo).getMessage());

                // if our activity is non-null (which it should be), mark the activity as over
                if (myActivity != null) myActivity.setGameOver(true);

                // acknowledge to the game that the game is over
//                game.sendAction(new GameOverAckAction(GameRemoteHumanPlayer.this));

                // set our instance variable, to indicate the game as over
                gameOver = true;
            } else {
                receiveInfo(myInfo);
            }
        }
    }

    /**
     * callback method--called when we are notified that the game is over
     *
     * @param msg the "game over" message sent by the game
     */
    protected void gameIsOver(String msg) {
        // the default behavior is to put a pop-up for the user to see that tells
        // the game's result
        showGameOverDialog(msg);
    }

    /**
     * Shows host disconnect dialog
     */
    public void showHostDisconnectDialog() {

        Dialog dialog = new Dialog(myActivity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.layout_disconnect_dialog);

        // Making background transparent
        if (dialog.getWindow() != null)
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        dialog.findViewById(R.id.layout_disconnect_dialog_play_again_btn).setOnClickListener(v -> {
            ToneFactory.on().stop();
            myActivity.finish();
        });

        dialog.show();
    }

    /**
     * Shows custom game end dialog
     */
    private void showGameOverDialog(String msg) {
        // Playing game win sound
        ToneFactory.on().play(R.raw.game_win);

        Dialog dialog = new Dialog(myActivity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.layout_game_over_dialog);

        // Making background transparent
        if (dialog.getWindow() != null)
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView text = dialog.findViewById(R.id.layout_game_over_body_text);
        text.setText(msg);

        dialog.findViewById(R.id.layout_game_over_play_again_btn).setOnClickListener(v -> {
            ToneFactory.on().stop();
            myActivity.finish();
        });

        dialog.show();
    }

    /**
     * Tells whether this class requires a GUI to run
     *
     * @return true, since this player needs to be running as a GUI
     */
    public final boolean requiresGui() {
        return true;
    }

    /**
     * Tells whether this class supports the running in a GUI
     *
     * @return true, since this player actually needs to be running as a GUI
     */
    public final boolean supportsGui() {
        return true;
    }

    public boolean isProxy() {
        return false;
    }

    public Player getPlayerInfo() {
        return playerInfo;
    }
}

