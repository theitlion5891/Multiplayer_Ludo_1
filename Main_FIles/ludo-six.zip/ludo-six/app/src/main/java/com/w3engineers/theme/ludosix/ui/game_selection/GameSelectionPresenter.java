package com.w3engineers.theme.ludosix.ui.game_selection;

import java.util.concurrent.TimeUnit;

import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import com.w3engineers.theme.LudoSixApp;
import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.NotifyWorker;
import com.w3engineers.theme.ludosix.ui.base.BasePresenter;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 01/03/2018 at 12:03 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Presenter class
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 01/03/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 01/03/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class GameSelectionPresenter extends BasePresenter<GameSelectionMvpView> {

    /**
     * Schedules/Replaces a periodic work request for daily notifications
     */
    public void schedulePeriodicWork() {
        PeriodicWorkRequest.Builder notifyWorkReqBuilder =
                new PeriodicWorkRequest.Builder(NotifyWorker.class, 1, TimeUnit.DAYS);

        WorkManager.getInstance().enqueueUniquePeriodicWork(LudoSixApp.getContext().getString(R.string.unique_work_name),
                ExistingPeriodicWorkPolicy.REPLACE, notifyWorkReqBuilder.build());
    }
}
