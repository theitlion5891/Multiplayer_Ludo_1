package com.w3engineers.theme.util.helper;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;

import java.io.File;
import java.io.IOException;

import id.zelory.compressor.Compressor;
import com.w3engineers.theme.LudoSixApp;

/**
 * Created by pl@b0n on 11/28/2018.
 */
public class ImageCompressHelper {

    private Uri mActualFileUri;
    private File mActualFile;
    private Context mContext;
    private ImageCompressedListener mListener;
    private static final long MAXIMUM_IMAGE_SIZE_IN_BYTE = 10*1024;

    public interface ImageCompressedListener{
         void onImageCompressed(Uri uri);
    }

    public ImageCompressHelper(ImageCompressedListener listener){
        mListener = listener;
        mContext = LudoSixApp.getContext();
    }

    public void compress(Uri actualFileUri){
        mActualFileUri =  actualFileUri;
        if(mActualFileUri!=null) {
            mActualFile = new File(mActualFileUri.getPath());
            if(mActualFile!=null){
                if(mActualFile.length()>MAXIMUM_IMAGE_SIZE_IN_BYTE)
                    doCompress(mActualFile);
                else {
                    if(mListener!=null){
                        mListener.onImageCompressed(Uri.fromFile(mActualFile));
                    }
                }
            }

        }else{
            throw new NullPointerException("Uri null");
        }
    }

    private void doCompress(File file){
        try {
            File compressedFile=new Compressor(mContext)
                    .setMaxWidth(100)
                    .setMaxHeight(100)
                    .setQuality(50)
                    .setCompressFormat(Bitmap.CompressFormat.JPEG)
                    .setDestinationDirectoryPath(Environment.getExternalStoragePublicDirectory(
                            Environment.DIRECTORY_PICTURES).getAbsolutePath())
                    .compressToFile(file);
            if(compressedFile.length()>MAXIMUM_IMAGE_SIZE_IN_BYTE){
                doCompress(compressedFile);
            }else{
                if(mListener!=null)
                    mListener.onImageCompressed(Uri.fromFile(compressedFile));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
