package com.w3engineers.theme.ludosix.data.remote.pushapi;

/**
 * Created by Dell on 10/24/2017.
 */

public class PushService {
}
