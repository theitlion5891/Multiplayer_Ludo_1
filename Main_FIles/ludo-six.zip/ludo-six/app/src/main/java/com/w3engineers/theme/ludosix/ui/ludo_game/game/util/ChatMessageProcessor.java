package com.w3engineers.theme.ludosix.ui.ludo_game.game.util;

import android.content.Context;
import androidx.core.content.res.ResourcesCompat;
import androidx.appcompat.content.res.AppCompatResources;
import android.text.Html;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.local.model.Message;
import com.w3engineers.theme.util.helper.ViewUtils;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 2/4/2019 at 6:30 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Executes the received messages in queue
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 2/4/2019.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 2/4/2019.
 * Copyright (c) 2019, W3 Engineers Ltd. All rights reserved.
 */
public class ChatMessageProcessor {

    private static final int DATA_PROCESS_DELAY = 30;

    private List<Message> messageQueue = new ArrayList<>();
    private static ChatMessageProcessor sGameQueueProcessor = new ChatMessageProcessor();

    private ChatMessageProcessor() {
    }

    public static ChatMessageProcessor getInstance() {
        return sGameQueueProcessor;
    }

    public void clearMessageQueue() {
        messageQueue.clear();
    }

    public void addMessage(Message message) {
        messageQueue.add(message);
    }

    public List<TextView> getChatMessageViews(Context context) {

        List<TextView> views = new ArrayList<>();
//        LinearLayout parent = new LinearLayout(context);
//        parent.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
//        parent.setOrientation(LinearLayout.VERTICAL);

        for (int i = 0; i < messageQueue.size(); i++) {
            Message message = messageQueue.get(i);

            TextView tv = new TextView(context);
            tv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            tv.setTextColor(context.getResources().getColor(R.color.white));
            tv.setTypeface(ResourcesCompat.getFont(context, R.font.roboto_medium));
//            tv.setTextSize(16);
            tv.setPadding(0, 0, 0, ViewUtils.dpToPx(5));

//            String coloredName = "<font color=#078C43>" + message.getPlayerName() + ":</font>";
//            tv.setText(Html.fromHtml(String.format("%s %s", coloredName, message.getChatText())));


            if (message.getResType() == Message.Type.TEXT) {
                tv.setText(Html.fromHtml(String.format("%s: %s", message.getPlayerName(), message.getChatText())));

            } else {
                tv.setText(Html.fromHtml(String.format("%s: ", message.getPlayerName())));
                tv.setCompoundDrawablesWithIntrinsicBounds(null, null, AppCompatResources.getDrawable(context,
                        message.getChatIconId()), null);
            }

//            parent.addView(tv);
            views.add(tv);
        }

        return views;
    }

    public void removeLastMessage() {
        messageQueue.remove(0);
    }
}
