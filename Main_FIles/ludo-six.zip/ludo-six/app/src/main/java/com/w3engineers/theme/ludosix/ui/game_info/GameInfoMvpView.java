package com.w3engineers.theme.ludosix.ui.game_info;

import com.w3engineers.theme.ludosix.ui.base.MvpView;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 12/28/2018 at 11:03 AM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: View class
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 12/28/2018
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 12/28/2018
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public interface GameInfoMvpView extends MvpView {
}
