package com.w3engineers.theme.ludosix.ui.snakes_game.snakes;

import com.w3engineers.theme.ludosix.ui.snakes_game.game.GamePlayer;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.actionMsg.GameAction;

/**
 * ActionAnimateDice class
 * Game action that is sent to LudoLocalgame
 */
public class ActionHostDisconnected extends GameAction {

    /**
     * constructor for GameAction
     *
     * @param player the player who created the action
     */
    public ActionHostDisconnected(GamePlayer player) {
        super(player);
    }

}
