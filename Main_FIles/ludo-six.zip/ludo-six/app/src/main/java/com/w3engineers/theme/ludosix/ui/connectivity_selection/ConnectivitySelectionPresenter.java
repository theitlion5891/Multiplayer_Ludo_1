package com.w3engineers.theme.ludosix.ui.connectivity_selection;

import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.w3engineers.theme.LudoSixApp;
import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.NotifyWorker;
import com.w3engineers.theme.ludosix.ui.base.BasePresenter;

import java.util.concurrent.TimeUnit;

public class ConnectivitySelectionPresenter  extends BasePresenter<ConnectivitySelectionMvpView> {

    /**
     * Schedules/Replaces a periodic work request for daily notifications
     */
    public void schedulePeriodicWork() {
        PeriodicWorkRequest.Builder notifyWorkReqBuilder =
                new PeriodicWorkRequest.Builder(NotifyWorker.class, 1, TimeUnit.DAYS);

        WorkManager.getInstance().enqueueUniquePeriodicWork(LudoSixApp.getContext().getString(R.string.unique_work_name),
                ExistingPeriodicWorkPolicy.REPLACE, notifyWorkReqBuilder.build());
    }
}
