package com.w3engineers.theme.ludosix.data.remote;

import android.content.Context;
import android.os.AsyncTask;

import java.io.File;

import com.w3engineers.theme.ludosix.data.remote.helper.InitManagerAsync;
import com.w3engineers.theme.ludosix.data.remote.helper.RemoteApiOption;
import com.w3engineers.theme.ludosix.data.remote.helper.callback.AuthSignInCallback;
import com.w3engineers.theme.ludosix.data.remote.helper.callback.AuthSignUpCallback;
import com.w3engineers.theme.ludosix.data.remote.helper.callback.FileTransferCallback;
import com.w3engineers.theme.ludosix.data.remote.helper.callback.UserCallback;
import com.w3engineers.theme.ludosix.data.remote.helper.models.ChatMessage;
import com.w3engineers.theme.ludosix.data.remote.helper.models.RemoteObject;
import com.w3engineers.theme.ludosix.data.remote.parseapi.ParseManager;
import com.w3engineers.theme.ludosix.data.remote.s3api.S3Manager;
import com.w3engineers.theme.ludosix.data.remote.thundercharmapi.TCharmManager;

/**
 * * ============================================================================
 * * Copyright (C) 2018 W3 Engineers Ltd - All Rights Reserved.
 * * Unauthorized copying of this file, via any medium is strictly prohibited
 * * Proprietary and confidential
 * * ----------------------------------------------------------------------------
 * * Created by: Sudipta K Paik on [13-Jul-2018 at 12:12 PM].
 * * Email: sudipta@w3engineers.com
 * * ----------------------------------------------------------------------------
 * * Project: Generic API.
 * * Code Responsibility: <Purpose of code>
 * * ----------------------------------------------------------------------------
 * * Edited by :
 * * --> <First Editor> on [13-Jul-2018 at 12:12 PM].
 * * --> <Second Editor> on [13-Jul-2018 at 12:12 PM].
 * * ----------------------------------------------------------------------------
 * * Reviewed by :
 * * --> <First Reviewer> on [13-Jul-2018 at 12:12 PM].
 * * --> <Second Reviewer> on [13-Jul-2018 at 12:12 PM].
 * * ============================================================================
 **/

public class RemoteApi {
    /*RegionStart: Singleton Internal */
    private static volatile RemoteApi ourInstance;
    private static Object mutex = new Object();

    private RemoteApi(Context context, RemoteApiOption remoteApiOption) {

        new InitManagerAsync(context, remoteApiOption).execute();
    }

    public synchronized static void init(Context context, RemoteApiOption remoteApiOption) {

        synchronized (mutex) {
            if (ourInstance == null)
                ourInstance = new RemoteApi(context, remoteApiOption);
        }
    }

    public static RemoteApi on() {

        return ourInstance;
    }
    /*RegionEnd: Singleton Internal */

    /*RegionStart: Public API */

    public void signUp(String username, String password, RemoteObject remoteObject, AuthSignUpCallback callback) {

        AsyncTask.execute(() -> ParseManager.on().signUp(username, password, remoteObject, callback));
    }

    public void signIn(String username, String password, AuthSignInCallback callback) {

        AsyncTask.execute(() -> ParseManager.on().signIn(username, password, callback));
    }

    public void logOut() {

        AsyncTask.execute(() -> ParseManager.on().logOut());
    }

    public void LiveQuerySubscribe(String user) {

        AsyncTask.execute(() -> ParseManager.on().LiveQuerySubscribe(user));
    }

    public void getCurrentUser(UserCallback callback) {

        AsyncTask.execute(() -> ParseManager.on().getCurrentUser(callback));
    }

    public void sendChatMessage(String user, ChatMessage chatMessage) {

        AsyncTask.execute(() -> TCharmManager.on().sendMessage(user, chatMessage));
    }

    public void uploadFile(String url, String file_key, File file, FileTransferCallback callback) {

        AsyncTask.execute(() -> S3Manager.on().uploadFile(url, file_key, file, callback));
    }
    /*RegionStart: Public API */
}