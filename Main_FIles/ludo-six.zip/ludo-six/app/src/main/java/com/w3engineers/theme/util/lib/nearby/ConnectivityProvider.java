package com.w3engineers.theme.util.lib.nearby;

import android.os.Handler;
import androidx.annotation.NonNull;
import androidx.collection.SimpleArrayMap;
import android.util.Log;

import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.gson.Gson;
import com.google.protobuf.InvalidProtocolBufferException;
import com.left.core.util.lib.nearby.GameMessages;
import com.left.core.util.lib.nearby.GameMessages.EndPoint;

import org.greenrobot.eventbus.EventBus;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.w3engineers.theme.LudoSixApp;
import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.data.local.event.GameActionEvent;
import com.w3engineers.theme.ludosix.data.local.event.GameDataEvent;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.LudoState;
import com.w3engineers.theme.util.helper.AndroidUtil;

/**
 * Created by pl@b0n on 11/14/2018.
 */
public class ConnectivityProvider {


    public enum ConnectionRole {
        HOST,
        CLIENT
    }

    private static final String TAG = "ConnectivityProvider";
    private static volatile ConnectivityProvider sConnectivityProvider = null;
    /**
     * Strategy to use to build a mesh
     */
    private final Strategy STRATEGY = Strategy.P2P_STAR;

    /**
     * Our ConnectionClient object used as a handle of near P2P_STAR by apis
     */
    private ConnectionsClient mConnectionsClient;

    private final Map<String, EndPoint> disCoveredEndPoints = new HashMap<>();
    private final Map<String, EndPoint> mPendingConnections = new HashMap<>();
    private final Map<String, EndPoint> mConnectedEndPoints = new HashMap<>();

    private final Map<String, EndPoint> otherSpokes = new HashMap<>();

    private final SimpleArrayMap<Long, Payload> incomingPayloads = new SimpleArrayMap<>();
    private final SimpleArrayMap<Long, String> filePayloadFilenames = new SimpleArrayMap<>();
    private final SimpleArrayMap<Long, Payload> completedPayloads = new SimpleArrayMap<>();

    private Handler handler = new Handler();
    private static final Object locker = new Object();

    private String mNetworkName;
    private boolean isDiscoverying = false;
    private boolean isAdvertising = false;

    private ConnectionRole currentRole = ConnectionRole.CLIENT;
    private EndPoint hostEndpoint = null;

    public EndPoint getHostEndpoint() {
        return hostEndpoint;
    }

    public void setHostEndpoint(EndPoint hostEndpoint) {
        this.hostEndpoint = hostEndpoint;
    }


    public ConnectivityProvider() {
        mConnectionsClient = Nearby.getConnectionsClient(LudoSixApp.getContext());
    }


    public static ConnectivityProvider getConnectivity() {
        ConnectivityProvider temp = sConnectivityProvider;
        if (temp == null) {
            synchronized (locker) {
                temp = sConnectivityProvider;        // thread may have instantiated the object.
                if (temp == null) {
                    temp = new ConnectivityProvider();
                    sConnectivityProvider = temp;
                }
            }
        }
        return sConnectivityProvider;
    }


    public void setCurrentRole(ConnectionRole role) {
        this.currentRole = role;
    }

    public ConnectionRole getCurrentRole() {
        return this.currentRole;
    }

    public void startFindingNearbyDevices(ConnectionRole role) {
        setCurrentRole(role);
        disconnectFromAllEndpoints();

        if (role == ConnectionRole.HOST)
            startAdvertising();
        else
            startDiscovery();
    }

    /**
     * Sends a {@link Payload} to specified connected endpoint.
     *
     * @param payload  The data you want to send.
     * @param endPoint EndPoint you want to send the payload to
     */
    protected void send(Payload payload, EndPoint endPoint) {
        if (mConnectionsClient != null) {
            mConnectionsClient.sendPayload(endPoint.getEndPointId(), payload)
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e(TAG, "onFailure: send payload");
                        }
                    }).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.d(TAG, "onSuccess: Send payload");

                }
            });
        }
    }

    protected void send(Payload payload, String endPointId, int i) {
        Log.e("stuck", "Start Sending 1 " + i);
        if (mConnectionsClient != null) {
            Log.e("stuck", "Start Sending 2");
            mConnectionsClient.sendPayload(endPointId, payload)
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e("stuck", "onFailure: send payload");

                        }
                    }).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.d("stuck", "onSuccess: Send payload");
                }
            });
        }
    }

    /**
     * @param payload
     * @param endpointIds
     */
    protected void send(Payload payload, List<String> endpointIds) {
        if (mConnectionsClient != null) {
            mConnectionsClient.sendPayload(endpointIds, payload)
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e(TAG, "onFailure: send payload to batch");
                        }
                    }).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.d(TAG, "onSuccess: Send payload to batch");

                }
            });
        }
    }

    private void handleIncomingInvitationPackets(GameMessages.EndPoint endPoint, GameMessages.InvitationPacket invitationPacket) {
        NearbyInvitationEvent nearbyInvitationEvent;

        switch (invitationPacket.getType()) {
            case INVITE:
                nearbyInvitationEvent = new NearbyInvitationEvent(InvitationPacketType.INVITE, invitationPacket.getEndpointsList(), endPoint);
                EventBus.getDefault().post(nearbyInvitationEvent);
                break;

            case ACCEPT:
                nearbyInvitationEvent = new NearbyInvitationEvent(InvitationPacketType.ACCEPT, invitationPacket.getEndpointsList(), endPoint);
                EventBus.getDefault().post(nearbyInvitationEvent);
                break;

            case DECLINE:
                nearbyInvitationEvent = new NearbyInvitationEvent(InvitationPacketType.DECLINE, endPoint);
                EventBus.getDefault().post(nearbyInvitationEvent);
                break;

            case UPDATE_ACCEPT:
                endPoint = invitationPacket.getEndpoint();
                otherSpokes.put(endPoint.getEndPointId(), endPoint);
                nearbyInvitationEvent = new NearbyInvitationEvent(InvitationPacketType.UPDATE_ACCEPT, endPoint);
                EventBus.getDefault().post(nearbyInvitationEvent);
                break;

            case MESH_PLAYER_INFO:
                List<EndPoint> endPoints = invitationPacket.getEndpointsList();
                for (EndPoint e : endPoints) {
                    otherSpokes.put(e.getEndPointId(), e);
                }
                nearbyInvitationEvent = new NearbyInvitationEvent(InvitationPacketType.MESH_PLAYER_INFO, endPoints);
                EventBus.getDefault().post(nearbyInvitationEvent);
                break;

            case PLAYER_DISCONNECTED:
                endPoint = invitationPacket.getEndpoint();
                nearbyInvitationEvent = new NearbyInvitationEvent(InvitationPacketType.PLAYER_DISCONNECTED, endPoint);
                EventBus.getDefault().post(nearbyInvitationEvent);
                break;

            case PLAYER_REMOVED:
                endPoint = invitationPacket.getEndpoint();
                nearbyInvitationEvent = new NearbyInvitationEvent(InvitationPacketType.PLAYER_REMOVED, endPoint);
                EventBus.getDefault().post(nearbyInvitationEvent);
                break;

            case REMOVED:
                nearbyInvitationEvent = new NearbyInvitationEvent(InvitationPacketType.REMOVED, endPoint);
                EventBus.getDefault().post(nearbyInvitationEvent);
                break;

            case READY_TO_PLAY:
                nearbyInvitationEvent = new NearbyInvitationEvent(InvitationPacketType.READY_TO_PLAY, invitationPacket.getEndpointsList());
                EventBus.getDefault().post(nearbyInvitationEvent);
                break;

            case READY_TO_PLAY_ACK:
                nearbyInvitationEvent = new NearbyInvitationEvent(InvitationPacketType.READY_TO_PLAY_ACK, invitationPacket.getEndpoint());
                EventBus.getDefault().post(nearbyInvitationEvent);
                break;

            case GAME_START:
                nearbyInvitationEvent = new NearbyInvitationEvent(InvitationPacketType.GAME_START);
                EventBus.getDefault().post(nearbyInvitationEvent);
                break;
        }
    }

    private void handleUserData(GameMessages.ImageFilenamePacket imageFilenamePacket
            , String fromEndPointId) {
        String payloadFilenameMessage = imageFilenamePacket.getImageName();
        long payloadId = addPayloadFilename(payloadFilenameMessage);
        processImage(payloadId, fromEndPointId);
    }


    /**
     * Extracts the payloadId and filename from the message and stores it in the
     * filePayloadFilenames map. The format is payloadId:filename.
     */
    private long addPayloadFilename(String payloadFilenameMessage) {
        Log.d(TAG, "addPayloadFilename: " + payloadFilenameMessage);
        int colonIndex = payloadFilenameMessage.indexOf(':');
        String payloadId = payloadFilenameMessage.substring(0, colonIndex);
        long payloadIdLong = Long.valueOf(payloadId).longValue();
        String filename = payloadFilenameMessage.substring(colonIndex + 1);
        filePayloadFilenames.put(payloadIdLong, filename);
        return payloadIdLong;
    }

    private void processImage(long payloadId, String endPointId) {
        // BYTES and FILE could be received in any order, so we call when either the BYTES or the FILE
        // payload is completely received. The file payload is considered complete only when both have
        // been received.
        Payload filePayload = completedPayloads.get(payloadId);
        String temp = filePayloadFilenames.get(payloadId);
        // Retrieve the filename that was received in a bytes payload.
        if (filePayload != null && temp != null) {
            if (temp != null) {
                String[] tokens = temp.split(":");
                String ownerEndPointId;
                String newFilename;
                if (tokens.length < 2) {
                    ownerEndPointId = endPointId;
                    newFilename = tokens[0];
                } else {
                    ownerEndPointId = tokens[0];
                    newFilename = tokens[1];
                }

                File payloadFile = filePayload.asFile().asJavaFile();
                // Rename the file.
                File renamedFile = new File(payloadFile.getParentFile(), newFilename);
                boolean isRenamed = payloadFile.renameTo(renamedFile);
                if (isRenamed && (mConnectedEndPoints.containsKey(ownerEndPointId) || otherSpokes.containsKey(ownerEndPointId))) {
                    EndPoint owner = mConnectedEndPoints.containsKey(ownerEndPointId) ? mConnectedEndPoints.get(ownerEndPointId) : otherSpokes.get(ownerEndPointId);
                    ImageRecievedEvent imageRecievedEvent = new ImageRecievedEvent(owner, renamedFile.getAbsolutePath());
                    EventBus.getDefault().post(imageRecievedEvent);
                } else {
                    Log.e(TAG, "processImage: this image is not for me");
                }

            }
        }
    }

    /**
     * call back for data payload transfer related events
     * like(send, recieve and progress)
     */
    private final PayloadCallback payloadCallback = new PayloadCallback() {
        @Override
        public void onPayloadReceived(String s, Payload payload) {
            Log.e("stuck", "onPayloadReceived ");
            Log.d(TAG, "onPayloadReceived: from " + s + "Type: " + payload.getType());
            EndPoint endPoint = mConnectedEndPoints.get(s);
            if (endPoint != null) {
                if (payload.getType() == Payload.Type.BYTES) {
                    try {
                        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.parseFrom(payload.asBytes());
                        switch (dataPacket.getPacketType()) {
                            case INVITATION_DATA:
                                GameMessages.InvitationPacket invitationPacket = dataPacket.getInvitation();
                                handleIncomingInvitationPackets(endPoint, invitationPacket);
                                break;

                            case USER_DATA:
                                GameMessages.ImageFilenamePacket imageFilenamePacket = dataPacket.getImageFilename();
                                handleUserData(imageFilenamePacket, s);
                                break;

                            case GAME_SETTINGS:
                                GameMessages.GameSettingsPacket gameSettingsPacket = dataPacket.getGameSettingsPacket();
                                handleInComingGameSettings(gameSettingsPacket);
                                break;

                            case GAME_DATA:
                                handleGameData(dataPacket.getGameData());
                                break;

                            default:
                                break;
                        }
                    } catch (InvalidProtocolBufferException e) {
                        e.printStackTrace();
                    }

                } else if (payload.getType() == Payload.Type.FILE) {
                    incomingPayloads.put(payload.getId(), payload);
                }

            }
        }

        @Override
        public void onPayloadTransferUpdate(String s, PayloadTransferUpdate payloadTransferUpdate) {
            Log.d(TAG, "onPayloadTransferUpdate: " + s);
            if (payloadTransferUpdate.getStatus() == PayloadTransferUpdate.Status.SUCCESS) {
                long payloadId = payloadTransferUpdate.getPayloadId();
                Log.d(TAG, "onPayloadTransferUpdate: payloadId: " + payloadId);
                Payload payload = incomingPayloads.remove(payloadId);
                completedPayloads.put(payloadId, payload);
                if (payload != null && payload.getType() == Payload.Type.FILE) {
                    processImage(payloadId, s);

                }
            } else if (payloadTransferUpdate.getStatus() == PayloadTransferUpdate.Status.FAILURE
                    || payloadTransferUpdate.getStatus() == PayloadTransferUpdate.Status.CANCELED) {
            }
        }
    };

    private void handleGameData(GameMessages.GameDataPacket gameDataPacket) {

        if (gameDataPacket.getDataType() == GameMessages.GameDataPacket.DataType.GAME_ACTION) {
            Log.e("stuck", "Test test");
            GameActionEvent gameActionEvent = new Gson().fromJson(gameDataPacket.getData(), GameActionEvent.class);
            Log.e("stuck", "Test test " + gameActionEvent.getAction());
            EventBus.getDefault().post(new GameDataEvent(gameActionEvent, false));


        } else {
            Log.e("stuck", "else Test test");
            LudoState ludoState = new Gson().fromJson(gameDataPacket.getData(), LudoState.class);
            Log.e("stuck", "else Test test " + ludoState.getAction());
            EventBus.getDefault().post(new GameDataEvent(ludoState, true));
        }
    }

    private void handleInComingGameSettings(GameMessages.GameSettingsPacket gameSettingsPacket) {
        NearbyGameSettingsEvent nearbyGameSettingsEvent = new NearbyGameSettingsEvent(gameSettingsPacket.getGameMode());
        EventBus.getDefault().post(nearbyGameSettingsEvent);
    }

    /**
     * end point is connected
     * send update to app layer via EventBus
     *
     * @param endpoint
     */
    public void connectedToEndpoint(EndPoint endpoint) {
        if (currentRole == ConnectionRole.CLIENT && mConnectedEndPoints.size() == 0) {
            hostEndpoint = endpoint;
        }
        mConnectedEndPoints.put(endpoint.getEndPointId(), endpoint);
        NearbyConnectionEvent nearbyConnectionEvent = new NearbyConnectionEvent
                (NearbyConnectionEvent.ConnectionType.CONNECTED, endpoint);

        EventBus.getDefault().post(nearbyConnectionEvent);

        Log.d(TAG, "connectedToEndpoint: " + GameDataHelper.getUserInfo().getImagePath());
        startSendingImage(endpoint, null, GameDataHelper.getUserInfo().getImagePath());
    }

    public void startSendingImage(String endPointId, EndPoint imageOwner, String imagePath) {
        if (mConnectedEndPoints.containsKey(endPointId)) {
            startSendingImage(mConnectedEndPoints.get(endPointId), imageOwner, imagePath);
        }
    }

    public void startSendingImage(EndPoint destinationEndpoint, EndPoint imageOwner, String imagePath) {
        try {
            Log.d(TAG, "startSending Image of " + ((imageOwner == null) ? "Self" : imageOwner.getEndPointName()) +
                    " path: " + imagePath +
                    " To: " + destinationEndpoint.getEndPointName());

            Payload filePayload = Payload.fromFile(new File(imagePath));

            //imagefileNameformat--> payloadId:imageOwnerEndpointId:imageName
            String payloadFilenameMessage;

            if (imageOwner == null)
                payloadFilenameMessage = filePayload.getId() + ":"
                        + imagePath.substring(imagePath.lastIndexOf("/") + 1);
            else
                payloadFilenameMessage = filePayload.getId() + ":" + imageOwner.getEndPointId() + ":"
                        + imagePath.substring(imagePath.lastIndexOf("/") + 1);

            Log.d(TAG, "payloadFilenameMessage: " + payloadFilenameMessage);
            GameMessages.ImageFilenamePacket imageFilenamePacket = GameMessages.ImageFilenamePacket.newBuilder()
                    .setImageName(payloadFilenameMessage)
                    .build();
            GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                    .setImageFilename(imageFilenamePacket)
                    .setPacketType(GameMessages.PacketType.USER_DATA)
                    .build();

            Payload filenamePayload = Payload.fromBytes(dataPacket.toByteArray());
            send(filenamePayload, destinationEndpoint);
            send(filePayload, destinationEndpoint);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    /**
     * disconnected to endpoint
     * send update to app layer via EventBus
     *
     * @param endPoint
     */
    private void disconnectedFromEndpoint(EndPoint endPoint) {
        Log.e(TAG, String.format("disconnectedFromEndpoint(endpoint=%s)", endPoint));
        mConnectedEndPoints.remove(endPoint.getEndPointId());
        NearbyConnectionEvent nearbyConnectionEvent = new NearbyConnectionEvent
                (NearbyConnectionEvent.ConnectionType.DISCONNECTED, endPoint);
        EventBus.getDefault().post(nearbyConnectionEvent);
    }

    public void onConnectionFailed(EndPoint endpoint) {

    }

    /**
     * callbacks for all the connection related events like(initiate, success, fail)
     */
    private final ConnectionLifecycleCallback mConnectionLifecycleCallback = new ConnectionLifecycleCallback() {
        @Override
        public void onConnectionInitiated(String endPointId, ConnectionInfo connectionInfo) {
            Log.d(TAG, "onConnectionInitiated: from " + endPointId + " " + connectionInfo.getEndpointName());
            EndPoint endPoint = EndPoint.newBuilder().setEndPointId(endPointId)
                    .setEndPointName(connectionInfo.getEndpointName())
                    .build();
            onNearbyConnectionInitiated(endPoint, connectionInfo);
        }


        @Override
        public void onConnectionResult(String endPointId, ConnectionResolution connectionResolution) {
            EndPoint endpoint = mPendingConnections.remove(endPointId);
            if (endpoint != null) {
                if (connectionResolution.getStatus().isSuccess()) {
                    connectedToEndpoint(endpoint);
                } else {
                    onConnectionFailed(endpoint);
                    return;
                }
            }
        }

        @Override
        public void onDisconnected(String endPointId) {
            Log.e(TAG, "onDisconnected: " + endPointId);
            if (!mConnectedEndPoints.containsKey(endPointId)) {
                Log.e(TAG, "Unexpected disconnection from endpoint " + endPointId);
                return;
            }
            disconnectedFromEndpoint(mConnectedEndPoints.get(endPointId));
        }
    };

    /**
     * Called when a pending connection with a remote endpoint is created. Use {@link ConnectionInfo}
     * for metadata about the connection (like incoming vs outgoing, or the authentication token).
     * by default we accept all the connection request
     */
    private void onNearbyConnectionInitiated(EndPoint endpoint, ConnectionInfo connectionInfo) {
        mPendingConnections.put(endpoint.getEndPointId(), endpoint);
        mConnectionsClient.acceptConnection(endpoint.getEndPointId()
                , payloadCallback)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.e(TAG, "onFailure: acceptConnection");
                        e.printStackTrace();
                    }
                });
    }

    /**
     * method to send request connection to discovered endpoint.
     *
     * @param endPointId
     * @param discoveredEndpointInfo
     */
    private void requestConnection(String endPointId, DiscoveredEndpointInfo discoveredEndpointInfo) {

        if (mPendingConnections.containsKey(endPointId) || mConnectedEndPoints.containsKey(endPointId)) {
            Log.e(TAG, "onEndpointFound: return this end point already has connection");
            return;
        }
        stopDiscovery();
        if (getServiceId().equals(discoveredEndpointInfo.getServiceId())) {
            EndPoint endPoint = EndPoint.newBuilder()
                    .setEndPointId(endPointId)
                    .setEndPointName(discoveredEndpointInfo.getEndpointName())
                    .build();
            disCoveredEndPoints.put(endPointId, endPoint);
            mConnectionsClient.requestConnection(getSelfName()
                    , endPointId
                    , mConnectionLifecycleCallback
            ).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.d(TAG, "onSuccess: request connection");
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "run: after onsuccess!");
                            startDiscovery();
                        }
                    }, 2000);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.e(TAG, "onFailure: request connection");
                    e.printStackTrace();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "run: after onFailure!");
                            startDiscovery();
                        }
                    }, 2000);

                }
            });
        }
    }


    /**
     * callback for endPoint discovered or endPoint lost to discoverer end
     */
    private final EndpointDiscoveryCallback mEndpointDiscoveryCallback = new EndpointDiscoveryCallback() {
        @Override
        public void onEndpointFound(String endPointId, DiscoveredEndpointInfo discoveredEndpointInfo) {
            Log.d(TAG, "onEndpointFound: " + endPointId);
            requestConnection(endPointId, discoveredEndpointInfo);
        }

        @Override
        public void onEndpointLost(String endPointId) {
            Log.d(TAG, "onEndpointLost: " + endPointId);
            disCoveredEndPoints.remove(endPointId);
        }
    };

    /**
     * method to get profile name
     *
     * @return profile name set in the welcome screen
     */
    private String getSelfName() {
        return GameDataHelper.getUserInfo().getName();
    }

    /**
     * @return serviceId (we are using packagename)
     */
    public String getServiceId() {
        return AndroidUtil.getApplicationId(LudoSixApp.getContext()) + mNetworkName;
//        return "LudoTestNetwork" + mNetworkName;
    }

    public void setNetworkName(String mNetworkName) {
        this.mNetworkName = mNetworkName;
    }

    public String getNetworkName() {
        return mNetworkName;
    }

    /**
     * Sets the device to advertising mode. It will broadcast to other devices in discovery mode.
     * Either {@link #onAdvertisingStarted()} or {@link #onAdvertisingFailed()} will be called once
     * we've found out if we successfully entered this mode.
     */
    private void startAdvertising() {
        Log.d(TAG, "startAdvertising: ");
        final String localEndpointName = getSelfName();
        if (mConnectionsClient != null && !isAdvertising) {
            isAdvertising = true;
            mConnectionsClient.startAdvertising(
                    localEndpointName,
                    getServiceId(),
                    mConnectionLifecycleCallback,
                    new AdvertisingOptions.Builder().setStrategy(STRATEGY).build())
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "onSuccess: advertising!");
                            onAdvertisingStarted();

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            e.printStackTrace();
                        }
                    });
        }
    }

    private void onAdvertisingStarted() {

    }

    private void onAdvertisingFailed() {

    }


    private void stopAdvertising() {
        Log.d(TAG, "stopAdvertising: ");
        if (mConnectionsClient != null && isAdvertising) {
            mConnectionsClient.stopAdvertising();
            isAdvertising = false;
        }
    }

    protected void onDiscoveryStarted() {

    }

    protected void onDiscoveryFailed() {

    }

    /**
     * Sets the device to discovery mode. It will now listen for devices in advertising mode. Either
     * {@link #onDiscoveryStarted()} or {@link #onDiscoveryFailed()} will be called once we've found
     * out if we successfully entered this mode.
     */
    private void startDiscovery() {
        Log.d(TAG, "startDiscovery: ");
        if (mConnectionsClient != null && !isDiscoverying) {
            isDiscoverying = true;
            mConnectionsClient.startDiscovery(getServiceId(),
                    mEndpointDiscoveryCallback,
                    new DiscoveryOptions.Builder().setStrategy(STRATEGY).build())
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "onSuccess: Discovery");
                            onDiscoveryStarted();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            e.printStackTrace();
                            onDiscoveryFailed();
                        }
                    });
        }

    }

    /**
     * Stop the device from being in discovery mode
     */
    private void stopDiscovery() {
        Log.e(TAG, "stopDiscovery: ");
        if (mConnectionsClient != null && isDiscoverying) {
            mConnectionsClient.stopDiscovery();
            isDiscoverying = false;
        }

    }

    /**
     * Disconnects from all currently connected endpoints.
     */
    protected void disconnectFromAllEndpoints() {
        for (EndPoint endpoint : mConnectedEndPoints.values()) {
            mConnectionsClient.disconnectFromEndpoint(endpoint.getEndPointId());
        }
        mConnectedEndPoints.clear();
    }

    /**
     * Resets and clears all state in Nearby Connections.
     */
    public void stopAllEndpoints() {

        disCoveredEndPoints.clear();
        mPendingConnections.clear();
        mConnectedEndPoints.clear();
        stopAdvertising();
        stopDiscovery();
        mConnectionsClient.stopAllEndpoints();
    }

}
