package com.w3engineers.theme.ludosix.ui.snakes_game.snakes;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.util.helper.ToneFactory;

/**
 * Token class
 * This class contains the pieces of the game (4 re, 4 blue, 4 green, and 4 yellow)
 * as well as the hardcoded paths that the tokens can take along the board. This class also
 * determines if a piece can move or not, and its initial positions at the start of the game
 */

public class Token {

    //instance variables
    private int numSpacesMoved;
    private int owner;
    private boolean isMovable;
    private boolean isHome;
    private boolean shouldHighlight = false;
    private float basePath[][];
    private float path[][];
    private int index;

    /**
     * constructor
     * The constructor defines the hardcoded paths for each piece.
     */
    public Token(int ownsMe) {
        isMovable = false;
        isHome = true;
        owner = ownsMe;

        basePath = new float[][]{
                {0, 9}, {1, 9}, {2, 9}, {3, 9}, {4, 9}, {5, 9}, {6, 9}, {7, 9}, {8, 9}, {9, 9},
                {9, 8}, {8, 8}, {7, 8}, {6, 8}, {5, 8}, {4, 8}, {3, 8}, {2, 8}, {1, 8}, {0, 8},
                {0, 7}, {1, 7}, {2, 7}, {3, 7}, {4, 7}, {5, 7}, {6, 7}, {7, 7}, {8, 7}, {9, 7},
                {9, 6}, {8, 6}, {7, 6}, {6, 6}, {5, 6}, {4, 6}, {3, 6}, {2, 6}, {1, 6}, {0, 6},
                {0, 5}, {1, 5}, {2, 5}, {3, 5}, {4, 5}, {5, 5}, {6, 5}, {7, 5}, {8, 5}, {9, 5},
                {9, 4}, {8, 4}, {7, 4}, {6, 4}, {5, 4}, {4, 4}, {3, 4}, {2, 4}, {1, 4}, {0, 4},
                {0, 3}, {1, 3}, {2, 3}, {3, 3}, {4, 3}, {5, 3}, {6, 3}, {7, 3}, {8, 3}, {9, 3},
                {9, 2}, {8, 2}, {7, 2}, {6, 2}, {5, 2}, {4, 2}, {3, 2}, {2, 2}, {1, 2}, {0, 2},
                {0, 1}, {1, 1}, {2, 1}, {3, 1}, {4, 1}, {5, 1}, {6, 1}, {7, 1}, {8, 1}, {9, 1},
                {9, 0}, {8, 0}, {7, 0}, {6, 0}, {5, 0}, {4, 0}, {3, 0}, {2, 0}, {1, 0}, {0, 0}
        };

        setBasePath(0);
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    /**
     * copy constructor
     *
     * @param original
     */
    public Token(Token original) {
        this.numSpacesMoved = original.numSpacesMoved;
        this.isMovable = original.isMovable;
        this.isHome = original.isHome;
        this.owner = original.owner;
        this.path = original.path;
    }

    public float getCurrentXLoc() {
        return this.path[this.numSpacesMoved][0];
    }

    public float getCurrentYLoc() {
        return this.path[this.numSpacesMoved][1];
    }

    public int getNumSpacesMoved() {
        return numSpacesMoved;
    }

    public void incNumSpacesMoved(int numDiceVal) {
        if (!shouldHighlight) {
            this.numSpacesMoved = numDiceVal + this.numSpacesMoved;
        }
    }

    public void setNumSpacesMoved(int val, boolean isSnakeCut) {
        this.numSpacesMoved = val;
        ToneFactory.on().play(isSnakeCut ? R.raw.snake_cut : R.raw.ladder_climb);
    }

    public boolean getIsMovable() {
        return isMovable;
    }

    public boolean isShouldHighlight() {
        return shouldHighlight;
    }

    public void setShouldHighlight(boolean shouldHighlight) {
        this.shouldHighlight = shouldHighlight;
    }

    public void setIsMovable(boolean movable) {
        isMovable = movable;
    }

    public boolean getIsHome() {
        return isHome;
    }

    public void setIsHome(boolean home) {
        isHome = home;
    }

    public int getOwner() {
        return owner;
    }

    public void setPath(float[][] path) {
        this.numSpacesMoved = 0;
        this.path = path;
    }

    public int getPathLength() {
        return path.length;
    }

    public void setBasePath(int numSpacesMoved) {
        this.numSpacesMoved = numSpacesMoved;
        this.path = basePath;
    }
}
