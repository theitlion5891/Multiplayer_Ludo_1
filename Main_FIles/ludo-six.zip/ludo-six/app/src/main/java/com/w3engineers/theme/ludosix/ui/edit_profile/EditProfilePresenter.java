package com.w3engineers.theme.ludosix.ui.edit_profile;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.data.local.model.UserInfo;
import com.w3engineers.theme.ludosix.ui.base.BasePresenter;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/9/2018 at 12:21 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Presenter class
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 11/9/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 11/9/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class EditProfilePresenter extends BasePresenter<EditProfileMvpView> {

    public void editInfo(UserInfo userInfo) {
        if (getMvpView() != null)
            getMvpView().onInfoEdited(GameDataHelper.saveUserInfo(userInfo));  // Updating user info in shared pref
    }

    public void validateUserInfo(UserInfo userInfo) {
        String message = "";

        if (userInfo.getName().isEmpty()) {
            message = getActivity().getString(R.string.empty_name);
        }

        if (getMvpView() != null)
            getMvpView().onUserInfoValidated(message, userInfo);
    }
}
