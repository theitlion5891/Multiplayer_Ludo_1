package com.w3engineers.theme.util.lib.nearby;

/**
 * Created by pl@b0n on 11/22/2018.
 */
public enum InvitationPacketType {
    INVITE,
    ACCEPT,
    DECLINE,
    REMOVED,
    UPDATE_ACCEPT,
    MESH_PLAYER_INFO,
    PLAYER_DISCONNECTED,
    PLAYER_REMOVED,
    GAME_START,
    READY_TO_PLAY,
    READY_TO_PLAY_ACK,
}
