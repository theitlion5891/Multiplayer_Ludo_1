package com.w3engineers.theme.ludosix.ui.game_info;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.View;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.databinding.ActivityGameInfoBinding;
import com.w3engineers.theme.ludosix.ui.base.BaseActivity;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 12/28/2018 at 11:03 AM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: This activity shows all relevant game info's like rules, privacy and about
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 12/28/2018
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 12/28/2018
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class GameInfoActivity extends BaseActivity<GameInfoMvpView, GameInfoPresenter> implements GameInfoMvpView {

    public enum InfoType {ABOUT, TERMS}

    private ActivityGameInfoBinding mBinding;
    private static final String EXTRA_TYPE = "EXTRA_TYPE";
    private InfoType type;

    /**
     * Start Activity (Pass value as a 2nd Parameter)
     * Date: 2018-03-13
     * Added By: Sudipta K Paik
     *
     * @param context
     **/
    public static void runActivity(Context context, InfoType infoType) {
        Intent intent = new Intent(context, GameInfoActivity.class);
        intent.putExtra(EXTRA_TYPE, infoType);
        runCurrentActivity(context, intent);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_game_info;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = (ActivityGameInfoBinding) getViewDataBinding();

        mBinding.activityGameInfoBackBtn.setOnClickListener(view -> onBackPressed());
        type = (InfoType) getIntent().getSerializableExtra(EXTRA_TYPE);

        switch (type) {

            case ABOUT:
                mBinding.activityGameInfoLogoIv.setVisibility(View.VISIBLE);
                mBinding.activityGameInfoTitleTv.setText(getString(R.string.about));
                setHtmlText(R.string.about_text);
                break;

            case TERMS:
                mBinding.activityGameInfoTitleTv.setText(getString(R.string.privacy_and_terms));
                setHtmlText(R.string.terms_text);
                break;
        }
    }

    private void setHtmlText(int stringResId) {
        // Showing rules html string
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            mBinding.activityGameInfoBodyText.setText(Html.fromHtml(getString(stringResId), Html.FROM_HTML_MODE_LEGACY));
        } else {
            mBinding.activityGameInfoBodyText.setText(Html.fromHtml(getString(stringResId)));
        }
    }

    @Override
    protected void startUI() {

    }

    @Override
    protected void stopUI() {

    }

    @Override
    protected GameInfoPresenter initPresenter() {
        return new GameInfoPresenter();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.right_in, R.anim.right_out);
    }
}
