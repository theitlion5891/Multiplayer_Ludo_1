package com.w3engineers.theme.util.lib.internet.enumkeys;

public enum InternetGameDataType {
    GAME_INFO,
    GAME_ACTION
}
