package com.w3engineers.theme.ludosix.data.remote.thundercharmapi;

import android.content.Context;

import com.w3engineers.theme.ludosix.data.remote.helper.models.ChatMessage;

/**
 * * ============================================================================
 * * Copyright (C) 2018 W3 Engineers Ltd - All Rights Reserved.
 * * Unauthorized copying of this file, via any medium is strictly prohibited
 * * Proprietary and confidential
 * * ----------------------------------------------------------------------------
 * * Created by: Sudipta K Paik on [16-Jul-2018 at 10:55 AM].
 * * Email: sudipta@w3engineers.com
 * * ----------------------------------------------------------------------------
 * * Project: Generic API.
 * * Code Responsibility: <Purpose of code>
 * * ----------------------------------------------------------------------------
 * * Edited by :
 * * --> <First Editor> on [16-Jul-2018 at 10:55 AM].
 * * --> <Second Editor> on [16-Jul-2018 at 10:55 AM].
 * * ----------------------------------------------------------------------------
 * * Reviewed by :
 * * --> <First Reviewer> on [16-Jul-2018 at 10:55 AM].
 * * --> <Second Reviewer> on [16-Jul-2018 at 10:55 AM].
 * * ============================================================================
 **/

public class TCharmManager {
    private static volatile TCharmManager ourInstance;
    private static Object mutex = new Object();

    private TCharmManager() {
    }

    public synchronized static void init(Context context) {
        synchronized (mutex) {
            if (ourInstance == null)
                ourInstance = new TCharmManager();
        }
    }

    public static TCharmManager on() {
        return ourInstance;
    }

    public void sendMessage(String toUser, ChatMessage chatMessage) {

    }
}
