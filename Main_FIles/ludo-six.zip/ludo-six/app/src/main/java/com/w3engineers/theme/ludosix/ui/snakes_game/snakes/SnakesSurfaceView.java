package com.w3engineers.theme.ludosix.ui.snakes_game.snakes;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.SparseArray;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.util.FlashSurfaceView;

import static com.w3engineers.theme.util.helper.ViewUtils.dpToPx;

/**
 * LudoSurfaceView
 * This draws the entire board, all the pieces, and the dice.
 * It also updates the board according to touch events and button presses * *
 */

public class SnakesSurfaceView extends FlashSurfaceView {

    //instance variables
    protected SnakesState mState = new SnakesState(new ArrayList<>());
    private boolean[] mIsDrawn;

    //Creating Color Objects
    private Paint greenPaint = new Paint();
    private Paint redPaint = new Paint();
    private Paint bluePaint = new Paint();
    private Paint yellowPaint = new Paint();

    private Paint whitePaint = new Paint();
    private Paint blackStrokePaint = new Paint();
    private Paint countPaint = new Paint();

    private List<Paint> paints = new ArrayList<>();
    private List<Integer> mBoardPaint = new ArrayList<>();
    private Random random = new Random();
    private float count;

    private static SparseArray<Bitmap> resourceMap = new SparseArray<>();

    /**
     * Constructors
     */
    public SnakesSurfaceView(Context context) {
        super(context);
        setWillNotDraw(false);
    }

    public SnakesSurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);
    }

    public void setState(SnakesState mState) {
        this.mState = mState;
    }

    private Bitmap createResMap(int resId) {
        resourceMap.put(resId, BitmapFactory.decodeResource(getResources(), resId));
        return resourceMap.get(resId);
    }

    private Bitmap getBitmapFromResMap(int resId) {
        return resourceMap.get(resId) != null ? resourceMap.get(resId) : createResMap(resId);
    }

    /**
     * onDraw
     * the starting place for all drawing that takes place
     * implements the use of helper methods.
     *
     * @param canvas - draw on this
     */
    @Override
    public void onDraw(Canvas canvas) {

        //define the canvas instance variables
        float heightAndWidth = getWidth();//height and width are the same because the surface view is a square
        float box = heightAndWidth / 10;

        //Creating the colors
        redPaint.setColor(Color.rgb(255, 0, 0));
        greenPaint.setColor(Color.rgb(0, 167, 80));
        bluePaint.setColor(Color.rgb(0, 191, 255));
        yellowPaint.setColor(Color.rgb(254, 238, 3));
        whitePaint.setColor(Color.WHITE);

        paints.add(redPaint);
        paints.add(greenPaint);
        paints.add(bluePaint);
        paints.add(yellowPaint);
        paints.add(whitePaint);

        blackStrokePaint.setColor(Color.BLACK);
        blackStrokePaint.setStyle(Paint.Style.STROKE);
        blackStrokePaint.setStrokeWidth(3);

        countPaint.setTextSize(dpToPx(13));
        countPaint.setFakeBoldText(true);
        countPaint.setColor(Color.BLACK);
        countPaint.setStyle(Paint.Style.FILL);

        if (mState.getPlayerList().size() == 0) {
            for (int i = 0; i < 100; i++) {
                mBoardPaint.add(random.nextInt(paints.size()));
            }
        }

        int index;

        //Drawing all tiles
        for (float i = 0, p = 0; i < box * 10 && p < 10; i = i + box, p++) {
            index = (int) p * 10;

            for (float j = 0, q = 0; j < box * 10 && q < 10; j = j + box, q++) {
                canvas.drawRect(i, j, i + box, j + box, paints.get(mBoardPaint.get(index + (int) q)));
                canvas.drawRect(i, j, i + box, j + box, blackStrokePaint);
            }
        }

        // Drawing ladders
        drawImageBitmap(canvas, box * 3, box * 8, box * 4, box * 2,
                getBitmapFromResMap(R.drawable.ic_ladder3)); // From tile 4-14

        drawImageBitmap(canvas, box * 8, box * 6, box * 2, box * 4,
                getBitmapFromResMap(R.drawable.ic_ladder4)); // From tile 9-31

        drawImageBitmap(canvas, 0, box * 6, box * 3, box * 3,
                getBitmapFromResMap(R.drawable.ic_ladder1)); // From tile 20-38

        drawImageBitmap(canvas, 0, box * 4, box * 2, box * 3,
                getBitmapFromResMap(R.drawable.ic_ladder5)); // From tile 40-59

        drawImageBitmap(canvas, 0, box, box * 3, box * 3,
                getBitmapFromResMap(R.drawable.ic_ladder7)); // From tile 63-81

        drawImageBitmap(canvas, box * 9, 0, box, box * 3,
                getBitmapFromResMap(R.drawable.ic_ladder6)); // From tile 71-91

        drawImageBitmap(canvas, box * 3, box, box * 5, box * 7,
                getBitmapFromResMap(R.drawable.ic_ladder2)); // From tile 28-84

        // Drawing snakes
        drawImageBitmap(canvas, box * 3, box * 8, box * 4, box * 2,
                getBitmapFromResMap(R.drawable.ic_snake1)); // From tile 17-7

        drawImageBitmap(canvas, box, 0, box * 3, box * 3,
                getBitmapFromResMap(R.drawable.ic_snake5)); // From tile 99-78

        drawImageBitmap(canvas, box * 7, 0, box * 2, box * 3,
                getBitmapFromResMap(R.drawable.ic_snake6)); // From tile 93-73

        drawImageBitmap(canvas, 0, box * 3, box * 4, box * 2,
                getBitmapFromResMap(R.drawable.ic_snake4)); // From tile 64-60

        drawImageBitmap(canvas, box, box * 3, box * 2, box * 6,
                getBitmapFromResMap(R.drawable.ic_snake2)); // From tile 62-18

        drawImageBitmap(canvas, box * 6, box * 4, box * 2, box * 3,
                getBitmapFromResMap(R.drawable.ic_snake3)); // From tile 54-34

        drawImageBitmap(canvas, box * 3, box, box * 4, box * 7,
                getBitmapFromResMap(R.drawable.ic_snake8)); // From tile 87-24

        drawImageBitmap(canvas, box * 4, 0, box * 2, box * 3,
                getBitmapFromResMap(R.drawable.ic_snake7)); // From tile 95-75

        //Drawing all numbers
        for (float i = 0, p = 0; i < box * 10 && p < 10; i = i + box, p++) {
            for (float j = 0, q = 0; j < box * 10 && q < 10; j = j + box, q++) {

                if (q == 0) {
                    count = 100 - p;

                } else if (q % 2 == 0) {
                    count = count - (1 + (2 * p));

                } else {
                    count = count - (19 - (2 * p));
                }

                if (Math.round(count) == 1) {
                    canvas.drawText("Start", i + (box / 11), j + (3 * (box / 6)), countPaint);
                    canvas.drawText(String.valueOf(Math.round(count)), i + (box / 3), j + (5 * (box / 6)), countPaint);

                } else if (Math.round(count) == 100) {
                    canvas.drawText("End", i + (box / 7), j + (3 * (box / 6)), countPaint);
                    canvas.drawText(String.valueOf(Math.round(count)), i + (box / 6), j + (5 * (box / 6)), countPaint);

                } else {
                    canvas.drawText(String.valueOf(Math.round(count)), i + (box / 4), j + (2 * (box / 3)), countPaint);
                }
            }
        }

        drawPieces(canvas, box);
    }

    private Paint getPaintBasedOnPlayer(int homePos) {

        if (mState.getPlayerList().size() > 1) {
            Player player = getPlayerBasedOnPosition(homePos);

            if (player != null) {
                return getPaintFromColor(player.getPlayerColor());
            }
        }

        return redPaint;
    }

    private Player getPlayerBasedOnPosition(int pos) {
        for (Player player : mState.getPlayerList()) {

            if (player.getPlayerPosition() == pos) {
                return player;
            }
        }

        return null;
    }

    private Paint getPaintFromColor(int color) {

        switch (color) {
            case Color.RED:
                return redPaint;

            case Color.BLUE:
                return bluePaint;

            case Color.YELLOW:
                return yellowPaint;

            case Color.GREEN:
                return greenPaint;

            default:
                return greenPaint;
        }
    }

    private int getPieceDrawableFromColor(int color) {

        if (color == greenPaint.getColor()) {
            return R.drawable.ic_piece_green;

        } else if (color == bluePaint.getColor()) {
            return R.drawable.ic_piece_blue;

        } else if (color == yellowPaint.getColor()) {
            return R.drawable.ic_piece_yellow;

        } else {
            return R.drawable.ic_piece_red;
        }
    }

    /**
     * drawPieces
     * this draws the pieces. They are moved according to touch events etc.
     *
     * @param canvas Canvas objects
     * @param box    This is the width of the board divided by 15. This is used to scale everything
     *               according to the screens dimensions
     */
    private void drawPieces(Canvas canvas, float box) {
        //initialize the isdrawn array to false
        mIsDrawn = new boolean[4];
        Arrays.fill(mIsDrawn, false);

        for (int i = 0; i < mState.getPlayerList().size(); i++) {
            int index = mState.getPlayerList().get(i).getPlayerPosition();
            drawPiece(index, canvas, box);
        }
    }

    private void drawPiece(int i, Canvas canvas, float box) {
        float xPos, yPos;

        if (!mIsDrawn[i] && !mState.pieces[i].getIsHome()) {//only draw the pieces that haven't been drawn yet
            xPos = mState.pieces[i].getCurrentXLoc();
            yPos = mState.pieces[i].getCurrentYLoc();
            checkOverlap(mState.pieces[i], i, (box * xPos), (box * yPos), box, canvas, getPieceDrawableFromColor(getPaintBasedOnPlayer(i).getColor()));
        }
    }

    //Draws the pieces entirely and ensures that all pieces can be seen even if another piece lands
    //on the same spot.
    public void checkOverlap(Token piece, int currentIndex, float xPos, float yPos, float box, Canvas canvas, int resId) {

        //initialize local instance variables
        boolean overlapHappened = false;
        List<Integer> overlapPieceIndexies = new ArrayList<>();
        ArrayList<Integer> resIds = new ArrayList<>();
        overlapPieceIndexies.add(currentIndex);
        resIds.add(resId);

        //store the indexies and the paints of the pieces that overlap
        for (int i = 0; i < mState.getNumPlayers(); i++) {
            int index = mState.getPlayerList().get(i).getPlayerPosition();

            if (!mState.pieces[index].getIsHome() && index != currentIndex &&
                    (piece.getCurrentXLoc() == mState.pieces[index].getCurrentXLoc()) &&
                    (piece.getCurrentYLoc() == mState.pieces[index].getCurrentYLoc())) {
                //overlap found!!
                overlapHappened = true;
                overlapPieceIndexies.add(index);
                resIds.add(getPieceDrawableFromColor(getPaintBasedOnPlayer(index).getColor()));
            }
        }

        if (overlapHappened) {
            drawOverlapPieces(canvas, box, xPos, yPos, overlapPieceIndexies, resIds);

        } else {
            drawImageBitmap(canvas, xPos, yPos, box, box, getBitmapFromResMap(resId));
        }
    }

    private void drawImageBitmap(Canvas canvas, float xPos, float yPos, float imageWidth, float imageHeight, Bitmap bitmap) {
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, Math.round(imageWidth), Math.round(imageHeight), false);
        canvas.drawBitmap(resizedBitmap, xPos, yPos, null);
    }

    private void drawOverlapPieceBitmap(Canvas canvas, int resId, float x, float y, float resWidth, float resHeight) {
        drawImageBitmap(canvas, x, y, resWidth, resHeight, getBitmapFromResMap(resId));
    }

    public void drawOverlapPieces(Canvas canvas, float box, float xPos, float yPos, List<Integer> indexes, ArrayList<Integer> resIds) {

        switch (indexes.size()) {
            case 2: //draw two overlapping pieces
                // Two overlapping pieces
                drawOverlapPieceBitmap(canvas, resIds.get(0), xPos - (box / 12), yPos, (float) (box / 1.2), (float) (box / 1.2));
                drawOverlapPieceBitmap(canvas, resIds.get(1), (float) (xPos + (box / 3.8)), (float) (yPos + (box / 4.5)), (float) (box / 1.2), (float) (box / 1.2));

                //set the two pieces to true
                this.mIsDrawn[indexes.get(0)] = true;
                this.mIsDrawn[indexes.get(1)] = true;
                break;

            case 3: //draw three overlapping pieces
                // Three overlapping pieces
                drawOverlapPieceBitmap(canvas, resIds.get(0), xPos + (box / 6), yPos, (float) (box / 1.45), (float) (box / 1.45));
                drawOverlapPieceBitmap(canvas, resIds.get(1), (float) (xPos + (box / 2.5)), (float) (yPos + (box / 3.2)), (float) (box / 1.45), (float) (box / 1.45));
                drawOverlapPieceBitmap(canvas, resIds.get(2), xPos - (box / 12), (float) (yPos + (box / 3.2)), (float) (box / 1.45), (float) (box / 1.45));

                //set the two pieces to true
                this.mIsDrawn[indexes.get(0)] = true;
                this.mIsDrawn[indexes.get(1)] = true;
                this.mIsDrawn[indexes.get(2)] = true;
                break;

            case 4: //draw four overlapping pieces
                // Four overlapping pieces
                drawOverlapPieceBitmap(canvas, resIds.get(0), xPos - (box / 12), yPos, (float) (box / 1.5), (float) (box / 1.5));
                drawOverlapPieceBitmap(canvas, resIds.get(1), (float) (xPos + (box / 2.5)), yPos, (float) (box / 1.5), (float) (box / 1.5));
                drawOverlapPieceBitmap(canvas, resIds.get(2), xPos - (box / 12), (float) (yPos + (box / 2.8)), (float) (box / 1.5), (float) (box / 1.5));
                drawOverlapPieceBitmap(canvas, resIds.get(3), (float) (xPos + (box / 2.5)), (float) (yPos + (box / 2.8)), (float) (box / 1.5), (float) (box / 1.5));

                //set the two pieces to true
                this.mIsDrawn[indexes.get(0)] = true;
                this.mIsDrawn[indexes.get(1)] = true;
                this.mIsDrawn[indexes.get(2)] = true;
                this.mIsDrawn[indexes.get(3)] = true;
                break;
        }
    }
}

