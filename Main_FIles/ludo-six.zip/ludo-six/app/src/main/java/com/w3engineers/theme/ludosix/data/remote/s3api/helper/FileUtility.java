package com.w3engineers.theme.ludosix.data.remote.s3api.helper;

/*
 *  ****************************************************************************
 *  * Created by : Ahmed Mohmmad Ullah (Azim) on 5/4/2018 at 11:51 AM.
 *  * Email : azim@w3engineers.com
 *  *
 *  * Last edited by : Ahmed Mohmmad Ullah (Azim) on 5/4/2018.
 *  * Last edited by : Sudipta K Paik on 05/29/2018.
 *  * Last edited by : Sudipta K Paik on 06/01/2018.
 *  *
 *  * Last Reviewed by : <Reviewer Name> on <mm/dd/yy>
 *  ****************************************************************************
 */

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.webkit.MimeTypeMap;

import java.io.File;

public class FileUtility {

    public static String getFileNameFromFullPath(String fullFilePath) {
        if (TextUtils.isEmpty(fullFilePath)) {
            return null;
        }
        return fullFilePath.substring(fullFilePath.lastIndexOf("/") + 1);
    }

    /**
     * Use this method when you directly collect
     * the file info from the file full path Uri.
     *
     * @param fullFilePath full file path as Uri
     * @return the FileInfo object with full data
     */
    public static FileInfo getFileInfoFromUri(Uri fullFilePath) {
        if (fullFilePath == null) {
            return null;
        }

        File file = new File(fullFilePath.getPath());

        FileInfo fileInfo = null;

        if (file.exists()) {
            fileInfo = new FileInfo();
            fileInfo.name = file.getName();
            fileInfo.size = file.length();
            fileInfo.fileUri = fullFilePath;
            fileInfo.filePath = file.getAbsolutePath();
        }

        return fileInfo;
    }

    /**
     * Use this method when you collect
     * the file info from the file full path Uri
     * and ContentResolver.
     *
     * @param contentResolver current ContentResolver
     * @param fullFilePath    full file path as Uri
     * @return the FileInfo object with full data
     */
    public static FileInfo getFileInfoFromUri(ContentResolver contentResolver, Uri fullFilePath) {
        if (fullFilePath == null || contentResolver == null) {
            return null;
        }
        String[] filePathColumn = {OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE, MediaStore.Images.Media.DATA};
        Cursor returnCursor = contentResolver.query(fullFilePath, filePathColumn, null, null, null);
        if (returnCursor == null)
            return null;

        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        int sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE);
        int filePathIndex = returnCursor.getColumnIndex(MediaStore.Images.Media.DATA);
        FileInfo fileInfo = null;

        if (returnCursor.moveToFirst()) {

            fileInfo = new FileInfo();
            String name = returnCursor.getString(nameIndex);
            String path = returnCursor.getString(filePathIndex);
            long size = returnCursor.getLong(sizeIndex);
            fileInfo.name = name;
            fileInfo.size = size;
            fileInfo.fileUri = fullFilePath;
            fileInfo.filePath = path;

        }
        returnCursor.close();
        return fileInfo;
    }

    /**
     * Use this method when you get Mime type
     *
     * @param context Context
     * @param uri     Uri
     * @return the mime type as String
     */
    public static String getMimeType(Context context, Uri uri) {

        if (context == null || uri == null) return null;
        String extension;

    if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {

        final MimeTypeMap mime = MimeTypeMap.getSingleton();
        extension = mime.getExtensionFromMimeType(context.getContentResolver().getType(uri));
    } else {

        extension = MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(new File(uri.getPath())).toString());

    }

    return extension;

}}
