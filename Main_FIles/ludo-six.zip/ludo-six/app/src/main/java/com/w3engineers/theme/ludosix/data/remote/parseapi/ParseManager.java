package com.w3engineers.theme.ludosix.data.remote.parseapi;

import android.content.Context;

import com.parse.LogInCallback;
import com.parse.Parse;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

import com.w3engineers.theme.ludosix.data.remote.helper.callback.AuthSignInCallback;
import com.w3engineers.theme.ludosix.data.remote.helper.callback.AuthSignUpCallback;
import com.w3engineers.theme.ludosix.data.remote.helper.callback.UserCallback;
import com.w3engineers.theme.ludosix.data.remote.helper.models.RemoteObject;
import com.w3engineers.theme.ludosix.data.remote.helper.models.UserModel;

/**
 * * ============================================================================
 * * Copyright (C) 2018 W3 Engineers Ltd - All Rights Reserved.
 * * Unauthorized copying of this file, via any medium is strictly prohibited
 * * Proprietary and confidential
 * * ----------------------------------------------------------------------------
 * * Created by: Sudipta K Paik on [13-Jul-2018 at 12:49 PM].
 * * Email: sudipta@w3engineers.com
 * * ----------------------------------------------------------------------------
 * * Project: Generic API.
 * * Code Responsibility: <Purpose of code>
 * * ----------------------------------------------------------------------------
 * * Edited by :
 * * --> <First Editor> on [13-Jul-2018 at 12:49 PM].
 * * --> <Second Editor> on [13-Jul-2018 at 12:49 PM].
 * * ----------------------------------------------------------------------------
 * * Reviewed by :
 * * --> <First Reviewer> on [13-Jul-2018 at 12:49 PM].
 * * --> <Second Reviewer> on [13-Jul-2018 at 12:49 PM].
 * * ============================================================================
 **/

public class ParseManager   {

    private static volatile ParseManager ourInstance;
    private static Object mutex = new Object();

    private ParseManager() {

    }

    public synchronized static void init(Context context, String serverUrl, String appId, String clientKey) {
        synchronized (mutex) {
            if (ourInstance == null)
                ourInstance = new ParseManager();
        }

        Parse.initialize(new Parse.Configuration.Builder(context)
                .applicationId(appId)
                .clientKey(clientKey)
                .server(serverUrl)
                .build()
        );
    }

    public static ParseManager on() {
        return ourInstance;
    }


    public void signUp(String username, String password, RemoteObject remoteObject, final AuthSignUpCallback callback) {
        ParseUser user = new ParseMapper().getParseUser(username, password, remoteObject);

        // other fields can be set just like with ParseObject

        user.signUpInBackground(new SignUpCallback() {
            public void done(ParseException e) {
                if (e == null) {
                    callback.onSignUp(true);
                } else {
                    // Sign up didn't succeed. Look at the ParseException
                    // to figure out what went wrong
                    //userEntity.setSuccess(false);
                    callback.onSignUp(false);
                }

            }
        });
    }


    public void getCurrentUser(UserCallback callback) {
        UserModel userModel = null;

        userModel = new ParseMapper().getUser(ParseUser.getCurrentUser(), userModel);

        callback.onCurrentUser(userModel);
    }


    public void signIn(String username, String password, final AuthSignInCallback callback) {

        ParseUser.logInInBackground(username, password, new LogInCallback() {
            public void done(ParseUser user, ParseException e) {

                UserModel userModel = null;

                if (user != null) {
                    userModel = new ParseMapper().getUser(user, userModel);

                    callback.onSignIn(userModel, true);
                } else {
                    callback.onSignIn(userModel, false);
                }
            }
        });

    }


    public void logOut() {
        ParseUser.logOut();
    }

    public void LiveQuerySubscribe(String user) {

    }
}
