package com.w3engineers.theme.util.helper;

import android.content.Context;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.StyleSpan;
import android.widget.Toast;

import es.dmoral.toasty.Toasty;
import com.w3engineers.theme.ludosix.R;

import static android.graphics.Typeface.BOLD_ITALIC;

/*
 * ****************************************************************************
 * * Copyright © 2018 W3 Engineers Ltd., All rights reserved.
 * *
 * * Created by:
 * * Name : SUDIPTA KUMAR PAIK
 * * Date : 2/1/18
 * * Email : sudipta@w3engineers.com
 * *
 * * Purpose : Toaster for all type of toast showing
 * *
 * * Last Edited by : SUDIPTA KUMAR PAIK on 2/1/18.
 * * History:
 * * 1:
 * * 2:
 * *
 * * Last Reviewed by : SUDIPTA KUMAR PAIK on 2/1/18.
 * ****************************************************************************
 */

public class Toaster {
    private static Context sContext;

    /*
     * Private constructor. Don't make it public
     * */
    private Toaster() {
    }


    /*
     * Show long toast message
     * */
    public static void show(String txt) {
        Toast.makeText(sContext, txt, Toast.LENGTH_SHORT).show();
    }

    /*
     * Init Toast message context only one time
     * */
    public static void init(Context context) {
        sContext = context;
    }


    public static void error(String txt) {
        if (!TextUtils.isEmpty(txt)) {
            Toasty.error(sContext, txt, Toast.LENGTH_SHORT, true).show();
        }
    }

    public static void success(String txt) {
        if (!TextUtils.isEmpty(txt)) {
            Toasty.success(sContext, txt, Toast.LENGTH_SHORT, true).show();
        }
    }

    public static void info(String txt) {
        if (!TextUtils.isEmpty(txt)) {
            Toasty.info(sContext, txt, Toast.LENGTH_SHORT, true).show();
        }
    }









}