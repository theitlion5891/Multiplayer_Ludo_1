package com.w3engineers.theme.ludosix.ui.ludo_game.ludo;


import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.GameComputerPlayer;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.GameInfo;

/**
 * ComputerPlayer
 * This class contains the "dumb" AI
 * This is the super dumb AI
 */

public class ComputerPlayer extends GameComputerPlayer {

    // to satisfy Serializable interface
    private static final long serialVersionUID = 578920931238746L;
    /**
     * constructor
     *
     * @param player
     */
    public ComputerPlayer(Player player){
        super(player);
    }

    @Override
    protected void receiveInfo(GameInfo info) {
        // if it's not a LudoState message, ignore it; otherwise
        // cast it
        if (!(info instanceof LudoState)) return;
        LudoState myState = (LudoState)info;
        // if it's not our move, ignore it
        if (myState.getWhoseMove() != this.playerNum) return;
        // sleep for 0.3 seconds to slow down the game
        sleep(700);
        //if it is the computer's turn to roll
        if(myState.getWhoseMove() == this.playerNum){
            if(myState.getIsRollable()) {
               // Log.i("Computer Player: " + this.playerNum, "Rolling the dice");
                game.sendAction(new ActionRollDice(this));
                return;
            }
            int index;
            index = myState.getTokenIndexOfFirstPieceOutOfStart(this.playerNum);
            //if the computer needs to move a piece
            if (index != -1) {
                game.sendAction(new ActionMoveToken(this, index));
                return; //return because if the player made a move, then it can't possibly bring a piece out of base
            }
            //if it needs to bring piece out of start
            index = myState.getTokenIndexOfFirstPieceInStart(this.playerNum);
            if (index != -1) {
                game.sendAction(new ActionRemoveFromBase(this, index));
                return;
            }
        }
    }
}
