package com.w3engineers.theme.util.lib.internet;

import android.util.Log;

import com.google.gson.Gson;
import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.util.lib.GSonHelper;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetDataType;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetGameDataType;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetGameModeType;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetInvitationType;
import com.w3engineers.theme.util.lib.internet.model.DataModel;
import com.w3engineers.theme.util.lib.internet.model.GameDataModel;
import com.w3engineers.theme.util.lib.internet.model.GameSettingsModel;
import com.w3engineers.theme.util.lib.internet.model.InvitationModel;

import java.util.List;

public class InternetConnectionManager {

    private static final String TAG = "ConnectionManager";

    public static void sendInvitation(List<Player> players) {
        Log.d(TAG, "sendInvitation: ");
   /*     GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.INVITE)
                .addAllEndpoints(endPoints)
                .build();*/

        InvitationModel invitationModel = new InvitationModel();
        invitationModel.setInternetInvitationType(InternetInvitationType.INVITE);
        invitationModel.setPlayerList(players);
        invitationModel.setReceiver(players.get(0).getUserId());

/*        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();*/

        //   List<DataModel> items = new ArrayList<>();

        DataModel dataModel = new DataModel();
        dataModel.setInternetDataType(InternetDataType.INVITATION_DATA);
        dataModel.setInvitationModel(invitationModel);
        dataModel.setSenderId(players.get(1));

        //  items.add(dataModel);
        //  new Gson().toJson(dataModel)
        System.out.println("JSon data: " + GSonHelper.toJson(dataModel));
        ConnectivityInternetProvider.getConnectivity().send(GSonHelper.toJson(dataModel));
    }

    public static void sendGameData(String data, boolean isGameInfo, String endPointId) {
/*        GameMessages.GameDataPacket gameDataPacket = GameMessages.GameDataPacket.newBuilder()
                .setData(data)
                .setDataType(isGameInfo ? GameMessages.GameDataPacket.DataType.GAME_INFO : GameMessages.GameDataPacket.DataType.GAME_ACTION)
                .build();*/

        Player selfPlayer = new Player(GameDataHelper.getUserInfo().getId(), "", GameDataHelper.getUserInfo().getName(),
                GameDataHelper.getUserInfo().getImagePath(), Player.Type.PROXY_PLAYER, GSonHelper.toJson(GameDataHelper.getScoreBoard()));


        GameDataModel gameDataModel = new GameDataModel();
        gameDataModel.setInternetGameDataType(isGameInfo ? InternetGameDataType.GAME_INFO : InternetGameDataType.GAME_ACTION);
        gameDataModel.setData(data);
        gameDataModel.setReceiver(endPointId);

/*        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setGameData(gameDataPacket)
                .setPacketType(GameMessages.PacketType.GAME_DATA)
                .build();*/

        DataModel dataModel = new DataModel();
        dataModel.setGameDataModel(gameDataModel);
        dataModel.setInternetDataType(InternetDataType.GAME_DATA);
        dataModel.setSenderId(selfPlayer);

        ConnectivityInternetProvider.getConnectivity().send(new Gson().toJson(dataModel));
    }

    public static void sendInvitationAccept(List<Player> players) {
/*        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .addAllEndpoints(endPoints)
                .setType(GameMessages.InvitationPacket.InvitationPacketType.ACCEPT)
                .build();*/


        InvitationModel invitationModel = new InvitationModel();
        invitationModel.setInternetInvitationType(InternetInvitationType.ACCEPT);
        invitationModel.setPlayerList(players);
        invitationModel.setReceiver(players.get(0).getUserId());
        ;

/*        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();*/

        DataModel dataModel = new DataModel();
        dataModel.setInternetDataType(InternetDataType.INVITATION_DATA);
        dataModel.setInvitationModel(invitationModel);
        dataModel.setSenderId(players.get(1));


        ConnectivityInternetProvider.getConnectivity().send(new Gson().toJson(dataModel));
    }

    public static void sendInvitationDecline(Player endPoint) {
     /*   GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.DECLINE)
                .build();*/
        Player selfPlayer = new Player(GameDataHelper.getUserInfo().getId(), "", GameDataHelper.getUserInfo().getName(),
                GameDataHelper.getUserInfo().getImagePath(), Player.Type.PROXY_PLAYER, GSonHelper.toJson(GameDataHelper.getScoreBoard()));

        selfPlayer.setRequestStatus(endPoint.getRequestStatus()); // This is just keeping flag of action type

        InvitationModel invitationModel = new InvitationModel();
        invitationModel.setInternetInvitationType(InternetInvitationType.DECLINE);
        invitationModel.setReceiver(endPoint.getUserId());

 /*       GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();*/

        DataModel dataModel = new DataModel();
        dataModel.setInternetDataType(InternetDataType.INVITATION_DATA);
        dataModel.setInvitationModel(invitationModel);
        dataModel.setSenderId(selfPlayer);

        ConnectivityInternetProvider.getConnectivity().send(new Gson().toJson(dataModel));
    }

    /**
     * Send mesh update(new endpoint added) to specified endpoints
     *
     * @param endpointIds
     * @param endpoint
     */
    public static void sendUpdateAccept(List<String> endpointIds, Player endpoint) {

        Player selfPlayer = new Player(GameDataHelper.getUserInfo().getId(), "", GameDataHelper.getUserInfo().getName(),
                GameDataHelper.getUserInfo().getImagePath(), Player.Type.PROXY_PLAYER, GSonHelper.toJson(GameDataHelper.getScoreBoard()));

        for (String id : endpointIds) {
   /*     GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.UPDATE_ACCEPT)
                .setEndpoint(endpoint)
                .build();*/

            InvitationModel invitationModel = new InvitationModel();
            invitationModel.setInternetInvitationType(InternetInvitationType.UPDATE_ACCEPT);
            invitationModel.setPlayer(endpoint);
            invitationModel.setReceiver(id);


/*        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();*/

            DataModel dataModel = new DataModel();
            dataModel.setInternetDataType(InternetDataType.INVITATION_DATA);
            dataModel.setInvitationModel(invitationModel);
            dataModel.setSenderId(selfPlayer);

            ConnectivityInternetProvider.getConnectivity().send(new Gson().toJson(dataModel));
        }


    }

    public static void sendPlayersInfoToNewPlayer(List<Player> endPoints, Player targetEndPoint) {
/*        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.MESH_PLAYER_INFO)
                .addAllEndpoints(endPoints)
                .build();*/

        Player selfPlayer = new Player(GameDataHelper.getUserInfo().getId(), "", GameDataHelper.getUserInfo().getName(),
                GameDataHelper.getUserInfo().getImagePath(), Player.Type.PROXY_PLAYER, GSonHelper.toJson(GameDataHelper.getScoreBoard()));


        InvitationModel invitationModel = new InvitationModel();
        invitationModel.setInternetInvitationType(InternetInvitationType.MESH_PLAYER_INFO);
        invitationModel.setPlayerList(endPoints);
        invitationModel.setReceiver(targetEndPoint.getUserId());

/*        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();*/

        DataModel dataModel = new DataModel();
        dataModel.setInternetDataType(InternetDataType.INVITATION_DATA);
        dataModel.setInvitationModel(invitationModel);
        dataModel.setSenderId(selfPlayer);

        ConnectivityInternetProvider.getConnectivity().send(new Gson().toJson(dataModel));
    }

    public static void broadCastImagesUpdate(List<String> endPointIds, Player owner, String imagePath) {
        for (String endPointId : endPointIds) {
            ConnectivityInternetProvider.getConnectivity().startSendingImage(endPointId, owner, imagePath);
        }
    }

    public static void sendInGamePlayerImagesToNewPlayer(List<Player> endPoints, Player destinationEndPoint) {
        for (Player endPoint : endPoints) {
            ConnectivityInternetProvider.getConnectivity().startSendingImage(destinationEndPoint, endPoint, endPoint.getImagePath());
        }
    }

    public static void sendGameSettingsToPlayers(List<String> endPointIds, InternetGameModeType gameMode) {

        for (String receiverId : endPointIds) {
/*
        GameMessages.GameSettingsPacket gameSettingsPacket = GameMessages.GameSettingsPacket.newBuilder()
                .setGameMode(gameMode)
                .build();
*/

            GameSettingsModel gameSettingsData = new GameSettingsModel();
            gameSettingsData.setInternetGameModeType(gameMode);
            gameSettingsData.setReceiver(receiverId);

/*
        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setGameSettingsPacket(gameSettingsPacket)
                .setPacketType(GameMessages.PacketType.GAME_SETTINGS)
                .build();
*/

            DataModel dataModel = new DataModel();
            dataModel.setInternetDataType(InternetDataType.GAME_SETTINGS);
            dataModel.setGameSettingsModel(gameSettingsData);

            ConnectivityInternetProvider.getConnectivity().send(new Gson().toJson(dataModel));
        }
    }

    public static void broadcastReadyToPlayMessage(List<String> sendToEndPointIds, List<Player> gamePlayerList) {
/*        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.READY_TO_PLAY)
                .addAllEndpoints(gamePlayerList)
                .build();*/
        Player selfPlayer = new Player(GameDataHelper.getUserInfo().getId(), "", GameDataHelper.getUserInfo().getName(),
                GameDataHelper.getUserInfo().getImagePath(), Player.Type.PROXY_PLAYER, GSonHelper.toJson(GameDataHelper.getScoreBoard()));

        for (String id : sendToEndPointIds) {
            InvitationModel invitationModel = new InvitationModel();
            invitationModel.setInternetInvitationType(InternetInvitationType.READY_TO_PLAY);
            invitationModel.setPlayerList(gamePlayerList);
            invitationModel.setReceiver(id);

/*        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();*/

            DataModel dataModel = new DataModel();
            dataModel.setInternetDataType(InternetDataType.INVITATION_DATA);
            dataModel.setInvitationModel(invitationModel);
            dataModel.setSenderId(selfPlayer);

            ConnectivityInternetProvider.getConnectivity().send(new Gson().toJson(dataModel));
        }
    }

    public static void broadcastGameStartMessage(List<String> sendToEndPointIds) {
 /*       GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.GAME_START)
                .build();*/

        Player selfPlayer = new Player(GameDataHelper.getUserInfo().getId(), "", GameDataHelper.getUserInfo().getName(),
                GameDataHelper.getUserInfo().getImagePath(), Player.Type.PROXY_PLAYER, GSonHelper.toJson(GameDataHelper.getScoreBoard()));

        for (String id : sendToEndPointIds) {

            InvitationModel invitationModel = new InvitationModel();
            invitationModel.setInternetInvitationType(InternetInvitationType.GAME_START);
            invitationModel.setReceiver(id);


 /*       GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();*/

            DataModel dataModel = new DataModel();
            dataModel.setInternetDataType(InternetDataType.INVITATION_DATA);
            dataModel.setInvitationModel(invitationModel);
            dataModel.setSenderId(selfPlayer);

            ConnectivityInternetProvider.getConnectivity().send(new Gson().toJson(dataModel));
        }
    }

    public static void sendReadyToPlayAckToHost(Player endPoint, String hostEndpointId) {
/*        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.READY_TO_PLAY_ACK)
                .setEndpoint(endPoint)
                .build();*/

        Player selfPlayer = new Player(GameDataHelper.getUserInfo().getId(), "", GameDataHelper.getUserInfo().getName(),
                GameDataHelper.getUserInfo().getImagePath(), Player.Type.PROXY_PLAYER, GSonHelper.toJson(GameDataHelper.getScoreBoard()));


        InvitationModel invitationModel = new InvitationModel();
        invitationModel.setPlayer(endPoint);
        invitationModel.setInternetInvitationType(InternetInvitationType.READY_TO_PLAY_ACK);
        invitationModel.setReceiver(hostEndpointId);

/*        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();*/

        DataModel dataModel = new DataModel();
        dataModel.setInternetDataType(InternetDataType.INVITATION_DATA);
        dataModel.setInvitationModel(invitationModel);
        dataModel.setSenderId(selfPlayer);

        ConnectivityInternetProvider.getConnectivity().send(new Gson().toJson(dataModel));
    }

    public static void broadcastPlayerDisconnectedEvent(List<String> endPointIds, Player endPoint) {
/*        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.PLAYER_DISCONNECTED)
                .setEndpoint(endPoint)
                .build();*/

        Player selfPlayer = new Player(GameDataHelper.getUserInfo().getId(), "", GameDataHelper.getUserInfo().getName(),
                GameDataHelper.getUserInfo().getImagePath(), Player.Type.PROXY_PLAYER, GSonHelper.toJson(GameDataHelper.getScoreBoard()));

        for (String id : endPointIds) {

            InvitationModel invitationModel = new InvitationModel();
            invitationModel.setPlayer(endPoint);
            invitationModel.setInternetInvitationType(InternetInvitationType.PLAYER_DISCONNECTED);
            invitationModel.setReceiver(id);

/*
        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();
*/

            DataModel dataModel = new DataModel();
            dataModel.setInternetDataType(InternetDataType.INVITATION_DATA);
            dataModel.setInvitationModel(invitationModel);
            dataModel.setSenderId(selfPlayer);

            ConnectivityInternetProvider.getConnectivity().send(new Gson().toJson(dataModel));
        }
    }


    public static void removePlayerByHost(Player endPoint, List<String> endPointIds) {
/*        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.PLAYER_REMOVED)
                .setEndpoint(endPoint)
                .build();*/

        Player selfPlayer = new Player(GameDataHelper.getUserInfo().getId(), "", GameDataHelper.getUserInfo().getName(),
                GameDataHelper.getUserInfo().getImagePath(), Player.Type.PROXY_PLAYER, GSonHelper.toJson(GameDataHelper.getScoreBoard()));

        for (String id : endPointIds) {
            InvitationModel invitationModel = new InvitationModel();
            invitationModel.setPlayer(endPoint);
            invitationModel.setInternetInvitationType(InternetInvitationType.PLAYER_REMOVED);
            invitationModel.setReceiver(id);


/*        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();*/

            DataModel dataModel = new DataModel();
            dataModel.setInternetDataType(InternetDataType.INVITATION_DATA);
            dataModel.setInvitationModel(invitationModel);
            dataModel.setSenderId(selfPlayer);

            ConnectivityInternetProvider.getConnectivity().send(new Gson().toJson(dataModel));
        }

    }

    public static void remove(Player targetEndPoint) {
/*        GameMessages.InvitationPacket invitationPacket = GameMessages.InvitationPacket.newBuilder()
                .setType(GameMessages.InvitationPacket.InvitationPacketType.REMOVED)
                .build();*/

        Player selfPlayer = new Player(GameDataHelper.getUserInfo().getId(), "", GameDataHelper.getUserInfo().getName(),
                GameDataHelper.getUserInfo().getImagePath(), Player.Type.PROXY_PLAYER, GSonHelper.toJson(GameDataHelper.getScoreBoard()));


        InvitationModel invitationModel = new InvitationModel();
        invitationModel.setInternetInvitationType(InternetInvitationType.REMOVED);
        invitationModel.setReceiver(targetEndPoint.getUserId());

/*        GameMessages.DataPacket dataPacket = GameMessages.DataPacket.newBuilder()
                .setInvitation(invitationPacket)
                .setPacketType(GameMessages.PacketType.INVITATION_DATA)
                .build();*/

        DataModel dataModel = new DataModel();
        dataModel.setInternetDataType(InternetDataType.INVITATION_DATA);
        dataModel.setInvitationModel(invitationModel);
        dataModel.setSenderId(selfPlayer);


        ConnectivityInternetProvider.getConnectivity().send(new Gson().toJson(dataModel));
    }

}