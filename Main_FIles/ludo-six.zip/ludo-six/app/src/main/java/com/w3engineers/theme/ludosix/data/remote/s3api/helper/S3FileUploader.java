package com.w3engineers.theme.ludosix.data.remote.s3api.helper;

/*
 *  ****************************************************************************
 *  * Created by : Ahmed Mohmmad Ullah (Azim) on 5/3/2018 at 3:58 PM.
 *  * Email : azim@w3engineers.com
 *  *
 *  * Last edited by : Ahmed Mohmmad Ullah (Azim) on 5/3/2018.
 *  * Last edited by : Sudipta K Paik on 05/29/2018.
 *  *
 *  * Last Reviewed by : <Reviewer Name> on <mm/dd/yy>
 *  ****************************************************************************
 */

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLException;


import id.zelory.compressor.Compressor;

final public class S3FileUploader {

    private final int FILE_UPLOAD_CANCELLED = -1;

    private final String TAG = getClass().getSimpleName();
    private S3UploaderConfig mS3UploaderConfig;
    private ConcurrentMap<String, Integer> mMap = new ConcurrentHashMap<>();

    private static final S3FileUploader mS3FileUploader = new S3FileUploader();

    public static final S3FileUploader getInstance() {
        return mS3FileUploader;
    }

    public void init(S3UploaderConfig s3UploaderConfig) {
        this.mS3UploaderConfig = s3UploaderConfig;
    }

    /**
     * throws {@link IllegalStateException}
     *
     *
     * @param contentResolver
     * @param fileUri
     * @param s3FileUploaderListener
     * @param context
     * @return
     * @throws IllegalStateException
     */
    public final S3FileUploadResponse uploadFile(ContentResolver contentResolver, Uri fileUri,
                                                 S3FileUploaderListener s3FileUploaderListener, Context context)
            throws IllegalStateException, IOException {

        FileInfo fi = FileUtility.getFileInfoFromUri(fileUri);

        if (fi == null)
            fi = FileUtility.getFileInfoFromUri(context.getContentResolver(), fileUri);

        BaseResponse baseResponse = getUploadUrl(fi);
        if(baseResponse != null) {

            S3FileUploadResponse s3FileUploadResponse = DataParser.parseUploadUrlData(baseResponse.responseMessage);
            if(s3FileUploadResponse != null) {

                if (s3FileUploadResponse.responseCode == HttpURLConnection.HTTP_OK) {

                    String path = fi.filePath;
                    if(TextUtils.isEmpty(path)) {
                        s3FileUploadResponse.responseCode = HTTPConstant.FILE_UPLOAD_FAILED_REASON_DEFAULT;
                        return s3FileUploadResponse;
                    }
                    File file = new Compressor(context).compressToFile(new File(path));
                    if(file == null) {
                        s3FileUploadResponse.responseCode = HTTPConstant.FILE_UPLOAD_FAILED_REASON_FILE_SIZE;
                        return s3FileUploadResponse;
                    }
                    boolean isSuccess = uploadToServer(file, s3FileUploadResponse.uploadSignedUrl, s3FileUploaderListener);
                    s3FileUploadResponse.responseCode = isSuccess ? HttpURLConnection.HTTP_OK : HTTPConstant.FILE_UPLOAD_FAILED_REASON_DEFAULT;
                    return s3FileUploadResponse;
                }
            }

            Log.d(TAG, "upload link::"+baseResponse.responseMessage);
        }

        return null;
    }

    public final void cancelFileUpload(String filePath) {
        if(mMap != null) {
            mMap.put(filePath, FILE_UPLOAD_CANCELLED);
        }
    }



    private BaseResponse getUploadUrl(FileInfo fileInfo) {


        //Working
        Map<String, String> map = new HashMap<>();
        map.put(HTTPConstant.S3BUCKET, mS3UploaderConfig.bucket);
        map.put(HTTPConstant.FILE_NAME, fileInfo.name);

        try {
            BaseResponse baseResponse = HttpRequester.post(mS3UploaderConfig.baseUrl +
                    mS3UploaderConfig.uploadSignedUrl, map, mS3UploaderConfig.authTokenId);
            Log.d(TAG, "" + baseResponse.responseMessage);
            return baseResponse;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public boolean uploadToServer(File file, String signedUrl, S3FileUploaderListener s3FileUploaderListener) {

        HttpsURLConnection http = null;
        try {

            mMap.put(file.getAbsolutePath(), 0);

            boolean isFailed = false;
            int lengthOfFile = (int) file.length();

            Log.d(TAG, "http.keepAlive false");
            http = (HttpsURLConnection) new URL(signedUrl).openConnection();

            http.setRequestMethod("PUT");
            http.setDoOutput(true);  // reset any previous setting, if con is long lasting
            http.setRequestProperty("Content-Type", "application/octet-stream");
            // TODO: 27-Jun-16 Need to impose check for below 19 API
            //For some unknown reason it was creating problem so, avoiding for now
            http.setFixedLengthStreamingMode(lengthOfFile);

            http.connect();


            OutputStream output = http.getOutputStream();

            InputStream input = new FileInputStream(file);

            // Read buffer, to read a big chunk at a time.
            byte[] buffer = new byte[20480];
            int length;
            long total = 0;
            int percentage = 0;
            // Read until -1 is returned, i.e. stream ended.

            while ((length = input.read(buffer)) != -1) {

                if (mMap.get(file.getAbsolutePath()) == FILE_UPLOAD_CANCELLED) {
                    if(s3FileUploaderListener != null) {
                        s3FileUploaderListener.onFileUploadFailed(file.getAbsolutePath(), HTTPConstant.FILE_UPLOAD_FAILED_REASON_CANCELLED);
                    }
                    isFailed = true;
                    break;
                } else {

                    total += length;

                    percentage = (int) ((total * 100) / lengthOfFile);
                    output.write(buffer, 0, length);

                    if(percentage % 10 == 0) {
                        Log.d(TAG, "uploaded "+ percentage + "%");
                    }

                    if(s3FileUploaderListener != null) {
                        s3FileUploaderListener.onFileUploadProgress(file.getAbsolutePath(), percentage);
                    }

                }
            }

            output.flush();

            input.close();
            output.close();


            if (isFailed) {
                if(s3FileUploaderListener != null) {
                    s3FileUploaderListener.onFileUploadFailed(null, HTTPConstant.FILE_UPLOAD_FAILED_REASON_DEFAULT);
                }
            } else {
                int responseCode = http.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {

                    if(s3FileUploaderListener != null) {
                        s3FileUploaderListener.onFileUploadSuccess(file.getAbsolutePath());
                    }

                } else {
                    if(s3FileUploaderListener != null) {
                        s3FileUploaderListener.onFileUploadFailed(file.getAbsolutePath(), HTTPConstant.FILE_UPLOAD_FAILED_REASON_DEFAULT);
                    }
                }
            }


        }
        catch(SSLException e){
            e.printStackTrace();
            if(s3FileUploaderListener != null) {
                s3FileUploaderListener.onFileUploadFailed(file.getAbsolutePath(), HTTPConstant.FILE_UPLOAD_FAILED_REASON_DEFAULT);
            }
            return false;
        }
        catch (Exception e) {
            e.printStackTrace();
            if(s3FileUploaderListener != null) {
                s3FileUploaderListener.onFileUploadFailed(file.getAbsolutePath(), HTTPConstant.FILE_UPLOAD_FAILED_REASON_DEFAULT);
            }
            return false;
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            if(s3FileUploaderListener != null) {
                s3FileUploaderListener.onFileUploadFailed(file.getAbsolutePath(), HTTPConstant.FILE_UPLOAD_FAILED_REASON_DEFAULT);
            }
            return false;
        } finally {

            if (http != null) {
                http.disconnect();
            }

        }

        return true;
    }
}
