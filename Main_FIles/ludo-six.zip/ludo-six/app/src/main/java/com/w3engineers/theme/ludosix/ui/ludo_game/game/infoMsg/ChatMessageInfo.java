package com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg;

import com.w3engineers.theme.ludosix.data.local.model.Message;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 15/02/2019 at 11:20 AM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Info class containing chat message data
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 15/02/2019.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 15/02/2019.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class ChatMessageInfo extends GameInfo {

    private Message message;

    public void setMessage(Message message) {
        this.message = message;
    }

    public ChatMessageInfo(Message message) {
        this.message = message;
    }

    public Message getMessage() {
        return message;
    }
}
