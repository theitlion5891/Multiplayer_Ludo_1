package com.w3engineers.theme.ludosix.data.local.model;

import androidx.databinding.BindingAdapter;
import android.widget.ImageView;

import com.w3engineers.theme.util.helper.Glider;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/9/2018 at 11:47 AM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Model class representing user info
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 12/18/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 12/18/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public class UserInfo {

    private String id;
    private String name;
    private String imagePath;

    public UserInfo() {
    }

    public UserInfo(String id, String name, String imagePath) {
        this.id = id;
        this.name = name;
        this.imagePath = imagePath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    @BindingAdapter({"bind:imagePath"})
    public static void setUserImage(ImageView imageView, String imagePath) {
        if (imagePath != null)
            Glider.showCircleImage(imagePath, imageView);
    }
}
