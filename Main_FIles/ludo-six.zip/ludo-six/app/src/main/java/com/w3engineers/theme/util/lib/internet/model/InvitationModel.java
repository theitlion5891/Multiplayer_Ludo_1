package com.w3engineers.theme.util.lib.internet.model;

import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetInvitationType;

import java.util.List;

public class InvitationModel {
    InternetInvitationType internetInvitationType;
    List<Player> playerList;
    Player player;
    String receiver;

    public InvitationModel(){

    }

    public InvitationModel(InternetInvitationType internetInvitationType, List<Player> playerList){
        this.internetInvitationType = internetInvitationType;
        this.playerList = playerList;
    }

    public InternetInvitationType getInternetInvitationType() {
        return internetInvitationType;
    }

    public void setInternetInvitationType(InternetInvitationType internetInvitationType) {
        this.internetInvitationType = internetInvitationType;
    }

    public List<Player> getPlayerList() {
        return playerList;
    }

    public void setPlayerList(List<Player> playerList) {
        this.playerList = playerList;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }
}
