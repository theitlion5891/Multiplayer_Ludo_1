package com.w3engineers.theme.ludosix.ui.snakes_game.snakes;

import com.w3engineers.theme.ludosix.ui.snakes_game.game.GamePlayer;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.actionMsg.GameAction;

/**
 * ActionMoveToken class
 * Game action that is sent to LudoLocalgame
 */
public class ActionAnimateToken extends GameAction {

//    private int index;
    private int count;

    /**
     * constructor for GameAction
     *
     * @param player the player who created the action
     */
    public ActionAnimateToken(GamePlayer player, int count) {
        super(player);
//        this.index = index;
        this.count = count;
    }

    public int getCount() {
        return this.count;
    }
}
