package com.w3engineers.theme.ludosix.ui.internet;

import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.base.MvpView;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetGameModeType;

import java.util.List;

public interface InternetHomeMvpView extends MvpView {
    void onInternetDeviceConnected(Player player);

    void onInternetDeviceDisconnected(Player player);

    void onInvitationReceived(Player requestedByPlayer, Player selfPlayer);

    void onInvitationAcceptByPeer(Player acceptedByPlayer, Player selfPlayer);

    void onInvitationRejectByPeer(Player player);

    void onNewPeerAccepted(Player player);

    void onProfilePicReceived(Player player, String imagePath);

    void onInternetPlayerInfoReceived(List<Player> players);

    void onGameModeDataChanged(InternetGameModeType gameMode);

    void onOtherPlayerDisconnected(Player player);

    void onPlayerRemovedByHost(Player player);

    void onReadyToPlayMessage(List<Player> players);

    void onGameStartedByHost();

    void onReadyToPlayAckMessage(Player player);

    void onRemoved();

}
