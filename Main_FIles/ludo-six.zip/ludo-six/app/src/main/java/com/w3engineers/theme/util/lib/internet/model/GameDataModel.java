package com.w3engineers.theme.util.lib.internet.model;

import com.w3engineers.theme.util.lib.internet.enumkeys.InternetGameDataType;

public class GameDataModel {
    InternetGameDataType internetGameDataType;
    String data;
    String receiver;


    public InternetGameDataType getInternetGameDataType() {
        return internetGameDataType;
    }

    public void setInternetGameDataType(InternetGameDataType internetGameDataType) {
        this.internetGameDataType = internetGameDataType;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }
}
