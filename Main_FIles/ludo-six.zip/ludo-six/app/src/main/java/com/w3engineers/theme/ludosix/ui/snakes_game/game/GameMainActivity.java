package com.w3engineers.theme.ludosix.ui.snakes_game.game;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.data.helper.keys.PreferenceKey;
import com.w3engineers.theme.ludosix.data.local.event.GameActionEvent;
import com.w3engineers.theme.ludosix.data.local.event.GameDataEvent;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.home.HomeActivity;
import com.w3engineers.theme.ludosix.ui.internet.InternetHomeActivity;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.util.ChatMessageProcessor;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.actionMsg.GameAction;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.config.GameConfig;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.config.GamePlayerType;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.util.GameQueueProcessor;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.util.MessageBox;
import com.w3engineers.theme.ludosix.ui.snakes_game.snakes.ActionAnimateDice;
import com.w3engineers.theme.ludosix.ui.snakes_game.snakes.ActionChatMessage;
import com.w3engineers.theme.ludosix.ui.snakes_game.snakes.ActionHostDisconnected;
import com.w3engineers.theme.ludosix.ui.snakes_game.snakes.ActionRollDice;
import com.w3engineers.theme.util.helper.AdHelper;
import com.w3engineers.theme.util.helper.ScreenUtils;
import com.w3engineers.theme.util.helper.SharedPref;
import com.w3engineers.theme.util.lib.internet.ConnectivityInternetProvider;
import com.w3engineers.theme.util.lib.internet.InternetConnectionManager;
import com.w3engineers.theme.util.lib.nearby.ConnectionManager;
import com.w3engineers.theme.util.lib.nearby.ConnectivityProvider;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import timber.log.Timber;

/**
 * class GameMainActivity
 * <p>
 * is the main activity for the game framework. To create a new game, create a
 * sub-class of this class that implements its abstract methods below.
 *
 * @author Andrew M. Nuxoll
 * @author Steven R. Vegdahl
 * @date Version 2013
 */
public abstract class GameMainActivity extends AppCompatActivity {

    /*
     * ====================================================================
     * Instance Variables
     * --------------------------------------------------------------------
     */

    // A reference to the object representing the game itself. This is the
    // object that knows the rules of the game. This variable is initialized in
    // launchGame.
    private Game game = null;

    // an array containing references to all the players that are playing the game
    private GamePlayer[] players = null;

    // tells which player, if any, is running in the GUI
    private GamePlayer guiPlayer = null;

    // whether the game is over
    private boolean gameIsOver = false;
    public static boolean isInGame = false;

    private Handler mHandler = new Handler();
    private Dialog mSoundSettingsDialog;

    public static final int DIALOG_DISMISS_TIMEOUT = 3 * 1000;
    /**
     * contains the game configuration this activity will be used to initialize
     */
    GameConfig config = null;

    /*
     * ====================================================================
     * Abstract Methods
     *
     * To create a game using the game framework you must create a subclass of
     * GameMainActivity that implements the following methods.
     * --------------------------------------------------------------------
     */

    /**
     * Creates a default, game-specific configuration for the current game.
     * <p>
     * IMPORTANT: The default configuration must be a legal configuration!
     *
     * @return an instance of the GameConfig class that defines a default
     * configuration for this game. (The default may be subsequently
     * modified by the user if this is allowed.)
     */
    public abstract GameConfig createDefaultConfig();

    /**
     * createLocalGame
     * <p>
     * Creates a new game that runs on the server tablet. For example, if
     * you were creating tic-tac-toe, you would implement this method to return
     * an instance of your TTTLocalGame class which, in turn, would be a
     * subclass of {@link LocalGame}.
     *
     * @return a new, game-specific instance of a sub-class of the LocalGame
     * class.
     */
    public abstract LocalGame createLocalGame();

    public abstract RemoteGame createRemoteGame();

    /*
     * ====================================================================
     * Public Methods
     * --------------------------------------------------------------------
     */

    /**
     * onCreate
     * <p>
     * "main" for the game framework
     */
    @Override
    public final void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Making the activity full screen in IMMERSIVE_STICKY fullscreen mode
        ScreenUtils.hideSystemUI(this);
        setContentView(R.layout.snakes_board);

        // create the default configuration for this game
        this.config = createDefaultConfig();
        String msg = launchGame(this.config);

        if (msg != null) {
            // we have an error message
            MessageBox.popUpMessage(msg, this);
        }

        checkIfMusicMuted();
        findViewById(R.id.snakes_board_music_btn).setOnClickListener(view -> showMusicSettingsDialog());

        // Load Banner ads
        AdHelper.loadBannerAd(this, (LinearLayout) findViewById(R.id.add_layout));
    }

    private void checkIfMusicMuted() {

        if (GameDataHelper.getSoundVolume() == 0) {
            ((ImageView) findViewById(R.id.snakes_board_music_btn)).setImageResource(R.drawable.ic_home_music_disabled);
        } else {
            ((ImageView) findViewById(R.id.snakes_board_music_btn)).setImageResource(R.drawable.ic_home_music);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        isInGame = true;
    }

    @Override
    protected void onPause() {
        isInGame = false;
        super.onPause();

    }

    @Override
    protected void onDestroy() {
        isInGame = false;

        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onGamePlayerDisconnectedEvent(Player player) {
        if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
            if (ConnectivityProvider.getConnectivity().getCurrentRole() == ConnectivityProvider.ConnectionRole.HOST) {
                replaceDisconnectedPlayerWithBot(player.getUserId());

            } else {
                if (game instanceof RemoteGame) {
                    game.sendAction(new ActionHostDisconnected(((RemoteGame) game).getRemoteHumanPlayer()));
                }
            }
        }else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)){
            if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.HOST) {
                replaceDisconnectedPlayerWithBot(player.getUserId());

            } else {
                if (game instanceof RemoteGame) {
                    game.sendAction(new ActionHostDisconnected(((RemoteGame) game).getRemoteHumanPlayer()));
                }
            }
        }

    }

    public GamePlayer[] getGamePlayers() {
        return players;
    }

    private void replaceDisconnectedPlayerWithBot(String userId) {
        if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)) {
            if (game != null && config != null) {
                for (GamePlayer gameplayer : players) {
                    if (gameplayer.getPlayerInfo().getUserId().equals(userId)) {
                        LocalGame localGame = (LocalGame) game;

                        // If proxy player then replace with bot
                        if (gameplayer instanceof GameProxyPlayer) {
                            GamePlayerType gpt = config.getAvailTypes()[1]; // bot player type
                            GamePlayer botPlayer = gpt.createPlayer(
                                    new Player(gameplayer.getPlayerInfo().getUserId(), gameplayer.getPlayerInfo().getEndPointId(),
                                            gameplayer.getPlayerInfo().getName(), "", Player.Type.BOT)); // Replacement bot player

                            GameComputerPlayer computerPlayer = (GameComputerPlayer) botPlayer;
                            GameProxyPlayer disconnectedPlayer = (GameProxyPlayer) gameplayer;

                            computerPlayer.setGame(game);
                            computerPlayer.setPlayerNum(disconnectedPlayer.getPlayerInfo().getPlayerPosition());

                            String[] playerNames = disconnectedPlayer.getAllPlayerNames();
                            playerNames[disconnectedPlayer.getPlayerNum()] = computerPlayer.getPlayerInfo().getName(); // Setting own name

                            computerPlayer.setPlayerNames(playerNames);
                            computerPlayer.getPlayerInfo().setPlayerColor(disconnectedPlayer.getPlayerInfo().getPlayerColor());

                            computerPlayer.getPlayerInfo().setPlayerPosition(disconnectedPlayer.getPlayerInfo().getPlayerPosition());
                            localGame.replacePlayer(localGame.getPlayerIdx(gameplayer), computerPlayer);
                        }
                    }
                }
            }
        } else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)) {
            if (game != null && config != null) {
                for (GamePlayer gameplayer : players) {
                    if (gameplayer.getPlayerInfo().getUserId().equals(userId)) {
                        LocalGame localGame = (LocalGame) game;

                        // If proxy player then replace with bot
                        if (gameplayer instanceof GameProxyPlayer) {
                            GamePlayerType gpt = config.getAvailTypes()[1]; // bot player type
                            GamePlayer botPlayer = gpt.createPlayer(
                                    new Player(gameplayer.getPlayerInfo().getUserId(), gameplayer.getPlayerInfo().getUserId(),
                                            gameplayer.getPlayerInfo().getName(), "", Player.Type.BOT)); // Replacement bot player

                            GameComputerPlayer computerPlayer = (GameComputerPlayer) botPlayer;
                            GameProxyPlayer disconnectedPlayer = (GameProxyPlayer) gameplayer;

                            computerPlayer.setGame(game);
                            computerPlayer.setPlayerNum(disconnectedPlayer.getPlayerInfo().getPlayerPosition());

                            String[] playerNames = disconnectedPlayer.getAllPlayerNames();
                            playerNames[disconnectedPlayer.getPlayerNum()] = computerPlayer.getPlayerInfo().getName(); // Setting own name

                            computerPlayer.setPlayerNames(playerNames);
                            computerPlayer.getPlayerInfo().setPlayerColor(disconnectedPlayer.getPlayerInfo().getPlayerColor());

                            computerPlayer.getPlayerInfo().setPlayerPosition(disconnectedPlayer.getPlayerInfo().getPlayerPosition());
                            localGame.replacePlayer(localGame.getPlayerIdx(gameplayer), computerPlayer);
                        }
                    }
                }
            }
        }

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onGameDataEvent(GameDataEvent event) {

        if (game != null) {
            GameActionEvent gameActionEvent = event.getGameAction();

            if (!event.isGameInfo()) {
                if (game instanceof LocalGame) {
                    GameAction gameAction = getLocalGameActionFromGameEvent(gameActionEvent);

                    if (gameActionEvent.getAction() == GameActionEvent.Action.LEFT_GAME) {
                        replaceDisconnectedPlayerWithBot(gameActionEvent.getUserId());

                    } else if (gameAction != null) {
                        sendActionToProxyPlayers(gameAction);

                        if (gameActionEvent.getAction() == GameActionEvent.Action.CHAT_MESSAGE) {
                            game.sendAction(gameAction);

                        } else {
                            GameQueueProcessor.getInstance().addEvent(gameAction);
                        }
                    }

                } else if (game instanceof RemoteGame) {
                    RemoteGame remoteGame = (RemoteGame) game;

                    GamePlayer gamePlayer = remoteGame.getPlayerFromIndex(gameActionEvent.getPlayerId());
                    GameAction gameAction = getRemoteGameActionFromGameEvent(gameActionEvent, remoteGame, gamePlayer);

                    Timber.i("Remote Game data from: " + gamePlayer.getPlayerInfo().getName() + "  Action: " + gameActionEvent.getAction());

                    if (gameAction != null) {

                        if (gameAction instanceof ActionHostDisconnected || gameAction instanceof ActionChatMessage) {
                            remoteGame.sendAction(gameAction);

                        } else {
                            GameQueueProcessor.getInstance().addEvent(gameAction);
                        }
                    }
                }
            }
        }
    }

    private void sendActionToProxyPlayers(GameAction action) {
        if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)) {
            LocalGame localGame = (LocalGame) game;
            GamePlayer player = action.getPlayer();

            int playerId = player.getPlayerInfo().getPlayerPosition();
            GameActionEvent gameActionEvent = null;

            if (action instanceof ActionAnimateDice) {
                gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.ANIMATE_DICE);

            } else if (action instanceof ActionRollDice) {
                gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.ROLL_DICE, ((ActionRollDice) action).getDiceVal());

            } else if (action instanceof ActionChatMessage) {
                gameActionEvent = new GameActionEvent(playerId, ((ActionChatMessage) action).getMessage(), GameActionEvent.Action.CHAT_MESSAGE);
            }

            if (gameActionEvent != null) {
                String data = new Gson().toJson(gameActionEvent);

                for (GamePlayer playerToSend : localGame.players) {
                    if (playerToSend.isProxy() && !playerToSend.getPlayerInfo().getEndPointId().equals(player.getPlayerInfo().getEndPointId())) {

                        ConnectionManager.sendGameData(data, false, playerToSend.getPlayerInfo().getEndPointId());

                    }
                }
            }
        } else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)) {
            LocalGame localGame = (LocalGame) game;
            GamePlayer player = action.getPlayer();

            int playerId = player.getPlayerInfo().getPlayerPosition();
            GameActionEvent gameActionEvent = null;

            if (action instanceof ActionAnimateDice) {
                gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.ANIMATE_DICE);

            } else if (action instanceof ActionRollDice) {
                gameActionEvent = new GameActionEvent(playerId, GameActionEvent.Action.ROLL_DICE, ((ActionRollDice) action).getDiceVal());

            } else if (action instanceof ActionChatMessage) {
                gameActionEvent = new GameActionEvent(playerId, ((ActionChatMessage) action).getMessage(), GameActionEvent.Action.CHAT_MESSAGE);
            }

            if (gameActionEvent != null) {
                String data = new Gson().toJson(gameActionEvent);

                for (GamePlayer playerToSend : localGame.players) {
                    if (playerToSend.isProxy() && !playerToSend.getPlayerInfo().getUserId().equals(player.getPlayerInfo().getUserId())) {
                        InternetConnectionManager.sendGameData(data, false, playerToSend.getPlayerInfo().getUserId());
                    }
                }
            }
        }

    }

    private GameAction getLocalGameActionFromGameEvent(GameActionEvent gameActionEvent) {

        GamePlayer gamePlayer = ((LocalGame) game).getPlayerFromIndex(gameActionEvent.getPlayerId());
        int index = gameActionEvent.getIndex();

        Timber.i("Game data from: " + gamePlayer.getPlayerInfo().getName() + "  Action: " + gameActionEvent.getAction());

        if (gameActionEvent.getAction() == GameActionEvent.Action.ROLL_DICE) {
            return new ActionRollDice(gamePlayer, index);

        } else if (gameActionEvent.getAction() == GameActionEvent.Action.ANIMATE_DICE) {
            return new ActionAnimateDice(gamePlayer);

        } else if (gameActionEvent.getAction() == GameActionEvent.Action.CHAT_MESSAGE) {
            return new ActionChatMessage(gamePlayer, gameActionEvent.getMessage());
        }

        return null;
    }

    private GameAction getRemoteGameActionFromGameEvent(GameActionEvent gameActionEvent, RemoteGame remoteGame, GamePlayer gamePlayer) {

        if (gameActionEvent.getAction() == GameActionEvent.Action.ROLL_DICE) {
            return new ActionRollDice(gamePlayer, gameActionEvent.getIndex());

        } else if (gameActionEvent.getAction() == GameActionEvent.Action.ANIMATE_DICE) {
            return new ActionAnimateDice(gamePlayer);

        } else if (gameActionEvent.getAction() == GameActionEvent.Action.LEFT_GAME) {
            return new ActionHostDisconnected(remoteGame.getRemoteHumanPlayer());

        } else if (gameActionEvent.getAction() == GameActionEvent.Action.CHAT_MESSAGE) {
            return new ActionChatMessage(remoteGame.getRemoteHumanPlayer(), gameActionEvent.getMessage());
        }

        return null;
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            ScreenUtils.hideSystemUI(this);
        }
    }

    /**
     * Creates the game and players, and starts the game.
     *
     * @param config is the configuration for this game
     * @return null if the launch was successful; otherwise a message telling
     * why game could not be launched
     */
    private String launchGame(GameConfig config) {

        // create the game if it's local (we defer remote game creation
        // until further down so that we do not attempt to make the
        // network connection until other errors are checked)
        if (config.isLocal()) { // local game
            game = createLocalGame();
        } else {
            game = createRemoteGame();
        }

        // verify we have a game
        if (game == null) {
            return "Game creation failed.";
        }

        GameQueueProcessor.getInstance().setGame(game); // Initializing game action processor
        ChatMessageProcessor.getInstance().clearMessageQueue(); // Clearing chat message queue

        //////////////////////////////////////
        // create the players
        //////////////////////////////////////
        int requiresGuiCount = 0; // the number of players that require a GUI
        guiPlayer = null; // the player that will be our GUI player
        players = new GamePlayer[config.getNumPlayers()]; // the array to contains our players

        // loop through each player
        for (int i = 0; i < players.length; i++) {
            String name = config.getPlayerInfo(i).getName(); // the player's name
            GamePlayerType gpt = config.getSelType(i); // the player's type
            GamePlayerType[] availTypes = config.getAvailTypes(); // the available player types
            players[i] = gpt.createPlayer(config.getPlayerInfo(i)); // create the player

            // check that the player name is legal
            if (name.length() <= 0 && gpt != availTypes[availTypes.length - 1]) {
                // disallow an empty player name, unless it's a dummy (proxy) player
                return "Local player name cannot be empty.";
            }

            // if the player requires a GUI, count and mark it; otherwise, if a player
            // supports a GUI and the "requires" count is zero, mark it
            if (players[i].requiresGui()) {
                requiresGuiCount++;
                guiPlayer = players[i];
            } else if (guiPlayer == null && players[i].supportsGui()) {
                guiPlayer = players[i];
            }
        }

        //Avery changed it to greater than 4
        // if there is more than four player that requires a GUI, abort
        if (requiresGuiCount > 4) {
            return "Cannot have more than four GUI player on a single device.";
        }

        // if there is a player that supports a GUI, link it to the activity,
        // otherwise set the GUI to be a "dummy" one with a "no GUI" message
        if (guiPlayer != null) {
            guiPlayer.gameSetAsGui(this);
        } else {
            // set the layout to be one with a "no GUI" message
            setContentView(R.layout.game_no_gui);
        }

        // start the game; then return null to indicate that the launch was
        // successful
        game.start(players);
        return null;

    }// launchGame

    @Override
    public void onBackPressed() {
        showExitDialog();
    }

    /**
     * Shows music settings dialog
     */
    private void showMusicSettingsDialog() {

        mSoundSettingsDialog = new Dialog(GameMainActivity.this);
        mSoundSettingsDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mSoundSettingsDialog.setCancelable(true);
        mSoundSettingsDialog.setContentView(R.layout.layout_music_settings);

        // Making background transparent
        if (mSoundSettingsDialog.getWindow() != null) {
            mSoundSettingsDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            mSoundSettingsDialog.getWindow().setGravity(Gravity.TOP);
        }

        SeekBar soundSeekbar = mSoundSettingsDialog.findViewById(R.id.layout_music_settings_sound_sb);
        ImageView soundImage = mSoundSettingsDialog.findViewById(R.id.layout_music_settings_sound_iv);

        int soundVolume = Math.round(GameDataHelper.getSoundVolume() * 100);
        soundSeekbar.setProgress(soundVolume);

        if (soundVolume == 0) {
            soundImage.setImageResource(R.drawable.ic_home_music_disabled);
        }

        int yellowColor = getResources().getColor(R.color.yellow_seekbar);
        soundSeekbar.getProgressDrawable().setColorFilter(yellowColor, PorterDuff.Mode.SRC_IN);
        soundSeekbar.getThumb().setColorFilter(yellowColor, PorterDuff.Mode.SRC_IN);

        soundImage.setOnClickListener(view -> {

            GameDataHelper.setSoundVolume(0);
            checkIfMusicMuted();

            soundImage.setImageResource(R.drawable.ic_home_music_disabled);
            soundSeekbar.setProgress(0);

        });

        soundSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                float volume = (float) progress / 100;
                GameDataHelper.setSoundVolume(volume);
                checkIfMusicMuted();

                if (progress == 0) {
                    soundImage.setImageResource(R.drawable.ic_home_music_disabled);

                } else {
                    soundImage.setImageResource(R.drawable.ic_home_music);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                mHandler.removeCallbacks(settingsDialogDismissRunnable);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mHandler.postDelayed(settingsDialogDismissRunnable, DIALOG_DISMISS_TIMEOUT);
            }
        });

        mSoundSettingsDialog.setOnCancelListener(dialogInterface -> {
            mHandler.removeCallbacks(settingsDialogDismissRunnable);
        });

        mSoundSettingsDialog.show();
        mHandler.postDelayed(settingsDialogDismissRunnable, DIALOG_DISMISS_TIMEOUT);

    }

    Runnable settingsDialogDismissRunnable = new Runnable() {
        @Override
        public void run() {
            if (mSoundSettingsDialog != null && mSoundSettingsDialog.isShowing()) {
                mSoundSettingsDialog.dismiss();
            }
        }
    };

    /**
     * Shows custom exit dialog with two buttons
     */
    private void showExitDialog() {

        Dialog dialog = new Dialog(GameMainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.layout_exit_dialog);

        // Making background transparent
        if (dialog.getWindow() != null)
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        dialog.findViewById(R.id.layout_exit_dialog_positive_button).setOnClickListener(v -> {

            if (!SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)) {
                if (HomeActivity.mHostPlayer != null &&
                        ConnectivityProvider.getConnectivity().getCurrentRole() == ConnectivityProvider.ConnectionRole.CLIENT && game != null) {

                    ConnectionManager.sendGameData(getGameLeftAction(), false, HomeActivity.mHostPlayer.getEndPointId());

                } else if (ConnectivityProvider.getConnectivity().getCurrentRole() == ConnectivityProvider.ConnectionRole.HOST && game != null) {

                    for (GamePlayer gamePlayer : players) {
                        if (gamePlayer.isProxy()) {

                            ConnectionManager.sendGameData(getGameLeftAction(), false, gamePlayer.getPlayerInfo().getEndPointId());
                        }
                    }
                }
            } else if (SharedPref.readBoolean(PreferenceKey.IS_INTERNET_GAME)) {
                if (InternetHomeActivity.mHostPlayer != null &&
                        ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.CLIENT && game != null) {

                    InternetConnectionManager.sendGameData(getGameLeftAction(), false, InternetHomeActivity.mHostPlayer.getUserId());

                } else if (ConnectivityInternetProvider.getConnectivity().getCurrentRole() == ConnectivityInternetProvider.ConnectionRole.HOST && game != null) {

                    for (GamePlayer gamePlayer : players) {
                        if (gamePlayer.isProxy()) {

                            InternetConnectionManager.sendGameData(getGameLeftAction(), false, gamePlayer.getPlayerInfo().getUserId());
                        }
                    }
                }
            }


            finish();
        });

        dialog.findViewById(R.id.layout_exit_dialog_negative_button).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private String getGameLeftAction() {
        GameActionEvent gameActionEvent = new GameActionEvent(guiPlayer.getPlayerInfo().getUserId(), GameActionEvent.Action.LEFT_GAME);
        return new Gson().toJson(gameActionEvent);
    }

    /**
     * marks the game as being over
     *
     * @param b tells whether the game is over
     */
    public void setGameOver(boolean b) {
        gameIsOver = b;
    }// setGameOver

}

