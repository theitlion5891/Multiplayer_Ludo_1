package com.w3engineers.theme.ludosix.data.helper.keys;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/9/2018 at 12:21 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Shared pref key holder class
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 1/25/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 1/25/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public interface PreferenceKey {
    String USER_INFO = "USER_INFO";
    String LUDO_SCORE_BOARD = "LUDO_SCORE_BOARD";
    String SNAKES_SCORE_BOARD = "SNAKES_SCORE_BOARD";

    String IS_TUTORIAL_SHOWN = "IS_TUTORIAL_SHOWN";
    String SOUND_VOLUME = "SOUND_VOLUME";
    String IS_INTERNET_GAME = "is_internet_game";
}