package com.w3engineers.theme.util.lib.internet;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.Payload;
import com.google.gson.Gson;
import com.w3engineers.theme.LudoSixApp;
import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.data.local.event.GameActionEvent;
import com.w3engineers.theme.ludosix.data.local.event.GameDataEvent;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.ludo_game.ludo.LudoState;
import com.w3engineers.theme.util.helper.AndroidUtil;
import com.w3engineers.theme.util.helper.Constant;
import com.w3engineers.theme.util.helper.ImageProcessingUtil;
import com.w3engineers.theme.util.helper.ImageSaver;
import com.w3engineers.theme.util.lib.GSonHelper;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetDataType;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetGameDataType;
import com.w3engineers.theme.util.lib.internet.model.DataModel;
import com.w3engineers.theme.util.lib.internet.model.GameDataModel;
import com.w3engineers.theme.util.lib.internet.model.GameSettingsModel;
import com.w3engineers.theme.util.lib.internet.model.ImageFileNameModel;
import com.w3engineers.theme.util.lib.internet.model.InvitationModel;
import com.w3engineers.theme.util.lib.nearby.InvitationPacketType;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;


public class ConnectivityInternetProvider {
    public enum ConnectionRole {
        HOST,
        CLIENT
    }

    private Socket mSocket;
    private static final String TAG = "InternetProvider";
    private static volatile ConnectivityInternetProvider sConnectivityProvider = null;
    private Boolean isConnected = false;

    /**
     * Our ConnectionClient object used as a handle of near P2P_STAR by apis
     */
    // private ConnectionsClient mConnectionsClient;

    private final Map<String, Player> disCoveredEndPoints = new HashMap<>();
    private final Map<String, Player> mPendingConnections = new HashMap<>();
    private final Map<String, Player> mConnectedEndPoints = new HashMap<>();

    private final Map<String, Player> otherSpokes = new HashMap<>();
    private Handler handler = new Handler();
    private static final Object locker = new Object();

    private String mNetworkName;
    private boolean isDiscoverying = false;
    private boolean isAdvertising = false;

    private ConnectionRole currentRole = ConnectionRole.CLIENT;
    private Context mContext;
    private Player hostEndpoint = null;

    public Player getHostEndpoint() {
        return hostEndpoint;
    }

    public void setHostEndpoint(Player hostEndpoint) {
        this.hostEndpoint = hostEndpoint;
    }

    /**
     * Initialization of the socket
     */
    public ConnectivityInternetProvider() {
        try {
            if (Constants.Remote.BASE_URL.contains("http"))
            mSocket = IO.socket(Constants.Remote.BASE_URL);
        } catch (URISyntaxException e) {
        }
    }

    public static ConnectivityInternetProvider getConnectivity() {
        ConnectivityInternetProvider temp = sConnectivityProvider;
        if (temp == null) {
            synchronized (locker) {
                temp = sConnectivityProvider;        // thread may have instantiated the object.
                if (temp == null) {
                    temp = new ConnectivityInternetProvider();
                    sConnectivityProvider = temp;
                }
            }
        }
        return sConnectivityProvider;
    }


    public void setCurrentRole(Context context, ConnectionRole role) {
        this.mContext = context;
        this.currentRole = role;
    }

    public ConnectionRole getCurrentRole() {
        return this.currentRole;
    }

    public void startFindingOnlinePlayer(Context context, ConnectionRole role) {
        setCurrentRole(context, role);
        disconnectFromAllEndpoints();
        createSocketConnection();
    }

    private void createSocketConnection() {
        try {
            mSocket.on(Socket.EVENT_CONNECT, onConnect);
            mSocket.on(Socket.EVENT_DISCONNECT, onDisconnect);
            mSocket.on(Socket.EVENT_CONNECT_ERROR, onConnectError);
            //  mSocket.on(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);
            mSocket.on(Constants.RemoteKeys.LOGIN, onLogin);
            mSocket.on(Constants.RemoteKeys.NEW_MESSAGE, onNewMessage);
            mSocket.on(Constants.RemoteKeys.USER_JOINED, onUserJoined);
            mSocket.on(Constants.RemoteKeys.USER_LEFT, onUserLeft);
            mSocket.connect();
        }catch (Exception e){
           e.printStackTrace();
        }
    }


    private Emitter.Listener onConnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.e(TAG, "connected with socket");
            if (!isConnected) {
                if (currentRole == ConnectivityInternetProvider.ConnectionRole.HOST){
                    mSocket.emit(Constants.RemoteKeys.ADD_USER, getSelfName(), GameDataHelper.getUserInfo().getId(), Constants.RemoteKeys.HOST);
                }else {
                    mSocket.emit(Constants.RemoteKeys.ADD_USER, getSelfName(), GameDataHelper.getUserInfo().getId(), Constants.RemoteKeys.CLIENT);
                }
                isConnected = true;
            }
        }
    };

    private Emitter.Listener onLogin = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            int numUsers;
            String userid;
            List<Player> connectedPlayerList = new ArrayList<>();

            try {
                JSONObject data = (JSONObject) args[0];
                userid = data.getString("userid");
                numUsers = data.getInt("numUsers");
                //Iterating the contents of the array
                JSONArray jsonarray = data.getJSONArray("employees");
                for (int i = 0; i < jsonarray.length(); i++) {
                    JSONObject jsonobject = jsonarray.getJSONObject(i);
                    String userId = jsonobject.getString("userId");
                    String name = jsonobject.getString("name");
                    String role = jsonobject.getString("role");
                    connectedPlayerList.add(GSonHelper.fromJson(jsonobject.toString(), Player.class));

                    Log.e(TAG, "onLogin : " + "name: " + name + " role: " + role);
                }

                for (Player player : connectedPlayerList) {
                    Log.e(TAG, "userName from list:" + player.getName());
                    if (!player.getUserId().equalsIgnoreCase(userid)) {
                        connectedToEndpoint(player);
                    }
                }
            } catch (JSONException e) {
                return;
            }

            Log.e(TAG, "onLogin : " + numUsers + ": user Id :" + userid);
            //   SharedPref.write(PreferenceKey.INTERNET_USER_ID, userid);
        }
    };

    private Emitter.Listener onDisconnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.e(TAG, "diconnected from socket");
            isConnected = false;
        }
    };

    private Emitter.Listener onConnectError = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.e(TAG, "Error connecting");
            isConnected = false;
        }
    };

    private Emitter.Listener onUserJoined = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {

            String username;
            int numUsers;
            String userId;
            String role;
            try {
                JSONObject data = (JSONObject) args[0];
                username = data.getString("username");
                userId = data.getString("userid");
                role = data.getString("role");
                numUsers = data.getInt("numUsers");

                Log.e(TAG, userId + " : " + username + " : " + numUsers);

            } catch (JSONException e) {
                Log.e(TAG, e.getMessage());
                return;
            }

            Player player = new Player();
            player.setUserId(userId);
            player.setName(username);
            player.setRole(role);

            connectedToEndpoint(player);

        }
    };

    private Emitter.Listener onUserLeft = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            String username;
            String userId;
            int numUsers;
            String role;
            try {
                JSONObject data = (JSONObject) args[0];
                username = data.getString("username");
                userId = data.getString("userid");
                role = data.getString("role");
                numUsers = data.getInt("numUsers");

                Player player = new Player();
                player.setUserId(userId);
                player.setName(username);
                player.setRole(role);

                mConnectedEndPoints.remove(player.getUserId());
                InternetConnectionEvent internetConnectionEvent = new InternetConnectionEvent
                        (InternetConnectionEvent.ConnectionType.DISCONNECTED, player);
                EventBus.getDefault().post(internetConnectionEvent);

            } catch (JSONException e) {
                Log.e(TAG, e.getMessage());
                return;
            }

            Log.e(TAG, "username has left game");
        }
    };


    /**
     * Sends a {@link Payload} to specified connected endpoint.
     *
     * @param payload The data you want to send.
     */
    protected void send(String payload) {
        // perform the sending message attempt.
        mSocket.emit("new_message", payload);
    }


    private void handleIncomingInvitationPackets(Player player, InvitationModel invitationModel) {
        InternetInvitationEvent internetInvitationEvent;

        switch (invitationModel.getInternetInvitationType()) {
            case INVITE:
                internetInvitationEvent = new InternetInvitationEvent(InvitationPacketType.INVITE, invitationModel.getPlayerList(), player);
                EventBus.getDefault().post(internetInvitationEvent);
                break;

            case ACCEPT:
                internetInvitationEvent = new InternetInvitationEvent(InvitationPacketType.ACCEPT, invitationModel.getPlayerList(), player);
                EventBus.getDefault().post(internetInvitationEvent);
                break;

            case DECLINE:
                internetInvitationEvent = new InternetInvitationEvent(InvitationPacketType.DECLINE, player);
                EventBus.getDefault().post(internetInvitationEvent);
                break;

            case UPDATE_ACCEPT:
                player = invitationModel.getPlayer();
                otherSpokes.put(player.getUserId(), player);
                internetInvitationEvent = new InternetInvitationEvent(InvitationPacketType.UPDATE_ACCEPT, player);
                EventBus.getDefault().post(internetInvitationEvent);
                break;

            case MESH_PLAYER_INFO:
                List<Player> endPoints = invitationModel.getPlayerList();
                for (Player e : endPoints) {
                    otherSpokes.put(e.getUserId(), e);
                }
                internetInvitationEvent = new InternetInvitationEvent(InvitationPacketType.MESH_PLAYER_INFO, endPoints);
                EventBus.getDefault().post(internetInvitationEvent);
                break;

            case PLAYER_DISCONNECTED:
                player = invitationModel.getPlayer();
                internetInvitationEvent = new InternetInvitationEvent(InvitationPacketType.PLAYER_DISCONNECTED, player);
                EventBus.getDefault().post(internetInvitationEvent);
                break;

            case PLAYER_REMOVED:  // this is called to acknowledge other player remove from host
                player = invitationModel.getPlayer();
                internetInvitationEvent = new InternetInvitationEvent(InvitationPacketType.PLAYER_REMOVED, player);
                EventBus.getDefault().post(internetInvitationEvent);
                break;

            case REMOVED: // this is used to acknowledge self player remove
                internetInvitationEvent = new InternetInvitationEvent(InvitationPacketType.REMOVED, player);
                EventBus.getDefault().post(internetInvitationEvent);
                break;

            case READY_TO_PLAY:
                internetInvitationEvent = new InternetInvitationEvent(InvitationPacketType.READY_TO_PLAY, invitationModel.getPlayerList());
                Player hostPlayer = mConnectedEndPoints.get(player.getUserId());
                if (hostPlayer != null) {
                    hostEndpoint = hostPlayer;
                }
                EventBus.getDefault().post(internetInvitationEvent);
                break;

            case READY_TO_PLAY_ACK:
                internetInvitationEvent = new InternetInvitationEvent(InvitationPacketType.READY_TO_PLAY_ACK, invitationModel.getPlayer());
                EventBus.getDefault().post(internetInvitationEvent);
                break;

            case GAME_START:
                internetInvitationEvent = new InternetInvitationEvent(InvitationPacketType.GAME_START);
                EventBus.getDefault().post(internetInvitationEvent);
                break;
        }
    }

    private void handleUserData(ImageFileNameModel imageFilenamePacket, String fromEndPointId) {
        String imageFile = imageFilenamePacket.getImageFile();
        if (!TextUtils.isEmpty(imageFile)) {
            Bitmap bitmap = ImageProcessingUtil.decodeImage(imageFile);
            processImage(bitmap, fromEndPointId);
        }
    }


    private void processImage(Bitmap imageBitmap, String ownerEndPointId) {
        String imagePath = ImageSaver.on(mContext).saveToInternalStorage(imageBitmap, ownerEndPointId);
        if (imagePath != null) {
            if (mConnectedEndPoints.containsKey(ownerEndPointId) || otherSpokes.containsKey(ownerEndPointId)) {
                Player owner = mConnectedEndPoints.containsKey(ownerEndPointId) ? mConnectedEndPoints.get(ownerEndPointId) : otherSpokes.get(ownerEndPointId);
                InternetImageReceivedEvent imageRecievedEvent = new InternetImageReceivedEvent(owner, imagePath);
                EventBus.getDefault().post(imageRecievedEvent);
            } else {
                Log.e(TAG, "processImage: this image is not for me");
            }
        }
    }

    private Emitter.Listener onNewMessage = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            JSONObject data = (JSONObject) args[0];
            String username;
            String message;
            try {
                username = data.getString("username");
                message = data.getString("message");
            } catch (JSONException e) {
                return;
            }

            DataModel dataModel = GSonHelper.fromJson(message, DataModel.class);

            switch (dataModel.getInternetDataType()) {
                case INVITATION_DATA:
                    InvitationModel invitationModel = dataModel.getInvitationModel();
                    if (invitationModel.getReceiver() != null && invitationModel.getReceiver().equalsIgnoreCase(GameDataHelper.getUserInfo().getId())) {
                        handleIncomingInvitationPackets(dataModel.getSenderId(), invitationModel);
                    }

                    break;

                case USER_DATA:
                    ImageFileNameModel imageFilenamePacket = dataModel.getImageFileNameModel();
                    if (imageFilenamePacket.getReceiver() != null && imageFilenamePacket.getReceiver().equalsIgnoreCase(GameDataHelper.getUserInfo().getId())) {
                        handleUserData(imageFilenamePacket, dataModel.getSenderId().getUserId());
                    }

                    break;

                case GAME_SETTINGS:
                    GameSettingsModel gameSettingsModel = dataModel.getGameSettingsModel();
                    if (gameSettingsModel.getReceiver() != null && gameSettingsModel.getReceiver().equalsIgnoreCase(GameDataHelper.getUserInfo().getId())) {
                        handleInComingGameSettings(gameSettingsModel);
                    }
                    break;

                case GAME_DATA:
                    GameDataModel gameDataModel = dataModel.getGameDataModel();
                    if (gameDataModel.getReceiver() != null && gameDataModel.getReceiver().equalsIgnoreCase(GameDataHelper.getUserInfo().getId())) {
                        handleGameData(gameDataModel);
                    }
                    break;

                default:
                    break;
            }
        }
    };

    /**
     * call back for data payload transfer related events
     * like(send, recieve and progress)
     */
/*    private final PayloadCallback payloadCallback = new PayloadCallback() {
        @Override
        public void onPayloadReceived(String s, Payload payload) {
            Log.e("stuck", "onPayloadReceived ");
            Log.d(TAG, "onPayloadReceived: from " + s + "Type: " + payload.getType());
            //     Player endPoint = mConnectedEndPoints.get(s);
            //   if (endPoint != null) {
            if (payload.getType() == Payload.Type.BYTES) {
                // try {
                //    GameMessages.DataPacket dataPacket = GameMessages.DataPacket.parseFrom(payload.asBytes());
                //  gson.fromJson(json_ string, Object.class);
                DataModel dataModel = new Gson().fromJson(s, DataModel.class);
                switch (dataModel.getInternetDataType()) {
                    case INVITATION_DATA:
                        InvitationModel invitationModel = dataModel.getInvitationModel();
                        handleIncomingInvitationPackets(dataModel.getSenderId(), invitationModel);
                        break;

                    case USER_DATA:
                        ImageFileNameModel imageFilenamePacket = dataModel.getImageFileNameModel();
                        handleUserData(imageFilenamePacket, s);
                        break;

                    case GAME_SETTINGS:
                        GameSettingsModel gameSettingsModel = dataModel.getGameSettingsModel();
                        handleInComingGameSettings(gameSettingsModel);
                        break;

                    case GAME_DATA:
                        handleGameData(dataModel.getGameDataModel());
                        break;

                    default:
                        break;
                }
                  *//*  } catch (InvalidProtocolBufferException e) {
                        e.printStackTrace();
                    }*//*

            } else if (payload.getType() == Payload.Type.FILE) {
                incomingPayloads.put(payload.getId(), payload);
            }

            //   }
        }

        @Override
        public void onPayloadTransferUpdate(String s, PayloadTransferUpdate payloadTransferUpdate) {
            Log.d(TAG, "onPayloadTransferUpdate: " + s);
            if (payloadTransferUpdate.getStatus() == PayloadTransferUpdate.Status.SUCCESS) {
                long payloadId = payloadTransferUpdate.getPayloadId();
                Log.d(TAG, "onPayloadTransferUpdate: payloadId: " + payloadId);
                Payload payload = incomingPayloads.remove(payloadId);
                completedPayloads.put(payloadId, payload);
                if (payload != null && payload.getType() == Payload.Type.FILE) {
                    processImage(payloadId, s);

                }
            } else if (payloadTransferUpdate.getStatus() == PayloadTransferUpdate.Status.FAILURE
                    || payloadTransferUpdate.getStatus() == PayloadTransferUpdate.Status.CANCELED) {
            }
        }
    };*/
    private void handleGameData(GameDataModel gameDataModel) {

        if (gameDataModel.getInternetGameDataType() == InternetGameDataType.GAME_ACTION) {
            Log.e("stuck", "Test test");
            GameActionEvent gameActionEvent = new Gson().fromJson(gameDataModel.getData(), GameActionEvent.class);
            Log.e("stuck", "Test test " + gameActionEvent.getAction());
            EventBus.getDefault().post(new GameDataEvent(gameActionEvent, false));

        } else {
            Log.e("stuck", "else Test test");
            LudoState ludoState = new Gson().fromJson(gameDataModel.getData(), LudoState.class);
            Log.e("stuck", "else Test test " + ludoState.getAction());
            EventBus.getDefault().post(new GameDataEvent(ludoState, true));
        }
    }

    private void handleInComingGameSettings(GameSettingsModel gameSettingsModel) {
        InternetGameSettingsEvent internetGameSettingsEvent = new InternetGameSettingsEvent(gameSettingsModel.getInternetGameModeType());
        EventBus.getDefault().post(internetGameSettingsEvent);
    }

    /**
     * end point is connected
     * send update to app layer via EventBus
     *
     * @param player
     */
    public void connectedToEndpoint(Player player) {
        if (currentRole == ConnectivityInternetProvider.ConnectionRole.CLIENT && player.getRole() == Constants.RemoteKeys.HOST) {
            hostEndpoint = player;
        }

        mConnectedEndPoints.put(player.getUserId(), player);
        InternetConnectionEvent internetConnectionEvent = new InternetConnectionEvent
                (InternetConnectionEvent.ConnectionType.CONNECTED, player);

        EventBus.getDefault().post(internetConnectionEvent);

        Log.d(TAG, "connectedToEndpoint: " + GameDataHelper.getUserInfo().getImagePath());

        Player imageOwner = new Player(GameDataHelper.getUserInfo().getId(), GameDataHelper.getUserInfo().getId(), GameDataHelper.getUserInfo().getName(), GameDataHelper.getUserInfo().getImagePath(), Player.Type.PROXY_PLAYER);
        startSendingImage(player, imageOwner, GameDataHelper.getUserInfo().getImagePath());
    }

    public void startSendingImage(String endPointId, Player imageOwner, String imagePath) {
        if (mConnectedEndPoints.containsKey(endPointId)) {
            startSendingImage(mConnectedEndPoints.get(endPointId), imageOwner, imagePath);
        }
    }

    public void startSendingImage(Player destinationEndpoint, Player
            imageOwner, String imagePath) {

        if (!TextUtils.isEmpty(imagePath)) {
            ImageFileNameModel imageFileNameModel = new ImageFileNameModel();
            imageFileNameModel.setImageFile(ImageProcessingUtil.encodeImage(imagePath));
            imageFileNameModel.setReceiver(destinationEndpoint.getUserId());

            DataModel dataModel = new DataModel();
            dataModel.setImageFileNameModel(imageFileNameModel);
            dataModel.setInternetDataType(InternetDataType.USER_DATA);
            dataModel.setSenderId(imageOwner);

            send(new Gson().toJson(dataModel));
        }
    }


    /**
     * disconnected to endpoint
     * send update to app layer via EventBus
     *
     * @param endPoint
     */
    private void disconnectedFromEndpoint(Player endPoint) {
        Log.e(TAG, String.format("disconnectedFromEndpoint(endpoint=%s)", endPoint));
        mConnectedEndPoints.remove(endPoint.getEndPointId());
        InternetConnectionEvent nearbyConnectionEvent = new InternetConnectionEvent
                (InternetConnectionEvent.ConnectionType.DISCONNECTED, endPoint);
        EventBus.getDefault().post(nearbyConnectionEvent);
    }

    public void onConnectionFailed(Player endpoint) {

    }

    /**
     * callbacks for all the connection related events like(initiate, success, fail)
     */
/*    private final ConnectionLifecycleCallback mConnectionLifecycleCallback = new ConnectionLifecycleCallback() {
        @Override
        public void onConnectionInitiated(String endPointId, ConnectionInfo connectionInfo) {
            Log.d(TAG, "onConnectionInitiated: from " + endPointId + " " + connectionInfo.getEndpointName());
    *//*        EndPoint endPoint = EndPoint.newBuilder().setEndPointId(endPointId)
                    .setEndPointName(connectionInfo.getEndpointName())
                    .build();*//*
            Player player = new Player();
            player.setEndPointId(endPointId);
            player.setName(connectionInfo.getEndpointName());

            onNearbyConnectionInitiated(player, connectionInfo);
        }


        @Override
        public void onConnectionResult(String endPointId, ConnectionResolution connectionResolution) {
            Player endpoint = mPendingConnections.remove(endPointId);
            if (endpoint != null) {
                if (connectionResolution.getStatus().isSuccess()) {
                    connectedToEndpoint(endpoint);
                } else {
                    onConnectionFailed(endpoint);
                    return;
                }
            }
        }

        @Override
        public void onDisconnected(String endPointId) {
            Log.e(TAG, "onDisconnected: " + endPointId);
            if (!mConnectedEndPoints.containsKey(endPointId)) {
                Log.e(TAG, "Unexpected disconnection from endpoint " + endPointId);
                return;
            }
            disconnectedFromEndpoint(mConnectedEndPoints.get(endPointId));
        }
    };*/


    /**
     * method to send request connection to discovered endpoint.
     *
     * @param endPointId
     * @param discoveredEndpointInfo
     */
    private void requestConnection(String endPointId, DiscoveredEndpointInfo discoveredEndpointInfo) {

        if (mPendingConnections.containsKey(endPointId) || mConnectedEndPoints.containsKey(endPointId)) {
            Log.e(TAG, "onEndpointFound: return this end point already has connection");
            return;
        }
        stopDiscovery();
        if (getServiceId().equals(discoveredEndpointInfo.getServiceId())) {
  /*          EndPoint endPoint = EndPoint.newBuilder()
                    .setEndPointId(endPointId)
                    .setEndPointName(discoveredEndpointInfo.getEndpointName())
                    .build();*/

            Player player = new Player();
            player.setEndPointId(endPointId);
            player.setName(discoveredEndpointInfo.getEndpointName());


            disCoveredEndPoints.put(endPointId, player);

/*            mConnectionsClient.requestConnection(getSelfName()
                    , endPointId
                    , mConnectionLifecycleCallback
            ).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.d(TAG, "onSuccess: request connection");
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "run: after onsuccess!");
                            startDiscovery();
                        }
                    }, 2000);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.e(TAG, "onFailure: request connection");
                    e.printStackTrace();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "run: after onFailure!");
                            startDiscovery();
                        }
                    }, 2000);

                }
            });*/
        }
    }


    /**
     * method to get profile name
     *
     * @return profile name set in the welcome screen
     */
    private String getSelfName() {
        return GameDataHelper.getUserInfo().getName();
    }

    /**
     * @return serviceId (we are using packagename)
     */
    public String getServiceId() {
        return AndroidUtil.getApplicationId(LudoSixApp.getContext()) + mNetworkName;
//        return "LudoTestNetwork" + mNetworkName;
    }

    public void setNetworkName(String mNetworkName) {
        this.mNetworkName = mNetworkName;
    }

    public String getNetworkName() {
        return mNetworkName;
    }

    /**
     * Sets the device to advertising mode. It will broadcast to other devices in discovery mode.
     * Either {@link #onAdvertisingStarted()} or {@link #onAdvertisingFailed()} will be called once
     * we've found out if we successfully entered this mode.
     */


    private void onAdvertisingStarted() {

    }

    private void onAdvertisingFailed() {

    }


    protected void onDiscoveryStarted() {

    }

    protected void onDiscoveryFailed() {

    }


    /**
     * Stop the device from being in discovery mode
     */
    private void stopDiscovery() {
        Log.e(TAG, "stopDiscovery: ");
      /*  if (mConnectionsClient != null && isDiscoverying) {
            mConnectionsClient.stopDiscovery();
            isDiscoverying = false;
        }
*/
    }

    /**
     * Disconnects from all currently connected endpoints.
     */
    protected void disconnectFromAllEndpoints() {
     /*   for (Player endpoint : mConnectedEndPoints.values()) {
              mConnectionsClient.disconnectFromEndpoint(endpoint.getEndPointId());
        }*/
        mConnectedEndPoints.clear();
    }

    /**
     * Resets and clears all state in Nearby Connections.
     */
    public void stopAllEndpoints() {

        disCoveredEndPoints.clear();
        mPendingConnections.clear();
        mConnectedEndPoints.clear();

        isConnected = false;

        if (mSocket !=null){
            mSocket.disconnect();
            mSocket.off(Socket.EVENT_CONNECT, onConnect);
            mSocket.off(Socket.EVENT_DISCONNECT, onDisconnect);
            mSocket.off(Socket.EVENT_CONNECT_ERROR, onConnectError);
            mSocket.off(Constants.RemoteKeys.LOGIN, onLogin);
            mSocket.off(Constants.RemoteKeys.NEW_MESSAGE, onNewMessage);
            mSocket.off(Constants.RemoteKeys.USER_JOINED, onUserJoined);
            mSocket.off(Constants.RemoteKeys.USER_LEFT, onUserLeft);
        }
    }
}
