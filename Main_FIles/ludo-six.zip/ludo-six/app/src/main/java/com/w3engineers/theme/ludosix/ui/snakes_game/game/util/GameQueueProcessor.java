package com.w3engineers.theme.ludosix.ui.snakes_game.game.util;

import java.util.LinkedList;
import java.util.Queue;

import com.w3engineers.theme.ludosix.ui.snakes_game.game.Game;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.actionMsg.GameAction;
import com.w3engineers.theme.util.helper.HandlerUtil;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 2/4/2019 at 6:30 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Executes the received actions in queue
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 2/4/2019.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 2/4/2019.
 * Copyright (c) 2019, W3 Engineers Ltd. All rights reserved.
 */
public class GameQueueProcessor {

    private static final int DATA_PROCESS_DELAY = 30;
    private Game game;
    private boolean isProcessing;

    private Queue<GameAction> gameActionList = new LinkedList<>();
    private static GameQueueProcessor sGameQueueProcessor = new GameQueueProcessor();

    private GameQueueProcessor() {
    }

    public static GameQueueProcessor getInstance() {
        return sGameQueueProcessor;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;

        gameActionList.clear();
        isProcessing = false;
    }

    public void addEvent(GameAction gameAction) {
        gameActionList.add(gameAction);
        processQueue();
    }

    private void processQueue() {

        if (!isProcessing && !gameActionList.isEmpty()) {
            GameAction gameAction = gameActionList.remove();

            gameActionList.remove(gameAction);
            isProcessing = true;

            HandlerUtil.postBackground(() -> {
                // Call forceProcessQueue properly after this
                game.sendAction(gameAction);

            }, DATA_PROCESS_DELAY);
        }
    }

    public void forceProcessQueue() {
        isProcessing = false;
        processQueue();
    }
}
