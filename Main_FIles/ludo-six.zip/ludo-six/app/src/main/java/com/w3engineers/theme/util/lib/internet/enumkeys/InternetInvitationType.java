package com.w3engineers.theme.util.lib.internet.enumkeys;

public enum InternetInvitationType {
    INVITE,
    ACCEPT,
    DECLINE,
    REMOVED,
    UPDATE_ACCEPT,
    MESH_PLAYER_INFO,
    PLAYER_DISCONNECTED,
    PLAYER_REMOVED,
    GAME_START,
    READY_TO_PLAY,
    READY_TO_PLAY_ACK
}


