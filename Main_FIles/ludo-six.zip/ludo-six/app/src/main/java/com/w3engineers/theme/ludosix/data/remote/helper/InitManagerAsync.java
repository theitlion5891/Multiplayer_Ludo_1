package com.w3engineers.theme.ludosix.data.remote.helper;

import android.content.Context;
import android.os.AsyncTask;

import com.w3engineers.theme.ludosix.R;
import com.w3engineers.theme.ludosix.data.remote.parseapi.ParseManager;
//import com.w3engineers.theme.ludosix.data.remote.rightmeshapi.RMManager;
import com.w3engineers.theme.ludosix.data.remote.s3api.S3Manager;
import com.w3engineers.theme.ludosix.data.remote.thundercharmapi.TCharmManager;

/**
 * * ============================================================================
 * * Copyright (C) 2018 W3 Engineers Ltd - All Rights Reserved.
 * * Unauthorized copying of this file, via any medium is strictly prohibited
 * * Proprietary and confidential
 * * ----------------------------------------------------------------------------
 * * Created by: Sudipta K Paik on [19-Jul-2018 at 7:01 PM].
 * * Email: sudipta@w3engineers.com
 * * ----------------------------------------------------------------------------
 * * Project: Generic API.
 * * Code Responsibility: <Purpose of code>
 * * ----------------------------------------------------------------------------
 * * Edited by :
 * * --> <First Editor> on [19-Jul-2018 at 7:01 PM].
 * * --> <Second Editor> on [19-Jul-2018 at 7:01 PM].
 * * ----------------------------------------------------------------------------
 * * Reviewed by :
 * * --> <First Reviewer> on [19-Jul-2018 at 7:01 PM].
 * * --> <Second Reviewer> on [19-Jul-2018 at 7:01 PM].
 * * ============================================================================
 **/

public class InitManagerAsync extends AsyncTask<Void, Void, Void> {
    private Context mContext;
    private RemoteApiOption mRemoteApiOption;

    public InitManagerAsync(Context context, RemoteApiOption remoteApiOption) {
        mContext = context;
        mRemoteApiOption = remoteApiOption;

        if (mRemoteApiOption == null)
            mRemoteApiOption = new RemoteApiOption(true);
    }

    @Override
    protected Void doInBackground(Void... voids) {

        if (mRemoteApiOption.isStartTCharm())
            TCharmManager.init(mContext);

        if (mRemoteApiOption.isStartS3())
            S3Manager.init(mContext);

        if (mRemoteApiOption.isStartParse())
            ParseManagerInit();

        return null;
    }

    private void ParseManagerInit() {
        String serverUrl = mContext.getString(R.string.parseServerUrl);
        String appId = mContext.getString(R.string.parseAppId);
        String clientKey = mContext.getString(R.string.parseClientKey);

        ParseManager.init(mContext, serverUrl, appId, clientKey);
    }
}