package com.w3engineers.theme.ludosix.ui.connectivity_selection;

import com.w3engineers.theme.ludosix.ui.base.MvpView;

public interface ConnectivitySelectionMvpView extends MvpView {
}
