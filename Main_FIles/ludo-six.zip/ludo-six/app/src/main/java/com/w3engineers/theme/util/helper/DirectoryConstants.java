package com.w3engineers.theme.util.helper;

import android.os.Environment;

import java.io.File;

/*
*  ****************************************************************************
*  * Created by : Ahmed Mohmmad Ullah (Azim) process 10/17/2017 at 10:29 AM.
*  * Email : azim@w3engineers.com
*  * 
*  * Last edited by : Ahmed Mohmmad Ullah (Azim) process 10/17/2017.
*  * 
*  * Last Reviewed by : <Reviewer Name> process <mm/dd/yy>
*  ****************************************************************************
*/
public interface DirectoryConstants {

    String EXTERNAL_STORAGE_DIRECTORY = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator;
    String AVATAR_DIRECTORY = EXTERNAL_STORAGE_DIRECTORY + "/MyApp/.avatar/";
    String FILE_DIRECTORY = EXTERNAL_STORAGE_DIRECTORY + "/MyApp/file/";
    String THUMB_DIRECTORY = EXTERNAL_STORAGE_DIRECTORY + "/MyApp/.thumb/";
    String ROOT_DIRECTORY = EXTERNAL_STORAGE_DIRECTORY + "/MyApp/";
    String PHOTO_DIRECTORY = EXTERNAL_STORAGE_DIRECTORY + "/MyApp/image/";
    String VOICE_DIRECTORY = EXTERNAL_STORAGE_DIRECTORY + "/MyApp/voice/";
    String TEMP_DIRECTORY = EXTERNAL_STORAGE_DIRECTORY + "/MyApp/.temp/";
    String CAMERA_DIRECTORY = EXTERNAL_STORAGE_DIRECTORY + "/MyApp/capture/";

            String
    MY_AVATAR_LARGE ="my_profile_large.jpg";
    String MY_AVATAR_THUMB = "my_profile_thumb.jpg";
    String IMAGE = "MyApp_IMG";
    String VOICE = "MyApp_VOICE";

}
