package com.w3engineers.theme.ludosix.ui.home;

import com.left.core.util.lib.nearby.GameMessages;

import java.util.List;

import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.base.MvpView;

/**
 * Created by: MD. REZWANUR RAHMAN KHAN on 11/13/2018 at 3:38 PM.
 * Email: rezwanur@w3engineers.com
 * Code Responsibility: Model class for player
 * Last edited by : MD. REZWANUR RAHMAN KHAN on 11/13/2018.
 * Last Reviewed by : MD. REZWANUR RAHMAN KHAN on 11/13/2018.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */
public interface HomeMvpView extends MvpView {

    void onNearbyDeviceConnected(Player player);

    void onNearbyDeviceDisconnected(Player player);

    void onInvitationReceived(Player requestedByPlayer, Player selfPlayer);

    void onInvitationAcceptByPeer(Player acceptedByPlayer, Player selfPlayer);

    void onInvitationRejectByPeer(Player player);

    void onNewPeerAccepted(Player player);

    void onProfilePicReceived(Player player, String imagePath);

    void onMeshPlayerInfoReceived(List<Player> players);

    void onGameModeDataChanged(GameMessages.GameSettingsPacket.GameMode gameMode);

    void onOtherPlayerDisconnected(Player player);

    void onPlayerRemovedByHost(Player player);

    void onReadyToPlayMessage(List<Player> players);

    void onGameStartedByHost();

    void onReadyToPlayAckMessage(Player player);

    void onRemoved();
}