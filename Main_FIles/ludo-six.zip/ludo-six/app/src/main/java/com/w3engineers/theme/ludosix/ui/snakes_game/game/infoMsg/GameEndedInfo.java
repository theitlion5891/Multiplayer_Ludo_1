package com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg;

/**
 * A message from the game to a player that tells the player that
 * the game is over.
 *
 * @author Steven R. Vegdahl
 * @version July 2013
 */
public class GameEndedInfo extends GameInfo {

    // to satisfy the Serializable interface
    private static final long serialVersionUID = -8005304466588509849L;

    // the message that gives the game's result
    private int winnerPlayerNum;

    /**
     * constructor
     *
     * @param winnerPlayerNum a message that tells the result of the game
     */
    public GameEndedInfo(int winnerPlayerNum) {
        this.winnerPlayerNum = winnerPlayerNum;
    }

    /**
     * getter method for the message
     *
     * @return the message, telling the result of the game
     */
    public int getWinnerPlayerNum() {
        return winnerPlayerNum;
    }
}
