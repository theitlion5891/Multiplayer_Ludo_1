package com.w3engineers.theme.util.helper.internetdada;

import android.content.Context;

public class RemoteRepo {

    public RemoteRepo() {
    }

    /**
     * This API is used to book token
     *
     * @param authToken
     * @param queueNo
     */

    public void bookToken(String authToken, long queueNo) {
       /* BookTokenService service = RetrofitClientInstance.getRetrofitInstance().create(BookTokenService.class);

        Call<ResponseBody> result = service.getToken("Bearer " + authToken, queueNo);
        final String[] responseResult = new String[1];

        result.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                //     Log.e("response_token", "Response: book token " + response.body().toString());
                if (response.code() == Constants.Status.status_200) {
                    try {
                        responseResult[0] = response.body().string();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    JSONObject jsonObject = null;
                    try {
                        jsonObject = new JSONObject(responseResult[0]);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    //JSONObject jsonObject = response.body().string();
                    Log.e("response_token", "Response:mom " + jsonObject.toString());

                    TokenEntity tokenEntity = new TokenEntity();
                    try {
                        //   String status = jsonObject.has(Constants.JsonKeys.STATUS) ? jsonObject.getString(Constants.JsonKeys.STATUS) : "";
                        JSONObject data = jsonObject.has(Constants.JsonKeys.DATA) ? jsonObject.getJSONObject(Constants.JsonKeys.DATA) : null;
                        if (data != null) {

                            int ticketId = data.has(Constants.JsonKeys.ID) ? data.getInt(Constants.JsonKeys.ID) : 0;
                            String tickName = data.has(Constants.JsonKeys.TICKET_NO) ? data.getString(Constants.JsonKeys.TICKET_NO) : "";
                            String createdDate = data.has(Constants.JsonKeys.CREATED_AT) ? data.getString(Constants.JsonKeys.CREATED_AT) : "";
                            String updatedDate = data.has(Constants.JsonKeys.UPDATED_AT) ? data.getString(Constants.JsonKeys.UPDATED_AT) : "";
                            String customerCount = data.has(Constants.JsonKeys.CUSTOMER_COUNT) ? data.getString(Constants.JsonKeys.CUSTOMER_COUNT) : "";
                            String department = data.has(Constants.JsonKeys.SERVICE_NAME) ? data.getString(Constants.JsonKeys.SERVICE_NAME) : "";
                            String averageWaitingTime = data.has(Constants.JsonKeys.AVG_WAITING_TIME) ? data.getString(Constants.JsonKeys.AVG_WAITING_TIME) : "";

                            long estimatedWaitingTime = data.has(Constants.JsonKeys.ESTIMATED_WAITING_TIME) ? data.getLong(Constants.JsonKeys.ESTIMATED_WAITING_TIME) : 0;

                            String company = data.has(Constants.JsonKeys.COMPANY) ? data.getString(Constants.JsonKeys.COMPANY) : "";
                            String branch = data.has(Constants.JsonKeys.BRANCH) ? data.getString(Constants.JsonKeys.BRANCH) : "";

                            String customerId = data.has(Constants.JsonKeys.CUSTOMER_ID) ? data.getString(Constants.JsonKeys.CUSTOMER_ID) : "";

                            //   String nowServing = data.has(Constants.JsonKeys.NOW_SERVING) ? data.getString(Constants.JsonKeys.NOW_SERVING) : "";

                            int resolution = data.has(Constants.JsonKeys.RESOLUTION) ? data.getInt(Constants.JsonKeys.RESOLUTION) : 0;

                            JSONArray nowServing = data.has(Constants.JsonKeys.NOW_SERVING) ? data.getJSONArray(Constants.JsonKeys.NOW_SERVING) : null;

                            List<String> nowServingList = new ArrayList<>();

                            if (nowServing != null) {
                                for (int i = 0; i < nowServing.length(); i++) {
                                    nowServingList.add(nowServing.getString(i));
                                }
                            }

                            tokenEntity.setId(ticketId);
                            tokenEntity.setCustomerId(customerId);
                            tokenEntity.setCompanyName(company);
                            tokenEntity.setBranchName(branch);
                            tokenEntity.setTicket_name(tickName);
                            tokenEntity.setCreatedDate(createdDate);
                            tokenEntity.setUpdatedDate(updatedDate);
                            tokenEntity.setWaitingNumber(customerCount);
                            tokenEntity.setDepartMent(department);
                            tokenEntity.setAvgWaitingTime(averageWaitingTime);
                            tokenEntity.setEstimatedWaitingTime(estimatedWaitingTime);
                            tokenEntity.setNowServing(nowServingList);
                            tokenEntity.setResolution(resolution);

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    if (callback != null) {
                        callback.onBookToken(true, response.code(), tokenEntity);
                    }

                } else {
                    Log.e("response", "Response: code: " + response.code());
                    if (callback != null) {
                        callback.onBookToken(false, response.code(), null);
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                if (t instanceof IOException) {
                    // No internet connection
                    if (callback != null) {
                        callback.onBookToken(false, Constants.Status.status_100, null);
                    }
                } else {
                    if (callback != null) {
                        callback.onBookToken(false, 0, null);
                    }
                }
            }
        }); */
    }
}