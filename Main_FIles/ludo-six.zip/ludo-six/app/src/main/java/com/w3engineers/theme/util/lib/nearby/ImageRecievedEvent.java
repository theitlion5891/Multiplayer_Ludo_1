package com.w3engineers.theme.util.lib.nearby;

import com.left.core.util.lib.nearby.GameMessages;

/**
 * Created by pl@b0n on 11/27/2018.
 */
public class ImageRecievedEvent {
    GameMessages.EndPoint endPoint;
    String imagePath;

    public ImageRecievedEvent(GameMessages.EndPoint endPoint, String imagePath) {
        this.endPoint = endPoint;
        this.imagePath = imagePath;
    }

    public GameMessages.EndPoint getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(GameMessages.EndPoint endPoint) {
        this.endPoint = endPoint;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}
