package com.w3engineers.theme.ludosix.ui.ludo_game.ludo;

import com.w3engineers.theme.ludosix.ui.ludo_game.game.GamePlayer;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.actionMsg.GameAction;

/**
 * ActionMoveToken class
 * Game action that is sent to LudoLocalgame
 */
public class ActionAnimateToken extends GameAction {

    private int index;
    private int count;

    /**
     * constructor for GameAction
     *
     * @param player the player who created the action
     * @param index  index of piece
     */
    public ActionAnimateToken(GamePlayer player, int index, int count) {
        super(player);
        this.index = index;
        this.count = count;
    }


    /**
     * getter method for index of piece
     *
     * @return the index
     */
    public int getIndex() {
        return this.index;
    }

    public int getCount() {
        return this.count;
    }
}
