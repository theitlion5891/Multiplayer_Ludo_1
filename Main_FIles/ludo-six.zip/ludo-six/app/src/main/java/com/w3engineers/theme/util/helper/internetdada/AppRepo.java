package com.w3engineers.theme.util.helper.internetdada;

import android.content.Context;


public class AppRepo {
    private static RemoteRepo mRemoteRepo = null;

    private static volatile AppRepo ourInstance;

    private AppRepo() {
        mRemoteRepo = new RemoteRepo();
    }

    public synchronized static void init(Context context) {
        if (ourInstance == null) {
            synchronized (AppRepo.class) {

                if (ourInstance == null)
                    ourInstance = new AppRepo();
            }
        }
    }

    public static AppRepo on() {
        if (ourInstance == null) {

            synchronized (AppRepo.class) {

                if (ourInstance == null)
                    ourInstance = new AppRepo();
            }
        }
        return ourInstance;
    }

    public void off() {
        ourInstance = null;
    }

    public void bookToken(String authToken, long queueNo) {
        mRemoteRepo.bookToken(authToken, queueNo);
    }
}