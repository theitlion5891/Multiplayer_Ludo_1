package com.w3engineers.theme.ludosix.ui.snakes_game.snakes;

import android.util.Log;

import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.GameComputerPlayer;
import com.w3engineers.theme.ludosix.ui.snakes_game.game.infoMsg.GameInfo;

/**
 * ComputerSmartPlayer
 * This implements the smart computer player.
 *
 * @author Ravi Nayyar
 * @author Avery Guillermo
 * @author Luke Danowski
 * @author Chris Sebrechts
 */

public class ComputerSmartPlayer extends GameComputerPlayer {
    /**
     * constructor
     *
     * @param playerInfo the player's name (e.g., "John")
     */
    public ComputerSmartPlayer(Player playerInfo) {
        super(playerInfo);
    }

    @Override
    protected void receiveInfo(GameInfo info) {
        Log.i("smart computer recieve", " " + playerNum);
        // if it's not a LudoState message, ignore it; otherwise
        // cast it
        if (!(info instanceof SnakesState)) return;
        SnakesState myState = (SnakesState) info;
        // if it's not our move, ignore it
        if (myState.getWhoseMove() != this.playerNum) return;

        // sleep for 0.8 seconds to slow down the game
        sleep(800);

        //if it is the computer's turn to roll
        if (myState.getWhoseMove() == this.playerNum && myState.getIsRollable()) {
            game.sendAction(new ActionAnimateDice(this));
        }
    }

}//Smart Computer Player