package com.w3engineers.theme.util;

/*
* ****************************************************************************
* * Copyright © 2018 W3 Engineers Ltd., All rights reserved.
* *
* * Created by:
* * Name : SUDIPTA KUMAR PAIK
* * Date : 2/15/18
* * Email : sudipta@w3engineers.com
* *
* * Purpose:
* *
* * Last Edited by : SUDIPTA KUMAR PAIK on 2/15/18.
* * History:
* * 1:
* * 2:
* *
* * Last Reviewed by : SUDIPTA KUMAR PAIK on 2/15/18.
* ****************************************************************************
*/

public final class AppConstants {
    public final static int REQUEST_CHECK_SETTINGS = 534;

    private AppConstants() {
        // This utility class is not publicly instantiable
    }
}
