package com.w3engineers.theme.ludosix.ui.internet;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;

import com.left.core.util.lib.nearby.GameMessages;
import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.data.helper.keys.GameMode;
import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.data.local.model.UserInfo;
import com.w3engineers.theme.ludosix.ui.base.BasePresenter;
import com.w3engineers.theme.ludosix.ui.home.HomeActivity;
import com.w3engineers.theme.util.lib.GSonHelper;
import com.w3engineers.theme.util.lib.internet.ConnectivityInternetProvider;
import com.w3engineers.theme.util.lib.internet.InternetConnectionEvent;
import com.w3engineers.theme.util.lib.internet.InternetConnectionManager;
import com.w3engineers.theme.util.lib.internet.InternetGameSettingsEvent;
import com.w3engineers.theme.util.lib.internet.InternetImageReceivedEvent;
import com.w3engineers.theme.util.lib.internet.InternetInvitationEvent;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetGameModeType;
import com.w3engineers.theme.util.lib.internet.enumkeys.InternetInvitationType;
import com.w3engineers.theme.util.lib.nearby.ConnectionManager;
import com.w3engineers.theme.util.lib.nearby.ConnectivityProvider;
import com.w3engineers.theme.util.lib.nearby.ImageRecievedEvent;
import com.w3engineers.theme.util.lib.nearby.InvitationPacketType;
import com.w3engineers.theme.util.lib.nearby.NearbyGameSettingsEvent;
import com.w3engineers.theme.util.lib.nearby.NearbyInvitationEvent;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.sql.ConnectionEvent;

public class InternetHomePresenter extends BasePresenter<InternetHomeMvpView> {
    private static final String TAG = "InternetHomePresenter";

    public ArrayList<Player> getGamePlayers(Player player1, Player player2, Player player3, int currentGameMode, boolean isNotInAnyGame, Player mSelfPlayer) {
        ArrayList<Player> gamePlayers = new ArrayList<>();

        Player botPlayer1 = new Player("bot1", "bot1", "Com 1", "", Player.Type.BOT);
        Player botPlayer2 = new Player("bot2", "bot2", "Com 2", "", Player.Type.BOT);
        Player botPlayer3 = new Player("bot3", "bot3", "Com 3", "", Player.Type.BOT);

        if (player1 != null) {
            player1.setPlayerType(Player.Type.PROXY_PLAYER);
            player1.setHasAcknowledged(false);
        }

        if (player2 != null) {
            player2.setPlayerType(Player.Type.PROXY_PLAYER);
            player2.setHasAcknowledged(false);
        }

        if (player3 != null) {
            player3.setPlayerType(Player.Type.PROXY_PLAYER);
            player3.setHasAcknowledged(false);
        }

        switch (currentGameMode) {
            case GameMode.TWO_PLAYER:

                if (player1 != null) {
                    gamePlayers.add(player1);

                } else {
                    gamePlayers.add(botPlayer1);
                }

                break;

            case GameMode.THREE_PLAYER:
                if (player1 != null && player2 != null) {
                    gamePlayers.add(player1);
                    gamePlayers.add(player2);

                } else if (player1 != null || player2 != null) {
                    gamePlayers.add(botPlayer1);

                    if (player1 != null) {
                        gamePlayers.add(player1);
                    } else {
                        gamePlayers.add(player2);
                    }

                } else {
                    gamePlayers.add(botPlayer1);
                    gamePlayers.add(botPlayer2);
                }
                break;

            case GameMode.FOUR_PLAYER:
                if (player1 != null && player2 != null && player3 != null) {
                    gamePlayers.add(player1);
                    gamePlayers.add(player2);
                    gamePlayers.add(player3);

                } else if (player1 != null || player2 != null || player3 != null) {

                    if (player1 != null) {
                        gamePlayers.add(player1);
                    }
                    if (player2 != null) {
                        gamePlayers.add(player2);
                    }
                    if (player3 != null) {
                        gamePlayers.add(player3);
                    }
                    if (gamePlayers.size() == 1) {
                        gamePlayers.add(botPlayer1);
                        gamePlayers.add(botPlayer2);
                    }
                    if (gamePlayers.size() == 2) {
                        gamePlayers.add(botPlayer1);
                    }

                } else {
                    gamePlayers.add(botPlayer1);
                    gamePlayers.add(botPlayer2);
                    gamePlayers.add(botPlayer3);
                }
                break;
        }

        if (gamePlayers.size() > 1) {
            Collections.shuffle(gamePlayers);
        }

        for (int i = 0; i < gamePlayers.size(); i++) {
            Player player = gamePlayers.get(i);

            // If player position is 2 then shifting to position 3
            if (i == 2) {
                i += 1;
            }

            player.setPlayerPosition(i);
            player.setPlayerColor(getPlayerColor(i));
        }

        UserInfo userInfo = GameDataHelper.getUserInfo();

        // Adding self player
        if (userInfo != null) {
            Player selfPlayer = new Player(userInfo.getId(), mSelfPlayer != null ? mSelfPlayer.getUserId() : "", userInfo.getName(), userInfo.getImagePath(), Player.Type.HUMAN_LOCAL);
            selfPlayer.setPlayerPosition(2);
            selfPlayer.setPlayerColor(getPlayerColor(2));
            gamePlayers.add(selfPlayer);
        }

        if (!isNotInAnyGame) {
            if (gamePlayers.size() == 2) {
                gamePlayers.add(new Player("dummy", "dummy", "dummy", "", Player.Type.PROXY_PLAYER));
                gamePlayers.add(new Player("dummy", "dummy2", "dummy", "", Player.Type.PROXY_PLAYER));

            } else if (gamePlayers.size() == 3) {
                gamePlayers.add(new Player("dummy", "dummy", "dummy", "", Player.Type.PROXY_PLAYER));
            }
        }

        return gamePlayers;
    }

    private int getPlayerColor(int position) {

        switch (position) {
            case 0:
                return Color.RED;

            case 1:
                return Color.BLUE;

            case 2:
                return Color.YELLOW;

            case 3:
                return Color.GREEN;

            default:
                return -1;
        }
    }

    public void startFindingOnlinePlayer(Context mContext, ConnectivityInternetProvider.ConnectionRole role) {
        ConnectivityInternetProvider.getConnectivity().startFindingOnlinePlayer(mContext, role);

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    public void stopSearchingOnline() {
        ConnectivityInternetProvider.getConnectivity().stopAllEndpoints();

        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    public void acceptInvitation(Player player) {
        List<Player> endPoints = new ArrayList<>();
        endPoints.add(player);

        UserInfo userInfo = GameDataHelper.getUserInfo();
        if (userInfo != null) {
            endPoints.add(new Player(userInfo.getId(), userInfo.getId(), userInfo.getName(),
                    userInfo.getImagePath(), Player.Type.HUMAN_REMOTE, GSonHelper.toJson(GameDataHelper.getScoreBoard())));
        }

        InternetConnectionManager.sendInvitationAccept(endPoints);
    }

    public void declineInvitation(Player player) {
        InternetConnectionManager.sendInvitationDecline(player);
    }

    public void sendUpdateAccept(List<Player> players, Player newPlayer) {
        List<String> endPointIds = new ArrayList<>();
        for (Player p : players) {
            endPointIds.add(p.getUserId());
        }
        InternetConnectionManager.sendUpdateAccept(endPointIds, newPlayer);
    }

    public void sendImageUpdateToPlayers(List<Player> players, Player newPlayer) {
        List<String> endPointIds = new ArrayList<>();
        for (Player p : players) {
            endPointIds.add(p.getUserId());
        }
        if (endPointIds.size() > 0)
            InternetConnectionManager.broadCastImagesUpdate(endPointIds, newPlayer, newPlayer.getImagePath());
    }

    public void sendPayersInfoToNewPlayer(List<Player> endPoints, Player newPlayer) {
      /*  List<Player> endPoints = new ArrayList<>();
        for (Player p : players) {
            endPoints.add(p);
        }*/
        InternetConnectionManager.sendPlayersInfoToNewPlayer(endPoints, newPlayer);
    }

    public void sendInvitation(Player player) {
        if (player.getState() == Player.State.NOT_IN_GAME) {
            List<Player> endPoints = new ArrayList<>();
            endPoints.add(player);

            UserInfo userInfo = GameDataHelper.getUserInfo();
            if (userInfo != null) {
                endPoints.add(new Player(userInfo.getId(), userInfo.getId(), userInfo.getName(), userInfo.getImagePath(),
                        Player.Type.HUMAN_LOCAL, GSonHelper.toJson(GameDataHelper.getScoreBoard())));

               /* endPoints.add(mapPlayerToEndPoint(new Player(userInfo.getId(), "", userInfo.getName(), userInfo.getImagePath(),
                        Player.Type.HUMAN_LOCAL, GSonHelper.toJson(GameDataHelper.getScoreBoard()))));*/
            }

            InternetConnectionManager.sendInvitation(endPoints);
        }
    }

    private GameMessages.EndPoint mapPlayerToEndPoint(Player player) {
        return GameMessages.EndPoint.newBuilder()
                .setUserId(player.getUserId())
                .setEndPointId(player.getEndPointId())
                .setEndPointName(player.getName())
                .setImagePath(player.getImagePath())
                .setPlayerType(player.getPlayerType())
                .setPlayerPosition(player.getPlayerPosition())
                .setPlayerColor(player.getPlayerColor())
                .setUserScore(player.getPlayerScoreJson())
                .build();

    }

    private Player mapEndPointToPlayer(Player endPoint) {

        Player player = new Player(endPoint.getUserId(), endPoint.getUserId(), endPoint.getName(), endPoint.getImagePath(),
                endPoint.getPlayerType(), endPoint.getPlayerScoreJson());

        player.setPlayerPosition(endPoint.getPlayerPosition());
        player.setPlayerColor(endPoint.getPlayerColor());

        return player;
    }

    private List<Player> mapEndPointListToPlayerList(List<Player> endPoints) {
        List<Player> players = new ArrayList<>();
        for (Player e : endPoints) {
            players.add(mapEndPointToPlayer(e));
        }
        return players;
    }

    /*    private Player mapPlayerToEndPoint(Player player) {
     *//*        return GameMessages.EndPoint.newBuilder()
                .setUserId(player.getUserId())
                .setEndPointId(player.getEndPointId())
                .setEndPointName(player.getName())
                .setImagePath(player.getImagePath())
                .setPlayerType(player.getPlayerType())
                .setPlayerPosition(player.getPlayerPosition())
                .setPlayerColor(player.getPlayerColor())
                .setUserScore(player.getPlayerScoreJson())
                .build();*//*

        Player player1 = new Player();
        player1.setUserId(player.getUserId());
        player1.setEndPointId(player.getEndPointId());
        player1.setName(player.getName());
        player1.setImagePath(player.getImagePath());
        player1.setPlayerType(player.getPlayerType());
        player1.setPlayerPosition(player.getPlayerPosition());
        player1.setPlayerColor(player.getPlayerColor());
        player1.setPlayerScore(player.getPlayerScoreJson());

        return player1;
    }*/

    public void sendInGamePlayerImagesToNewPlayer(List<Player> players, Player newPlayer) {
   /*     List<Player> endPoints = new ArrayList<>();
        for (Player p : players) {
            endPoints.add(p);
        }*/
        InternetConnectionManager.sendInGamePlayerImagesToNewPlayer(players, newPlayer);
    }

    public void broadcastGameMode(List<Player> players, InternetGameModeType gameMode) {
        List<String> endPointIds = new ArrayList<>();
        for (Player p : players) {
            endPointIds.add(p.getUserId());
        }
        if (endPointIds.size() > 0)
            InternetConnectionManager.sendGameSettingsToPlayers(endPointIds, gameMode);
    }

    public void broadcastGameInitMessage(List<Player> players, InternetInvitationType type) {
        List<String> sendToEndPointIds = getProxyPlayerEndpoints(players);

        if (sendToEndPointIds.size() > 0) {
            if (type == InternetInvitationType.READY_TO_PLAY) {
                InternetConnectionManager.broadcastReadyToPlayMessage(sendToEndPointIds, mapPlayerListToEndpointList(players));

            } else if (type == InternetInvitationType.GAME_START) {
                InternetConnectionManager.broadcastGameStartMessage(sendToEndPointIds);
            }
        }
    }

    public void sendReadyToPlayAck(Player player) {
        Player host = InternetHomeActivity.mHostPlayer; //done
        if (host != null) {
            InternetConnectionManager.sendReadyToPlayAckToHost(player, host.getUserId());
        } else {
            Log.e("start_ack", "Host not found");
        }
    }

    public List<String> getProxyPlayerEndpoints(List<Player> players) {
        List<String> proxyPlayerEndpoints = new ArrayList<>();

        for (int i = 0; i < players.size(); i++) {
            Player player = players.get(i);

            if (player.getPlayerType() == Player.Type.PROXY_PLAYER && player.getUserId() != null) {
                proxyPlayerEndpoints.add(player.getUserId());
            }
        }

        return proxyPlayerEndpoints;
    }

    private List<Player> mapPlayerListToEndpointList(List<Player> players) {
        List<Player> endpointList = new ArrayList<>();

        for (Player player : players) {
            endpointList.add(player);
        }

        return endpointList;
    }

    public void broadCastPlayerDisconnectedEvent(List<Player> players, Player disconnectedPlayer) {
        List<String> endPointIds = new ArrayList<>();
        for (Player p : players) {
            endPointIds.add(p.getUserId());
        }
        if (endPointIds.size() > 0)
            InternetConnectionManager.broadcastPlayerDisconnectedEvent(endPointIds, disconnectedPlayer);
    }

    public void broadcastRemovePlayerFromGame(List<Player> players, Player player) {
        List<String> endPointIds = new ArrayList<>();
        for (Player p : players) {
            endPointIds.add(p.getUserId());
        }
        if (endPointIds.size() > 0)
            InternetConnectionManager.removePlayerByHost(player, endPointIds);
    }

    public void removePlayer(Player player) {
        InternetConnectionManager.remove(player);
    }

    @Subscribe
    public void onInternetPlayerInvitationEvent(InternetInvitationEvent event) {
        if (getMvpView() != null) {
            switch (event.getType()) {
                case INVITE:
                    Player invitedByPlayer = mapEndPointToPlayer(event.getEndPoints().get(1));
                    invitedByPlayer.setUserId(event.getEndPoint().getUserId());

                    getMvpView().onInvitationReceived(invitedByPlayer, mapEndPointToPlayer(event.getEndPoints().get(0)));
                    break;

                case ACCEPT:
                    Player acceptedByPlayer = mapEndPointToPlayer(event.getEndPoints().get(1));
                    acceptedByPlayer.setUserId(event.getEndPoint().getUserId());

                    getMvpView().onInvitationAcceptByPeer(acceptedByPlayer, mapEndPointToPlayer(event.getEndPoints().get(0)));
                    break;

                case DECLINE:
                    getMvpView().onInvitationRejectByPeer(event.getEndPoint());
                    break;

                case UPDATE_ACCEPT:
                    getMvpView().onNewPeerAccepted(mapEndPointToPlayer(event.getEndPoint()));
                    break;

                case MESH_PLAYER_INFO:
                    //getMvpView().onInternetPlayerInfoReceived(mapEndPointListToPlayerList(event.getEndPoints()));
                    getMvpView().onInternetPlayerInfoReceived(event.getEndPoints());
                    break;

                case PLAYER_DISCONNECTED:
                //    getMvpView().onOtherPlayerDisconnected(mapEndPointToPlayer(event.getEndPoint()));
                    getMvpView().onOtherPlayerDisconnected(event.getEndPoint());
                    break;

                case PLAYER_REMOVED:
                  //  getMvpView().onPlayerRemovedByHost(mapEndPointToPlayer(event.getEndPoint()));
                    getMvpView().onPlayerRemovedByHost(event.getEndPoint());
                    break;

                case REMOVED:
                    getMvpView().onRemoved();
                    break;

                case READY_TO_PLAY:
                    getMvpView().onReadyToPlayMessage(mapEndPointListToPlayerList(event.getEndPoints()));
                    break;

                case GAME_START:
                    getMvpView().onGameStartedByHost();
                    break;

                case READY_TO_PLAY_ACK:
                    getMvpView().onReadyToPlayAckMessage(mapEndPointToPlayer(event.getEndPoint()));
                    break;

            }
        }
    }

    @Subscribe
    public void onImageReceivedEvent(InternetImageReceivedEvent event) {
        if (getMvpView() != null) {
            getMvpView().onProfilePicReceived(mapEndPointToPlayer(event.getEndPoint()), event.getImagePath());
        }
    }


    @Subscribe
    public void onInternetPlayerConnectionEvent(InternetConnectionEvent event) {
        if (event.getType() == InternetConnectionEvent.ConnectionType.CONNECTED) {
            if (getMvpView() != null)
                getMvpView().onInternetDeviceConnected(mapEndPointToPlayer(event.getEndPoint()));
            else
                Log.e(TAG, "onNearbyEndpointConnected: getMvpView Null!!!!");
        } else if (event.getType() == InternetConnectionEvent.ConnectionType.DISCONNECTED) {
            if (getMvpView() != null)
                getMvpView().onInternetDeviceDisconnected(mapEndPointToPlayer(event.getEndPoint()));
            else
                Log.e(TAG, "onNearbyEndPointDisconnected: getMvpView Null!!!!");
        }
    }

    @Subscribe
    public void onInternetGameSettingsEvent(InternetGameSettingsEvent event) {
        if (getMvpView() != null) {
            getMvpView().onGameModeDataChanged(event.getGameMode());
        }
    }

}
