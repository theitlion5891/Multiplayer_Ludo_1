package com.w3engineers.theme.ludosix.ui.ludo_game.ludo;

import com.google.gson.Gson;

import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.GameProxyPlayer;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.infoMsg.GameInfo;

/**
 * HumanPlayer
 * The human determines, through this class, which actions to send
 * specifically: which piece they want moved and if they roll a dice.
 */

public class ProxyPlayer extends GameProxyPlayer {

    /**
     * constructor
     *
     * @param player is info of player
     */
    public ProxyPlayer(Player player) {
        super(player);
    }


    /**
     * Callback method, called when player gets a message
     *
     * @param info the message
     */
    @Override
    public void receiveInfo(GameInfo info) {
        String data = new Gson().toJson(info);
    }
}
