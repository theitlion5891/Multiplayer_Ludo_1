package com.w3engineers.theme.util.lib.internet;

import com.w3engineers.theme.ludosix.data.local.model.Player;
import com.w3engineers.theme.util.lib.nearby.NearbyConnectionEvent;

import javax.sql.ConnectionEvent;

public class InternetConnectionEvent {
    public InternetConnectionEvent(InternetConnectionEvent.ConnectionType type, Player endPoint) {
        this.type = type;
        this.endPoint = endPoint;
    }

    public enum ConnectionType {CONNECTED,DISCONNECTED}
    private InternetConnectionEvent.ConnectionType type;
    private Player endPoint;

    public InternetConnectionEvent.ConnectionType getType() {
        return type;
    }

    public void setType(InternetConnectionEvent.ConnectionType type) {
        this.type = type;
    }

    public Player getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(Player endPoint) {
        this.endPoint = endPoint;
    }
}
