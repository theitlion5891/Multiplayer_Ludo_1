package com.w3engineers.theme.util.helper;

/**
 * Created by: SM. MAMUNUR RAHAMAN on 6/7/18 at 2:46 PM.
 * Email: hera@w3engineers.com
 * Code Responsibility: Button click tone generator singleton class
 * Last edited by : Rezwanur on Jan 29, 2019.
 * Last Reviewed by : Rezwanur on Jan 29, 2019.
 * Copyright (c) 2018, W3 Engineers Ltd. All rights reserved.
 */

import android.media.MediaPlayer;

import com.w3engineers.theme.LudoSixApp;
import com.w3engineers.theme.ludosix.data.helper.GameDataHelper;
import com.w3engineers.theme.ludosix.ui.ludo_game.game.GameMainActivity;

public class ToneFactory {

    private static ToneFactory tuneManager;

    public static ToneFactory on() {
        if (tuneManager == null) {
            tuneManager = new ToneFactory();
        }

        return tuneManager;
    }

    private MediaPlayer mediaPlayer;

    public void play(int resId) {
        if (GameMainActivity.isInGame || com.w3engineers.theme.ludosix.ui.snakes_game.game.GameMainActivity.isInGame) {
            initPlayer(resId);
        }
    }

    public void stop() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
        }
    }

    private void initPlayer(int resId) {
        if (mediaPlayer != null) {
            stop();

            mediaPlayer.release();
            mediaPlayer = null;
        }

        float volume = GameDataHelper.getSoundVolume();

        mediaPlayer = MediaPlayer.create(LudoSixApp.getContext(), resId);
        mediaPlayer.setVolume(volume, volume);
        mediaPlayer.start();
    }
}
