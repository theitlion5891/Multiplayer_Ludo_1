package com.w3engineers.theme.util.helper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import androidx.annotation.NonNull;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;


/**
 * Created by Anjan Debnath on 11/27/2017.
 * Copyright (c) 2017, W3 Engineers Ltd. All rights reserved.
 */

public class ImageSaver {

    private String directoryName = "images";
    private String fileName = "image.png";
    private Context context;
    private boolean external;
    private OnImageSaveResponse onImageSaveResponse;
    private static ImageSaver imageSaver;

    public ImageSaver(Context context) {
        this.context = context;
    }

    public static ImageSaver on(Context context) {
        if (imageSaver == null) {
            imageSaver = new ImageSaver(context);
        }
        return imageSaver;
    }


    public String saveToInternalStorage(Bitmap bitmapImage, String imageName) {
        String filePath = Constant.Directory.PARENT_DIRECTORY + Constant.Directory.PLAYER_IMAGES;
        File imageFileP = new File(filePath);
     //   deleteBasedOnNumber(imageFileP);

        if (!imageFileP.exists()) {
            imageFileP.mkdirs();
            File nomediaFile = new File(filePath + Constant.Directory.FILE_NO_MEDIA);
            if (!nomediaFile.exists()) {
                try {
                    nomediaFile.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        String mPath = filePath + "/" + imageName + ".JPEG";
        File imageFile = new File(mPath);
        FileOutputStream outputStream = null;

        try {
            outputStream = new FileOutputStream(imageFile);
            bitmapImage.compress(Bitmap.CompressFormat.JPEG, 50, outputStream);
           // showScreenShot.setImageBitmap(bitmapImage);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        String imagePath = Uri.fromFile(imageFile).getPath();
        Log.e("image_status", "System path" +imagePath + "custom path " + mPath);

        return mPath;
    }



    public ImageSaver setFileName(String fileName) {
        this.fileName = fileName;
        return this;
    }

    public ImageSaver setExternal(boolean external) {
        this.external = external;
        return this;
    }

    public ImageSaver setDirectoryName(String directoryName) {
        this.directoryName = directoryName;
        return this;
    }

    public OnImageSaveResponse setOnImageSaverCallBack(OnImageSaveResponse callBack) {
        this.onImageSaveResponse = callBack;
        return onImageSaveResponse;
    }

    public void save(Bitmap bitmapImage, OnImageSaveResponse onImageSaveResponse) {
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(createFile());
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 50, fileOutputStream);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                    if (onImageSaveResponse != null) {
                        String directory = directoryName;
                        onImageSaveResponse.imageSaveSuccess(directory);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
                if (onImageSaveResponse != null) {
                    onImageSaveResponse.imageSaveFailed();
                }
            }
        }
    }

    @NonNull
    private File createFile() {
        File directory;
        if (external) {
            directory = getAlbumStorageDir(directoryName);
        } else {
            directory = context.getDir(directoryName, Context.MODE_PRIVATE);
        }
        if (!directory.exists() && !directory.mkdirs()) {
            Log.e("ImageSaver", "Error creating directory " + directory);
        }

        return new File(directory, fileName);
    }

    private File getAlbumStorageDir(String albumName) {
        String baseDirectory = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator;
        return new File(baseDirectory, albumName);
    }

    public boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }

        return false;
    }

    public Bitmap load() {
        FileInputStream inputStream = null;
        try {
            inputStream = new FileInputStream(createFile());
            return BitmapFactory.decodeStream(inputStream);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public interface OnImageSaveResponse {
        void imageSaveSuccess(String imagePath);

        void imageSaveFailed();
    }
}