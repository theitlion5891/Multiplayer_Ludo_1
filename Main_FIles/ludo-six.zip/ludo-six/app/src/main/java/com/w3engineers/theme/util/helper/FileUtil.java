package com.w3engineers.theme.util.helper;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.w3engineers.theme.LudoSixApp;

/**
 * Created by w3e02 on 10/16/17.
 */

public class FileUtil {
    public static final String IMAGE = "img";
    public static final String VOICE = "voice";

    public FileUtil() {
    }

    public static boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }

    public static void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles()) deleteRecursive(child);

        fileOrDirectory.delete();
    }

    public static File makeExternalDir(String name) {
        if (isExternalStorageWritable()) {
            File dir = FileUtil.makeDir(Environment.getExternalStorageDirectory(), name);
            if (dir != null && dir.isDirectory()) {
                return dir;
            }
        }
        return null;
    }

    public static File makeDir(File parent, String child) {
        if (isExternalStorageWritable()) {
            File file = new File(parent, child);
            if (file.exists() && file.isDirectory()) return file;
            if (file.mkdirs()) {
                return file;
            }
        }
        return null;
    }

    public static String getFileType(String path) {
        try {
            String url = path.toLowerCase(Locale.US);
            if (url.toString().contains(".m4p")
                    || url.toString().contains(".3gpp")
                    || url.toString().contains(".mp3")
                    || url.toString().contains(".wma")
                    || url.toString().contains(".wav")
                    || url.toString().contains(".ogg")
                    || url.toString().contains(".m4a")
                    || url.toString().contains(".aac")
                    || url.toString().contains(".ota")
                    || url.toString().contains(".imy")
                    || url.toString().contains(".rtx")
                    || url.toString().contains(".rtttl")
                    || url.toString().contains(".xmf")
                    || url.toString().contains(".mid")
                    || url.toString().contains(".mxmf")
                    || url.toString().contains(".amr")
                    || url.toString().contains(".flac")) {
                return VOICE;
            } else if (url.toString().contains(".jpg")
                    || url.toString().contains(".jpeg")
                    || url.toString().contains(".png")
                    || url.toString().contains(".gif")
                    || url.toString().contains(".bmp")) {

                return IMAGE;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
        return null;
    }

    public static long getMediaLength(String mediaLink) {
        long mediaLength = 0;
        try {
            MediaPlayer mp = MediaPlayer
                    .create(LudoSixApp.getContext(), Uri.parse(mediaLink));
            return mp.getDuration();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mediaLength;
    }

    public static String getDurationInMinute(long durationInMillis) {

        final int HOUR = 60 * 60 * 1000;
        final int MINUTE = 60 * 1000;
        final int SECOND = 1000;

        long durationHour = durationInMillis / HOUR;
        long durationMint = (durationInMillis % HOUR) / MINUTE;
        long durationSec = (durationInMillis % MINUTE) / SECOND;

        String dispTime;
        if (durationSec > 9) {
            dispTime = durationMint + ":" + durationSec;
        } else {
            dispTime = durationMint + ":0" + durationSec;
        }
        return dispTime;
    }

    public static String getFileName(String fileLink) {

        if (TextUtils.isEmpty(fileLink)) return "default.jpg";

        String fName = "";
        try {
            File file = new File(fileLink);
            fName = file.getName();
        } catch (Exception e) {
        }
        return fName;
    }


    public static String buildFileName(String fileName) {
        if (fileName == null) return null;

        if (fileName.length() > 5) {
            fileName = fileName.substring(fileName.length() - 5);
        }

        String ext = getExtension(fileName);
        if (ext == null) return null;

        if (fileName.indexOf(".") > 0) {
            fileName = fileName.substring(0, fileName.lastIndexOf("."));
        }
        return DirectoryConstants.IMAGE + "_" + fileName + "_" + TimeUtil.currentTime() + "." + ext;
    }

    /*
     * Get the extension of a file.
     */
    public static String getExtension(String fileName) {

        int i = fileName.lastIndexOf('.');

        if (i > 0 && i < fileName.length() - 1) {
            return fileName.substring(i + 1).toLowerCase();
        }
        return null;
    }


    public static Uri getCameraUri() {
        return Uri.fromFile(getCameraOutputFile());
    }

    public static File getCameraOutputFile() {
        return getOutputFile(DirectoryConstants.CAMERA_DIRECTORY, DirectoryConstants.IMAGE, ".jpg");


    }

    private static File getOutputFile(String path, String prefix, String extension) {

        File mediaStorageDir = new File(path);
        if (mediaStorageDir == null || !mediaStorageDir.exists()) {
            // Create the storage directory if it does not exist
            new File(path).mkdirs();
        }

        String timeStamp = getTImeStamp();
        File mediaFile = new File(mediaStorageDir.getPath() + File.separator + prefix + timeStamp + extension);
        return mediaFile;

    }


    private static String getTImeStamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
    }

    public static Intent buildCameraIntent(Uri uri) {
        Intent intent = getCameraIntent();
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        intent.putExtra("return-data", true);
        return intent;
    }


    public static Intent getCameraIntent() {
        return new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
    }


    public static boolean isDeviceSupportCamera(Context mCOntext) {
        return mCOntext.getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_CAMERA);
    }

    public void scanMediaFile(Context context, String filePath) {
        MediaScannerConnection.scanFile(context,
                new String[]{filePath}, null,
                new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                    }
                });
    }

}
