package com.w3engineers.theme.util.helper;

/*
*  ****************************************************************************
*  * Created by : Azizul Islam process 19-Oct-17 at 3:51 PM.
*  * Email : azizul@w3engineers.com
*  * 
*  * Last edited by : Azizul Islam process 19-Oct-17.
*  * 
*  * Last Reviewed by : <Reviewer Name> process <mm/dd/yy>
*  ****************************************************************************
*/
public final class BindUtils {
    public static String format(String txt) {
        return txt != null ? txt : "";
    }

    public static int format(int value) {
        return value > 0 ? value : 0;
    }
}
