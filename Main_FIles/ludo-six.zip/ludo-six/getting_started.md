# Android MVP Architecture Tutorials

##Getting Started with MyMvpApp Tutorials

###***Here we will learn***
 1. **How we can start a android application from scratch.**
 2. **Which base classes are already implemented.**
 3. **How to extend and implement those class.**
 4. **What API are already available to use to avoid re write code.**


###***So let's start***
* **Step 1**: Clone this repository on your work station
* **Step 2**: Delete **.git** folder from source root directory
* **Step 3**: init **git** (optional)
* **Step 4**: Please read **Android-Project-Guideline_v1.1.pdf** doc carefully 
* **Step 5**: Change package name **myapplication** to your app name. e.g **flare**
* **Step 6**: Change class name **io.left.core.MyApplication.java** according to your app name. e.g **o.left.core.FlareApplication.java**

####Start a new **Android Activity**
1. Suppose new activity will be **contact**
2. So, create a package inside **io.left.core.myapplication.ui** , named as **contact**
3. Create a new Java **interface** on same package, named as **ContactMvpView.java** and extends **io.left.core.myapplication.ui.base.MvpView**
4. Create a new Java class on same package name **ContactPresenter.java** then
     * extends **io.left.core.myapplication.ui.base.BasePresenter** and
     * pass **ContactMvpView** as generic type as **BasePresenter<ContactMvpView>**
5. Create new java class file in **io.left.core.myapplication.ui.contact** name **ContactActivity.java** then
    * extends **BaseActivity** as  **BaseActivity<ContactMvpView, ContactPresenter>**
    * implements **ContactMvpView**
    * Implement all override methods suggest by Android Studio
    * @Override method **getLayoutId()**: pass the  current activity layout file id as **return R.layout.activity_contact;**
    * @Override method **initPresenter()**: pass the  current ContactPresenter as **return new ContactPresenter();**
    * @Override method **startUI()**: is the representative of Activity lifecycle method  **onStart()**, which call after **onCreate**
    * @Override method **stopUI()**: is the representative of Activity lifecycle method  **onDestroy()**, which call during destroy any activity
    * We use dataBinding, so please add <layout tag on each layout file start point     
    * Declare a new variable mBinding as ActivityContactBinding type.
    * On **startUI()** method assign mBinding = (ActivityContactBinding) getViewDataBinding();
    * All UI components are available on  mBinding objects
    * **ActivityContactBinding** class will auto generate by android system
    * Now you can proceed on your logic 
* Add a entry of **ContactActivity** in **AndroidManifest.xml** file    


####Start a new **Android Fragment**
* Same as android Activity (follow the structure of **contact** package)

####Start a new **Recycler View Adapter**
* Create adapter in the same package of Activity/Fragment where you use the adapter
* Name the adapter 

# N.B: 
##We gave all type of class example inside this base application. So, please follow this.